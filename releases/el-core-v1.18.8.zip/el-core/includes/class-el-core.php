<?php
/**
 * EL Core Orchestrator
 * 
 * Central class that initializes all subsystems in the correct order
 * and provides a single access point for the entire system.
 * 
 * Usage: $core = EL_Core::instance();
 *        $core->settings->get('brand', 'primary_color');
 *        $core->modules->is_active('lms');
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class EL_Core {

    private static ?EL_Core $instance = null;

    // ── Subsystems (public for easy access) ──
    public ?EL_Settings       $settings      = null;
    public ?EL_Database       $database      = null;
    public ?EL_Roles          $roles         = null;
    public ?EL_Module_Loader  $modules       = null;
    public ?EL_Asset_Loader   $assets        = null;
    public ?EL_AJAX_Handler   $ajax          = null;
    public ?EL_AI_Client      $ai            = null;
    public ?EL_Organizations  $organizations = null;

    /**
     * Get the single instance
     */
    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Boot sequence — order matters!
     */
    private function __construct() {
        $this->load_dependencies();
        $this->boot();
    }

    /**
     * Load all core class files
     */
    private function load_dependencies(): void {
        $includes = EL_CORE_DIR . 'includes/';

        require_once $includes . 'class-admin-ui.php';
        require_once $includes . 'class-settings.php';
        require_once $includes . 'class-database.php';
        require_once $includes . 'class-roles.php';
        require_once $includes . 'class-module-loader.php';
        require_once $includes . 'class-asset-loader.php';
        require_once $includes . 'class-ajax-handler.php';
        require_once $includes . 'class-ai-client.php';
        require_once $includes . 'class-organizations.php';
        require_once $includes . 'class-canvas-page.php';
    }

    /**
     * Initialize subsystems in dependency order
     * 
     * Order:
     * 1. Settings    — everything reads config
     * 2. Database    — modules need schema management
     * 3. Roles       — modules need capability checking
     * 4. Modules     — discovers and activates feature modules
     * 5. Assets      — CSS/JS with brand variables
     * 6. AJAX        — request handling
     * 7. AI Client   — shared AI integration
     * 8. Canvas Page — custom page template system
     */
    private function boot(): void {
        // 1. Settings first — everything depends on configuration
        $this->settings = new EL_Settings();

        // 2. Database — modules need tables before they can run
        $this->database = new EL_Database();

        // 3. Roles — modules need capability checking
        $this->roles = new EL_Roles( $this->settings );

        // 4. Module Loader — discovers and activates modules
        $this->modules = new EL_Module_Loader( $this );

        // 5. Asset Loader — CSS/JS with brand injection
        $this->assets = new EL_Asset_Loader( $this->settings );

        // 6. AJAX Handler — standardized request processing
        $this->ajax = new EL_AJAX_Handler();

        // 7. AI Client — shared API wrapper
        $this->ai = new EL_AI_Client( $this->settings );

        // 8. Organizations — core client management infrastructure
        $this->database->ensure_core_tables();
        $this->organizations = new EL_Organizations( $this->database );

        // 9. Canvas Page — AI-generated page system
        EL_Canvas_Page::instance();

        // Hide WP toolbar from portal-only (client) users
        add_action( 'after_setup_theme', [ $this, 'maybe_hide_admin_bar' ] );

        // Handle built-in Login As / Switch Back (no plugin required)
        // admin-post.php runs while Fred is still authenticated as admin — safe for session switch
        add_action( 'admin_post_el_login_as',   [ $this, 'handle_login_as' ] );
        add_action( 'admin_post_el_switch_back', [ $this, 'handle_switch_back' ] );
        // Also handle switch-back from the front end (portal page)
        add_action( 'init', [ $this, 'handle_switch_back' ] );

        // Hook into WordPress admin
        if ( is_admin() ) {
            $this->init_admin();
        }
    }

    /**
     * Hide the WordPress admin toolbar for portal-only (client) users.
     * When an admin has switched into a client account, the portal shortcode
     * renders its own switch-back bar instead.
     */
    public function maybe_hide_admin_bar(): void {
        if ( ! is_user_logged_in() ) {
            return;
        }

        // Always show toolbar for admins
        if ( current_user_can( 'manage_options' ) || current_user_can( 'manage_expand_site' ) ) {
            return;
        }

        // Hide toolbar for client-role users (portal access only)
        if (
            current_user_can( 'view_expand_site' ) ||
            current_user_can( 'es_contributor' ) ||
            current_user_can( 'es_decision_maker' )
        ) {
            show_admin_bar( false );
        }
    }

    /**
     * Handle "Login As" — admin switches into a client account.
     *
     * URL: ?el_login_as=USER_ID&_wpnonce=...
     * - Verifies nonce and that current user is admin
     * - Stores admin user ID in a transient keyed to the client user ID
     * - Sets auth cookie for the client user and redirects to portal
     */
    public function handle_login_as(): void {
        // Works via admin-post.php?action=el_login_as
        $client_user_id = absint( $_GET['el_login_as'] ?? 0 );
        if ( ! $client_user_id ) {
            wp_die( __( 'Missing user ID.', 'el-core' ) );
        }

        // admin_post hook already requires authentication, but double-check for manage_options
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Permission denied.', 'el-core' ) );
        }

        if ( ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'el_login_as_' . $client_user_id ) ) {
            wp_die( __( 'Security check failed.', 'el-core' ) );
        }

        $client_user = get_userdata( $client_user_id );
        if ( ! $client_user ) {
            wp_die( __( 'User not found.', 'el-core' ) );
        }

        $admin_user_id = get_current_user_id();

        // Store the admin's ID — expires in 8 hours
        set_transient( 'el_viewing_as_' . $client_user_id, $admin_user_id, 8 * HOUR_IN_SECONDS );

        // Switch session to the client
        wp_clear_auth_cookie();
        wp_set_current_user( $client_user_id );
        wp_set_auth_cookie( $client_user_id, true );

        // Redirect to portal
        $redirect = esc_url_raw( $_GET['redirect_to'] ?? home_url( '/' ) );
        wp_safe_redirect( $redirect );
        exit;
    }

    /**
     * Handle "Switch Back" — return to admin account after viewing as a client.
     *
     * URL: ?el_switch_back=ADMIN_USER_ID&_wpnonce=...
     * - Reads the stored transient to verify the admin ID
     * - Clears the transient
     * - Restores the admin session and redirects to WP admin
     */
    public function handle_switch_back(): void {
        // Called from init (front end portal) or admin_post hook
        if ( empty( $_GET['el_switch_back'] ) ) {
            return;
        }

        $admin_user_id = absint( $_GET['el_switch_back'] );
        if ( ! $admin_user_id ) {
            return;
        }

        if ( ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'el_switch_back_' . $admin_user_id ) ) {
            wp_die( __( 'Security check failed.', 'el-core' ) );
        }

        $current_user_id = get_current_user_id();

        // Verify the stored transient matches — prevents forged switch-back attempts
        $stored_admin_id = (int) get_transient( 'el_viewing_as_' . $current_user_id );
        if ( $stored_admin_id !== $admin_user_id ) {
            wp_die( __( 'Switch back session not found or expired.', 'el-core' ) );
        }

        $admin_user = get_userdata( $admin_user_id );
        if ( ! $admin_user || ! $admin_user->has_cap( 'manage_options' ) ) {
            wp_die( __( 'Admin user not found.', 'el-core' ) );
        }

        // Clean up the transient
        delete_transient( 'el_viewing_as_' . $current_user_id );

        // Restore the admin session
        wp_clear_auth_cookie();
        wp_set_current_user( $admin_user_id );
        wp_set_auth_cookie( $admin_user_id, true );

        // Redirect back to WP admin
        wp_safe_redirect( admin_url() );
        exit;
    }

    /**
     * Initialize admin-side functionality
     */
    private function init_admin(): void {
        add_action( 'admin_menu', [ $this, 'register_admin_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
    }

    /**
     * Register the EL Core admin menu and subpages
     */
    public function register_admin_menu(): void {
        // Main menu
        add_menu_page(
            'EL Core',                          // Page title
            'EL Core',                          // Menu title
            'manage_options',                   // Capability required
            'el-core',                          // Menu slug
            [ $this, 'render_admin_page' ],     // Callback
            'dashicons-building',               // Icon
            3                                   // Position
        );

        // Explicitly register Dashboard as the first submenu item with the same
        // slug as the parent. This suppresses WordPress's auto-generated duplicate
        // and ensures it stays labeled "Dashboard" when other submenus are added.
        add_submenu_page( 'el-core', 'EL Core Dashboard', 'Dashboard', 'manage_options', 'el-core', [ $this, 'render_admin_page' ] );
        add_submenu_page( 'el-core', 'Brand Settings', 'Brand', 'manage_options', 'el-core-brand', [ $this, 'render_brand_page' ] );
        add_submenu_page( 'el-core', 'Module Manager', 'Modules', 'manage_options', 'el-core-modules', [ $this, 'render_modules_page' ] );
        add_submenu_page( 'el-core', 'Role Manager', 'Roles', 'manage_options', 'el-core-roles', [ $this, 'render_roles_page' ] );
    }

    /**
     * Enqueue admin CSS/JS
     */
    public function enqueue_admin_assets( string $hook ): void {
        // Only load on our pages
        if ( strpos( $hook, 'el-core' ) === false ) {
            return;
        }

        wp_enqueue_style(
            'el-core-admin',
            EL_CORE_URL . 'admin/css/admin.css',
            [],
            EL_CORE_VERSION
        );

        wp_enqueue_script(
            'el-core-admin',
            EL_CORE_URL . 'admin/js/admin.js',
            [ 'jquery' ],
            EL_CORE_VERSION,
            true
        );
    }

    /**
     * Admin page renderers — load view files
     */
    public function render_admin_page(): void {
        include EL_CORE_DIR . 'admin/views/settings-general.php';
    }

    public function render_brand_page(): void {
        include EL_CORE_DIR . 'admin/views/settings-brand.php';
    }

    public function render_modules_page(): void {
        include EL_CORE_DIR . 'admin/views/settings-modules.php';
    }

    public function render_roles_page(): void {
        include EL_CORE_DIR . 'admin/views/settings-roles.php';
    }

    /**
     * Prevent cloning and unserialization
     */
    private function __clone() {}
    public function __wakeup() {
        throw new \Exception( 'Cannot unserialize singleton' );
    }
}

<?php
/**
 * Expand Site Module Settings Page
 * 
 * Allows agencies to configure stage names, deadlines, and feature toggles
 * to match their workflow and make the module resale-ready.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$module = EL_Expand_Site_Module::instance();
$settings = $module->core->settings;

// Save settings
if ( $_SERVER['REQUEST_METHOD'] === 'POST' && isset( $_POST['el_es_settings_nonce'] ) ) {
    if ( ! wp_verify_nonce( $_POST['el_es_settings_nonce'], 'el_es_settings' ) ) {
        wp_die( __( 'Security check failed.', 'el-core' ) );
    }

    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( __( 'Permission denied.', 'el-core' ) );
    }

    // Save each setting
    $setting_keys = [
        'stage_1_name', 'stage_2_name', 'stage_3_name', 'stage_4_name',
        'stage_5_name', 'stage_6_name', 'stage_7_name', 'stage_8_name',
        'default_stage_deadline_days', 'deadline_warning_days',
        'enable_ai_content_generation', 'enable_branding_ai', 'enable_multi_stakeholder',
        'agency_name', 'default_budget_low', 'default_budget_high', 'enable_client_portal'
    ];

    foreach ( $setting_keys as $key ) {
        $value = $_POST[ $key ] ?? '';
        
        // Convert checkboxes to boolean
        if ( in_array( $key, [ 'enable_ai_content_generation', 'enable_branding_ai', 'enable_multi_stakeholder', 'enable_client_portal' ] ) ) {
            $value = ! empty( $value ) ? 1 : 0;
        }
        
        // Convert numbers
        if ( in_array( $key, [ 'default_stage_deadline_days', 'deadline_warning_days', 'default_budget_low', 'default_budget_high' ] ) ) {
            $value = absint( $value );
        }
        
        $settings->set( 'mod_expand-site', $key, sanitize_text_field( $value ) );
    }

    echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Settings saved!', 'el-core' ) . '</p></div>';
}

// Load current values
$values = [];
$setting_keys = [
    'stage_1_name' => 'Qualification',
    'stage_2_name' => 'Discovery',
    'stage_3_name' => 'Scope Lock',
    'stage_4_name' => 'Visual Identity',
    'stage_5_name' => 'Wireframes',
    'stage_6_name' => 'Build',
    'stage_7_name' => 'Review',
    'stage_8_name' => 'Delivery',
    'default_stage_deadline_days' => 7,
    'deadline_warning_days' => 2,
    'enable_ai_content_generation' => true,
    'enable_branding_ai' => true,
    'enable_multi_stakeholder' => true,
    'agency_name' => '',
    'default_budget_low' => 3000,
    'default_budget_high' => 10000,
    'enable_client_portal' => true,
];

foreach ( $setting_keys as $key => $default ) {
    $values[ $key ] = $settings->get( 'mod_expand-site', $key, $default );
}

?>

<div class="wrap el-admin-wrap">
    <?php echo EL_Admin_UI::page_header( [
        'title' => __( 'Expand Site Settings', 'el-core' ),
        'icon'  => 'admin-generic',
    ] ); ?>

    <form method="post" action="">
        <?php wp_nonce_field( 'el_es_settings', 'el_es_settings_nonce' ); ?>

        <div class="el-admin-section">
            <h2><?php _e( 'Stage Names', 'el-core' ); ?></h2>
            <p class="description"><?php _e( 'Customize the 8 stage names to match your agency workflow.', 'el-core' ); ?></p>

            <table class="form-table">
                <?php for ( $i = 1; $i <= 8; $i++ ): ?>
                <tr>
                    <th scope="row">
                        <label for="stage_<?php echo $i; ?>_name"><?php printf( __( 'Stage %d Name', 'el-core' ), $i ); ?></label>
                    </th>
                    <td>
                        <input type="text" id="stage_<?php echo $i; ?>_name" name="stage_<?php echo $i; ?>_name" 
                               value="<?php echo esc_attr( $values[ "stage_{$i}_name" ] ); ?>" 
                               class="regular-text">
                    </td>
                </tr>
                <?php endfor; ?>
            </table>
        </div>

        <div class="el-admin-section">
            <h2><?php _e( 'Deadlines & Escalation', 'el-core' ); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="default_stage_deadline_days"><?php _e( 'Default Stage Deadline (days)', 'el-core' ); ?></label>
                    </th>
                    <td>
                        <input type="number" id="default_stage_deadline_days" name="default_stage_deadline_days" 
                               value="<?php echo esc_attr( $values['default_stage_deadline_days'] ); ?>" 
                               min="1" max="365" class="small-text">
                        <p class="description"><?php _e( 'Default number of days for each stage deadline.', 'el-core' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="deadline_warning_days"><?php _e( 'Deadline Warning (days before)', 'el-core' ); ?></label>
                    </th>
                    <td>
                        <input type="number" id="deadline_warning_days" name="deadline_warning_days" 
                               value="<?php echo esc_attr( $values['deadline_warning_days'] ); ?>" 
                               min="1" max="30" class="small-text">
                        <p class="description"><?php _e( 'Show warning badge when deadline is within this many days.', 'el-core' ); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <div class="el-admin-section">
            <h2><?php _e( 'Feature Toggles', 'el-core' ); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><?php _e( 'AI Content Generation', 'el-core' ); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="enable_ai_content_generation" value="1" 
                                   <?php checked( $values['enable_ai_content_generation'], 1 ); ?>>
                            <?php _e( 'Enable AI-powered content generation for pages', 'el-core' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e( 'AI Branding Tools', 'el-core' ); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="enable_branding_ai" value="1" 
                                   <?php checked( $values['enable_branding_ai'], 1 ); ?>>
                            <?php _e( 'Enable AI-powered brand color palette generation', 'el-core' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e( 'Multi-Stakeholder Projects', 'el-core' ); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="enable_multi_stakeholder" value="1" 
                                   <?php checked( $values['enable_multi_stakeholder'], 1 ); ?>>
                            <?php _e( 'Allow multiple stakeholders per project with Decision Maker / Contributor roles', 'el-core' ); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e( 'Client Portal Shortcodes', 'el-core' ); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="enable_client_portal" value="1" 
                                   <?php checked( $values['enable_client_portal'], 1 ); ?>>
                            <?php _e( 'Enable client-facing portal shortcodes', 'el-core' ); ?>
                        </label>
                    </td>
                </tr>
            </table>
        </div>

        <div class="el-admin-section">
            <h2><?php _e( 'Agency Settings', 'el-core' ); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="agency_name"><?php _e( 'Agency Name', 'el-core' ); ?></label>
                    </th>
                    <td>
                        <input type="text" id="agency_name" name="agency_name" 
                               value="<?php echo esc_attr( $values['agency_name'] ); ?>" 
                               class="regular-text">
                        <p class="description"><?php _e( 'Your agency name (appears in client communications).', 'el-core' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="default_budget_low"><?php _e( 'Default Budget Range (Low)', 'el-core' ); ?></label>
                    </th>
                    <td>
                        <input type="number" id="default_budget_low" name="default_budget_low" 
                               value="<?php echo esc_attr( $values['default_budget_low'] ); ?>" 
                               min="0" step="100" class="regular-text">
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="default_budget_high"><?php _e( 'Default Budget Range (High)', 'el-core' ); ?></label>
                    </th>
                    <td>
                        <input type="number" id="default_budget_high" name="default_budget_high" 
                               value="<?php echo esc_attr( $values['default_budget_high'] ); ?>" 
                               min="0" step="100" class="regular-text">
                    </td>
                </tr>
            </table>
        </div>

        <?php submit_button( __( 'Save Settings', 'el-core' ) ); ?>
    </form>
</div>

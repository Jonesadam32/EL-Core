<?php
/**
 * Admin View: Expand Site — Project Detail (v1.22.9 redesign)
 *
 * Layout: Page header → 8-stage pipeline stepper → two-column body
 *   Left:  Stage-aware panel (checklist + tools for current stage)
 *   Right: Persistent sidebar (project info, team, utilities)
 * All modals preserved at bottom.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$module     = EL_Expand_Site_Module::instance();
$core       = EL_Core::instance();
$project_id = absint( $_GET['project'] ?? 0 );
$project    = $module->get_project( $project_id );

if ( ! $project ) {
    echo EL_Admin_UI::wrap(
        EL_Admin_UI::notice( [ 'message' => __( 'Project not found.', 'el-core' ), 'type' => 'error' ] )
    );
    return;
}

// ── Load all data ──────────────────────────────────────────────────────────
$stage_history  = $module->get_stage_history( $project_id );
$deliverables   = $module->get_deliverables( $project_id );
$feedback       = $module->get_feedback( $project_id );
$pages          = $module->get_pages( $project_id );
$change_orders  = $module->get_change_orders( $project_id );
$stakeholders   = $module->get_stakeholders( $project_id );
$definition     = $module->get_project_definition( $project_id );
$proposals      = $module->get_proposals( $project_id );
$accepted_proposal  = $module->get_accepted_proposal( $project_id );
$active_def_review  = $module->get_active_definition_review( $project_id );
$def_review_comments = $active_def_review ? $module->get_definition_comments( $active_def_review->id ) : [];
$def_review_verdicts = $active_def_review ? $module->get_definition_verdicts( $active_def_review->id ) : [];

global $wpdb;
$_sugg_tbl = $wpdb->prefix . 'el_es_definition_suggestions';
$def_pending_suggestions = $wpdb->get_results( $wpdb->prepare(
    "SELECT s.*, u.display_name
     FROM {$_sugg_tbl} s
     LEFT JOIN {$wpdb->users} u ON u.ID = s.suggested_by
     WHERE s.project_id = %d AND s.status = 'pending'
     ORDER BY s.created_at ASC",
    $project_id
) );

$current_stage    = (int) $project->current_stage;
$stages           = $module->get_stages();
$is_locked        = $definition && $definition->locked_at;
$def_review_status = $definition->review_status ?? 'draft';
$pending_feedback  = count( array_filter( $feedback, fn( $f ) => $f->status === 'pending' ) );
$dm_count          = count( array_filter( $stakeholders, fn( $s ) => $s->role === 'decision_maker' ) );
$pending_proposals = array_filter( $proposals, fn( $p ) => $p->status === 'sent' );

// ── Build per-stage checklist items ───────────────────────────────────────
function el_es_checklist_item( string $label, bool $done, string $note = '', bool $alert = false ): string {
    $icon  = $done
        ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>'
        : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle></svg>';
    $state = $done ? 'el-es-check-done' : ( $alert ? 'el-es-check-alert' : 'el-es-check-todo' );
    $html  = '<div class="el-es-checklist-item ' . $state . '">';
    $html .= '<span class="el-es-check-icon">' . $icon . '</span>';
    $html .= '<span class="el-es-check-label">' . esc_html( $label );
    if ( $note ) $html .= ' <span class="el-es-check-note">' . esc_html( $note ) . '</span>';
    $html .= '</span>';
    $html .= '</div>';
    return $html;
}

// ── Compute stage-specific checklist + tools ──────────────────────────────
$stage_checklist = '';
$stage_tools     = '';
$stage_alerts    = []; // badge alerts for the panel header

switch ( $current_stage ) {

    case 1: // Qualification
        $has_dm         = $dm_count > 0;
        $has_budget     = $project->budget_range_low > 0 || $project->budget_range_high > 0;
        $has_stakehldr  = count( $stakeholders ) > 0;

        $stage_checklist .= el_es_checklist_item( 'Add at least one stakeholder',                    $has_stakehldr );
        $stage_checklist .= el_es_checklist_item( 'Designate a Decision Maker',                      $has_dm, $has_dm ? '' : 'required to advance' );
        $stage_checklist .= el_es_checklist_item( 'Record budget range',                             $has_budget );

        $stage_tools .= EL_Admin_UI::btn( [
            'label'   => __( 'Add Stakeholder', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'plus-alt',
            'data'    => [ 'modal-open' => 'add-stakeholder-modal' ],
        ] );
        break;

    case 2: // Discovery
        $has_transcript  = ! empty( $project->discovery_transcript );
        $has_definition  = $definition && ! empty( $definition->site_description );
        $review_sent     = in_array( $def_review_status, [ 'pending_review', 'approved', 'needs_revision', 'locked' ], true );
        $client_approved = in_array( $def_review_status, [ 'approved', 'locked' ], true );
        $def_locked      = $is_locked;

        // Tally review responses
        $total_sh         = count( $stakeholders );
        $responded_sh     = 0;
        if ( $active_def_review && ! empty( $def_review_verdicts ) ) {
            $responded_ids = array_unique( array_map( fn( $v ) => $v->user_id, $def_review_verdicts ) );
            $responded_sh  = count( $responded_ids );
        }
        $review_note = $review_sent && $active_def_review
            ? ( $responded_sh . ' of ' . $total_sh . ' responded' )
            : '';

        if ( ! empty( $def_pending_suggestions ) ) {
            $stage_alerts[] = count( $def_pending_suggestions ) . ' suggested edit' . ( count( $def_pending_suggestions ) > 1 ? 's' : '' ) . ' pending';
        }
        if ( $pending_feedback > 0 ) {
            $stage_alerts[] = $pending_feedback . ' feedback item' . ( $pending_feedback > 1 ? 's' : '' ) . ' pending';
        }

        $stage_checklist .= el_es_checklist_item( 'Transcript pasted & AI processed',           $has_transcript );
        $stage_checklist .= el_es_checklist_item( 'Definition saved (6 fields)',                 $has_definition );
        $stage_checklist .= el_es_checklist_item( 'Sent to client for review',                   $review_sent, $review_note );
        $stage_checklist .= el_es_checklist_item( 'All stakeholders responded',
            $responded_sh >= $total_sh && $total_sh > 0,
            $review_sent ? $review_note : ''
        );
        $stage_checklist .= el_es_checklist_item( 'Client approved definition',                  $client_approved );
        $stage_checklist .= el_es_checklist_item( 'Definition locked — ready to advance',        $def_locked );

        // Pending alerts
        if ( ! empty( $def_pending_suggestions ) ) {
            $stage_checklist .= '<div class="el-es-stage-alert">';
            $stage_checklist .= '<strong>' . count( $def_pending_suggestions ) . ' suggested edit(s) need your review</strong> — see definition below';
            $stage_checklist .= '</div>';
        }

        // Tools
        if ( $has_definition && ! $def_locked ) {
            if ( ! $review_sent ) {
                $stage_tools .= EL_Admin_UI::btn( [
                    'label'   => __( 'Send to Client for Review', 'el-core' ),
                    'variant' => 'primary',
                    'icon'    => 'email-alt',
                    'id'      => 'send-definition-review-btn',
                    'data'    => [ 'project-id' => $project_id ],
                ] );
            }
            $stage_tools .= ' ';
            $stage_tools .= EL_Admin_UI::btn( [
                'label'   => __( 'Lock Definition', 'el-core' ),
                'variant' => $client_approved ? 'primary' : 'secondary',
                'icon'    => 'lock',
                'id'      => 'lock-definition-btn',
                'data'    => [ 'project-id' => $project_id ],
            ] );
        }

        // Definition form (inline in stage panel)
        $def_status_badge_map = [
            'draft'          => [ 'label' => 'Draft',           'variant' => 'default'  ],
            'pending_review' => [ 'label' => 'Sent for Review', 'variant' => 'info'     ],
            'approved'       => [ 'label' => 'Client Approved', 'variant' => 'success'  ],
            'needs_revision' => [ 'label' => 'Needs Revision',  'variant' => 'warning'  ],
            'locked'         => [ 'label' => 'Locked',          'variant' => 'success'  ],
        ];
        $def_status_info = $def_status_badge_map[ $def_review_status ] ?? $def_status_badge_map['draft'];

        $def_fields = [
            'site_description' => [ 'label' => __( 'Site Description', 'el-core' ),   'type' => 'textarea', 'value' => $definition->site_description ?? '', 'help' => __( 'A brief overview of what this website will be.', 'el-core' ) ],
            'primary_goal'     => [ 'label' => __( 'Primary Goal', 'el-core' ),        'type' => 'textarea', 'value' => $definition->primary_goal ?? '',     'help' => __( 'The main objective this website should achieve.', 'el-core' ) ],
            'secondary_goals'  => [ 'label' => __( 'Secondary Goals', 'el-core' ),     'type' => 'textarea', 'value' => $definition->secondary_goals ?? '',  'help' => __( 'Additional objectives (one per line).', 'el-core' ) ],
            'target_customers' => [ 'label' => __( 'Target Customers', 'el-core' ),    'type' => 'textarea', 'value' => $definition->target_customers ?? '', 'help' => __( 'Who is this site designed to reach?', 'el-core' ) ],
            'user_types'       => [ 'label' => __( 'User Types', 'el-core' ),          'type' => 'textarea', 'value' => $definition->user_types ?? '',       'help' => __( 'Different types of users and their roles.', 'el-core' ) ],
            'site_type'        => [ 'label' => __( 'Site Type', 'el-core' ),           'type' => 'text',     'value' => $definition->site_type ?? '',         'help' => __( 'e.g., "E-commerce", "Educational Portal"', 'el-core' ) ],
        ];

        // Verdict summary if review active
        if ( $active_def_review && ! empty( $def_review_verdicts ) ) {
            $verdict_counts = [ 'approved' => 0, 'needs_revision' => 0 ];
            foreach ( $def_review_verdicts as $v ) {
                $verdict_counts[ $v->verdict ] = ( $verdict_counts[ $v->verdict ] ?? 0 ) + 1;
            }
            $stage_tools .= '<div class="el-es-verdict-summary-inline">';
            $stage_tools .= '<span class="el-es-vs-approved">' . (int)$verdict_counts['approved'] . ' fields approved</span>';
            $stage_tools .= '<span class="el-es-vs-revision">' . (int)$verdict_counts['needs_revision'] . ' need revision</span>';
            $stage_tools .= '<span class="el-es-vs-total">' . (int)array_sum($verdict_counts) . ' total responses</span>';
            $stage_tools .= '</div>';
        }

        // Pending suggestions
        if ( ! empty( $def_pending_suggestions ) ) {
            $field_labels = [
                'site_description' => 'Site Description', 'primary_goal' => 'Primary Goal',
                'secondary_goals' => 'Secondary Goals',   'target_customers' => 'Target Customers',
                'user_types' => 'User Types',             'site_type' => 'Site Type',
            ];
            $stage_tools .= '<div class="el-card el-es-suggestions-card" style="margin-top:16px;border-left:4px solid #f59e0b;">';
            $stage_tools .= '<div class="el-card__header"><h3 class="el-card__title">' . sprintf( __( 'Pending Suggested Edits (%d)', 'el-core' ), count( $def_pending_suggestions ) ) . '</h3></div>';
            $stage_tools .= '<div class="el-card__body">';
            foreach ( $def_pending_suggestions as $sg ) {
                $flabel = $field_labels[ $sg->field_key ] ?? $sg->field_key;
                $stage_tools .= '<div class="el-es-suggestion-row" id="suggestion-row-' . esc_attr( $sg->id ) . '" data-suggestion-id="' . esc_attr( $sg->id ) . '">';
                $stage_tools .= '<div class="el-es-suggestion-meta"><strong>' . esc_html( $flabel ) . '</strong> <span style="color:#9ca3af;font-size:12px;">— ' . esc_html( $sg->display_name ) . ', ' . date_i18n( 'M j, Y g:i A', strtotime( $sg->created_at ) ) . '</span></div>';
                $stage_tools .= '<div class="el-es-suggestion-diff">';
                $stage_tools .= '<div class="el-es-suggestion-diff-original"><span class="el-es-diff-label">' . __( 'Current', 'el-core' ) . '</span>' . nl2br( esc_html( $sg->original_text ) ) . '</div>';
                $stage_tools .= '<div class="el-es-suggestion-diff-proposed"><span class="el-es-diff-label">' . __( 'Proposed', 'el-core' ) . '</span>' . nl2br( esc_html( $sg->suggested_text ) ) . '</div>';
                $stage_tools .= '</div>';
                $stage_tools .= '<div class="el-es-suggestion-actions">';
                $stage_tools .= EL_Admin_UI::btn( [ 'label' => __( 'Accept', 'el-core' ), 'variant' => 'success', 'size' => 'small', 'data' => [ 'suggestion-id' => $sg->id, 'action-type' => 'accept' ], 'classes' => [ 'el-es-suggestion-action-btn' ] ] );
                $stage_tools .= ' ';
                $stage_tools .= EL_Admin_UI::btn( [ 'label' => __( 'Reject', 'el-core' ), 'variant' => 'danger',  'size' => 'small', 'data' => [ 'suggestion-id' => $sg->id, 'action-type' => 'reject' ], 'classes' => [ 'el-es-suggestion-action-btn' ] ] );
                $stage_tools .= '</div></div>';
            }
            $stage_tools .= '</div></div>';
        }

        // If locked show notice, else show locked banner
        if ( $is_locked ) {
            $locked_by = get_userdata( $definition->locked_by );
            $stage_tools .= EL_Admin_UI::notice( [
                'message' => sprintf( __( '<strong>Definition Locked</strong> — by %s on %s.', 'el-core' ),
                    $locked_by ? esc_html( $locked_by->display_name ) : 'Unknown',
                    date_i18n( 'M j, Y', strtotime( $definition->locked_at ) ) ),
                'type' => 'success',
            ] );
        } elseif ( ! $has_transcript ) {
            $has_transcript_val = esc_textarea( wp_unslash( $project->discovery_transcript ?? '' ) );
            $stage_tools .= '<div class="el-card" style="margin-top:16px;">';
            $stage_tools .= '<div class="el-card__header"><h3 class="el-card__title">' . __( 'Step 1 — Paste Meeting Transcript', 'el-core' ) . '</h3></div>';
            $stage_tools .= '<div class="el-card__body">';
            $stage_tools .= EL_Admin_UI::notice( [ 'message' => __( 'Paste your Fathom summary or any discovery call notes. AI will extract all definition fields.', 'el-core' ), 'type' => 'info' ] );
            $stage_tools .= '<textarea id="discovery-transcript" rows="10" style="width:100%;font-family:monospace;padding:10px;border:1px solid #ddd;border-radius:4px;">' . $has_transcript_val . '</textarea>';
            $stage_tools .= '<div style="margin-top:12px;">';
            $stage_tools .= EL_Admin_UI::btn( [ 'label' => __( 'Process with AI', 'el-core' ), 'variant' => 'primary', 'icon' => 'admin-generic', 'id' => 'process-transcript-btn', 'data' => [ 'project-id' => $project_id ] ] );
            $stage_tools .= '</div></div></div>';
        } else {
            $transcript_val = esc_textarea( wp_unslash( $project->discovery_transcript ?? '' ) );
            $stage_tools .= '<div class="el-card" style="margin-top:16px;">';
            $stage_tools .= '<div class="el-card__header" style="display:flex;justify-content:space-between;align-items:center;">';
            $stage_tools .= '<h3 class="el-card__title">' . __( 'Meeting Transcript', 'el-core' ) . '</h3>';
            if ( $project->discovery_extracted_at ) {
                $stage_tools .= '<span style="font-size:12px;color:#6b7280;">AI processed ' . date_i18n( 'M j, Y', strtotime( $project->discovery_extracted_at ) ) . '</span>';
            }
            $stage_tools .= '</div>';
            $stage_tools .= '<div class="el-card__body">';
            $stage_tools .= '<textarea id="discovery-transcript" rows="6" style="width:100%;font-family:monospace;padding:10px;border:1px solid #ddd;border-radius:4px;">' . $transcript_val . '</textarea>';
            $stage_tools .= '<div style="margin-top:10px;">';
            $stage_tools .= EL_Admin_UI::btn( [ 'label' => __( 'Re-process with AI', 'el-core' ), 'variant' => 'secondary', 'icon' => 'admin-generic', 'id' => 'process-transcript-btn', 'data' => [ 'project-id' => $project_id ] ] );
            $stage_tools .= '</div></div></div>';
        }

        // Definition form
        $def_form  = '<form id="project-definition-form" style="margin-top:16px;">';
        $def_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
        foreach ( $def_fields as $field_key => $field_cfg ) {
            $field_comments    = $def_review_comments[ $field_key ] ?? [];
            $field_verdict_data = array_filter( $def_review_verdicts ?? [], fn( $v ) => $v->field_key === $field_key );

            $def_form .= '<div class="el-es-def-field-wrap" data-field="' . esc_attr( $field_key ) . '">';
            if ( ! empty( $field_verdict_data ) ) {
                $n_approved = count( array_filter( $field_verdict_data, fn( $v ) => $v->verdict === 'approved' ) );
                $n_revision = count( array_filter( $field_verdict_data, fn( $v ) => $v->verdict === 'needs_revision' ) );
                $def_form .= '<div class="el-es-def-field-badges" style="margin-bottom:4px;">';
                if ( $n_approved ) $def_form .= EL_Admin_UI::badge( [ 'label' => $n_approved . ' ✓', 'variant' => 'success' ] ) . ' ';
                if ( $n_revision ) $def_form .= EL_Admin_UI::badge( [ 'label' => $n_revision . ' needs revision', 'variant' => 'warning' ] );
                $def_form .= '</div>';
            }
            $def_form .= EL_Admin_UI::form_row( [
                'name'     => $field_key,
                'label'    => $field_cfg['label'],
                'type'     => $field_cfg['type'],
                'value'    => $field_cfg['value'],
                'readonly' => $is_locked,
                'help'     => $field_cfg['help'],
            ] );
            if ( ! empty( $field_comments ) ) {
                $def_form .= '<div class="el-es-admin-comment-thread">';
                $def_form .= '<div class="el-es-admin-comment-thread-label">' . __( 'Stakeholder comments:', 'el-core' ) . '</div>';
                foreach ( $field_comments as $comment ) {
                    $commenter = get_userdata( $comment->user_id );
                    $def_form .= '<div class="el-es-admin-comment-item' . ( $comment->parent_id ? ' el-es-admin-comment-reply' : '' ) . '">';
                    $def_form .= '<div class="el-es-admin-comment-meta"><strong>' . esc_html( $commenter ? $commenter->display_name : 'User' ) . '</strong>';
                    $def_form .= ' <span class="el-es-admin-comment-date">' . date_i18n( 'M j g:i A', strtotime( $comment->created_at ) ) . '</span>';
                    if ( $comment->verdict ) {
                        $def_form .= ' ' . EL_Admin_UI::badge( [ 'label' => ucfirst( str_replace( '_', ' ', $comment->verdict ) ), 'variant' => $comment->verdict === 'approved' ? 'success' : 'warning' ] );
                    }
                    $def_form .= '</div>';
                    $def_form .= '<div class="el-es-admin-comment-body">' . esc_html( $comment->comment ) . '</div>';
                    if ( ! empty( $comment->replies ) ) {
                        foreach ( $comment->replies as $reply ) {
                            $replier = get_userdata( $reply->user_id );
                            $def_form .= '<div class="el-es-admin-comment-item el-es-admin-comment-reply">';
                            $def_form .= '<div class="el-es-admin-comment-meta"><strong>' . esc_html( $replier ? $replier->display_name : 'User' ) . '</strong>';
                            $def_form .= ' <span class="el-es-admin-comment-date">' . date_i18n( 'M j g:i A', strtotime( $reply->created_at ) ) . '</span></div>';
                            $def_form .= '<div class="el-es-admin-comment-body">' . esc_html( $reply->comment ) . '</div>';
                            $def_form .= '</div>';
                        }
                    }
                    $def_form .= '</div>';
                }
                $def_form .= '</div>';
            }
            $def_form .= '</div>';
        }
        if ( ! $is_locked ) {
            $def_form .= '<div class="el-form-row">';
            $def_form .= EL_Admin_UI::btn( [ 'label' => __( 'Save Definition', 'el-core' ), 'variant' => 'secondary', 'icon' => 'saved', 'type' => 'submit' ] );
            $def_form .= '</div>';
        }
        $def_form .= '</form>';

        $stage_tools .= EL_Admin_UI::card( [ 'title' => __( 'Project Definition', 'el-core' ) . ' ' . EL_Admin_UI::badge( [ 'label' => $def_status_info['label'], 'variant' => $def_status_info['variant'] ] ), 'icon' => 'edit-page', 'content' => $def_form ] );
        break;

    case 3: // Scope Lock
        $has_proposal  = ! empty( $proposals );
        $proposal_sent = ! empty( array_filter( $proposals, fn( $p ) => in_array( $p->status, [ 'sent', 'accepted' ], true ) ) );
        $scope_locked  = (bool) $project->scope_locked_at;

        $stage_checklist .= el_es_checklist_item( 'Create proposal from locked definition', $has_proposal );
        $stage_checklist .= el_es_checklist_item( 'Send proposal to Decision Maker',         $proposal_sent, $proposal_sent ? '' : 'client must accept to lock scope' );
        $stage_checklist .= el_es_checklist_item( 'Client accepts scope — scope locked',     $scope_locked || (bool)$accepted_proposal );

        if ( $accepted_proposal ) {
            $stage_tools .= EL_Admin_UI::notice( [
                'message' => sprintf( __( '<strong>Scope Accepted</strong> — Final price: $%s', 'el-core' ), number_format( (float)$accepted_proposal->final_price, 2 ) ),
                'type' => 'success',
            ] );
        }
        $stage_tools .= EL_Admin_UI::btn( [
            'label'   => __( 'New Proposal', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'plus-alt',
            'class'   => 'el-es-new-proposal-btn',
            'data'    => [ 'project-id' => $project_id ],
        ] );

        // Proposal table
        $prop_rows = [];
        foreach ( $proposals as $prop ) {
            $sv = match ( $prop->status ) { 'draft' => 'default', 'sent' => 'info', 'accepted' => 'success', 'declined' => 'error', default => 'default' };
            $pa  = '';
            if ( $prop->status === 'draft' ) {
                $pa .= EL_Admin_UI::btn( [ 'label' => __( 'Edit', 'el-core' ),   'variant' => 'ghost', 'icon' => 'edit',  'class' => 'el-es-edit-proposal-btn',   'data' => [ 'proposal-id' => $prop->id ] ] );
                $pa .= EL_Admin_UI::btn( [ 'label' => __( 'Send', 'el-core' ),   'variant' => 'ghost', 'icon' => 'email', 'class' => 'el-es-send-proposal-btn',   'data' => [ 'proposal-id' => $prop->id ] ] );
                $pa .= EL_Admin_UI::btn( [ 'label' => __( 'Delete', 'el-core' ), 'variant' => 'ghost', 'icon' => 'trash', 'class' => 'el-es-delete-proposal-btn', 'data' => [ 'proposal-id' => $prop->id ] ] );
            } elseif ( $prop->status === 'sent' ) {
                $pa .= EL_Admin_UI::btn( [ 'label' => __( 'Edit', 'el-core' ), 'variant' => 'ghost', 'icon' => 'edit', 'class' => 'el-es-edit-proposal-btn', 'data' => [ 'proposal-id' => $prop->id ] ] );
            }
            $prop_rows[] = [
                'number' => '<strong>' . esc_html( $prop->proposal_number ) . '</strong>',
                'title'  => esc_html( $prop->proposal_title ?: '—' ),
                'price'  => $prop->final_price > 0 ? '$' . number_format( (float)$prop->final_price, 2 ) : '—',
                'status' => EL_Admin_UI::badge( [ 'label' => ucfirst( $prop->status ), 'variant' => $sv ] ),
                '__actions' => $pa,
            ];
        }
        if ( ! empty( $prop_rows ) ) {
            $stage_tools .= EL_Admin_UI::data_table( [
                'columns' => [
                    [ 'key' => 'number', 'label' => __( '#', 'el-core' ) ],
                    [ 'key' => 'title',  'label' => __( 'Title', 'el-core' ) ],
                    [ 'key' => 'price',  'label' => __( 'Price', 'el-core' ) ],
                    [ 'key' => 'status', 'label' => __( 'Status', 'el-core' ) ],
                ],
                'rows' => $prop_rows,
            ] );
        }
        break;

    case 4: // Visual Identity
        $review_items  = $module->get_review_items( $project_id, 'mood_board' );
        $has_review    = ! empty( $review_items );
        $all_voted     = false;
        $brand_locked  = false;
        if ( $has_review ) {
            $latest = $review_items[0];
            $all_voted   = $latest->status === 'closed';
            $brand_locked = $all_voted;
        }

        $stage_checklist .= el_es_checklist_item( 'Create mood board review session',       $has_review );
        $stage_checklist .= el_es_checklist_item( 'All stakeholders vote on style direction', $all_voted, $has_review ? ( count( $review_items ) . ' session(s)' ) : '' );
        $stage_checklist .= el_es_checklist_item( 'Brand direction confirmed & locked',       $brand_locked );

        $stage_tools .= EL_Admin_UI::btn( [
            'label'   => __( 'Create Mood Board Session', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'plus-alt',
            'data'    => [ 'modal-open' => 'create-review-modal' ],
        ] );

        if ( $has_review ) {
            $stage_tools .= '<div style="margin-top:16px;" id="es-branding-tab" data-project-id="' . esc_attr( $project_id ) . '">';
            foreach ( $review_items as $ri ) {
                $is_closed = $ri->status === 'closed';
                $all_votes = $module->get_review_votes( (int)$ri->id );
                $voted_ids = array_map( fn( $v ) => (int)$v->user_id, $all_votes );
                $responded = count( array_filter( $stakeholders, fn( $s ) => in_array( (int)$s->user_id, $voted_ids, true ) ) );
                $total_sh2 = count( $stakeholders );

                $stage_tools .= '<div class="el-card" style="margin-bottom:16px;">';
                $stage_tools .= '<div class="el-card__header" style="display:flex;justify-content:space-between;align-items:center;">';
                $stage_tools .= '<h3 class="el-card__title">' . esc_html( $ri->title ) . '</h3>';
                $stage_tools .= EL_Admin_UI::badge( [ 'label' => $is_closed ? 'Closed' : 'Open', 'variant' => $is_closed ? 'success' : 'warning' ] );
                $stage_tools .= '</div><div class="el-card__body">';
                $stage_tools .= EL_Admin_UI::detail_row( [ 'label' => __( 'Responses', 'el-core' ), 'value' => $responded . ' of ' . $total_sh2 . ' team members', 'icon' => 'groups' ] );
                if ( $ri->deadline ) {
                    $stage_tools .= EL_Admin_UI::detail_row( [ 'label' => __( 'Deadline', 'el-core' ), 'value' => date_i18n( 'M j, Y', strtotime( $ri->deadline ) ), 'icon' => 'calendar-alt' ] );
                }
                if ( ! $is_closed ) {
                    $stage_tools .= '<div style="margin-top:10px;">';
                    $stage_tools .= EL_Admin_UI::btn( [
                        'label'  => $ri->deadline ? __( 'Extend Deadline', 'el-core' ) : __( 'Set Deadline', 'el-core' ),
                        'variant' => 'secondary', 'icon' => 'calendar-alt',
                        'data'   => [ 'action' => 'set-review-deadline', 'review-item-id' => $ri->id ],
                    ] );
                    $stage_tools .= '</div>';
                }
                $stage_tools .= '</div></div>';
            }
            $stage_tools .= '</div>';
        }
        break;

    default: // Stages 5–8: generic
        $stage_deliverables = $module->get_deliverables( $project_id, $current_stage );
        $stage_feedback_cur = array_filter( $feedback, fn( $f ) => (int)$f->stage === $current_stage );
        $pending_cur        = count( array_filter( $stage_feedback_cur, fn( $f ) => $f->status === 'pending' ) );

        $stage_checklist .= el_es_checklist_item( 'Deliverables uploaded for this stage',   count( $stage_deliverables ) > 0, count( $stage_deliverables ) . ' uploaded' );
        $stage_checklist .= el_es_checklist_item( 'Client feedback reviewed',                $pending_cur === 0 && count( $stage_feedback_cur ) > 0, $pending_cur > 0 ? $pending_cur . ' pending' : '' );

        $stage_tools .= EL_Admin_UI::btn( [
            'label'   => __( 'Add Deliverable', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'plus-alt',
            'data'    => [ 'modal-open' => 'add-deliverable-modal' ],
        ] );
}

// ── Stage panel "ready to advance" row ────────────────────────────────────
$stage_checklist .= '<div class="el-es-checklist-divider"></div>';
$stage_checklist .= '<div class="el-es-checklist-advance">';
$stage_checklist .= EL_Admin_UI::btn( [
    'label'   => sprintf( __( 'Advance to Stage %d →', 'el-core' ), min( $current_stage + 1, 8 ) ),
    'variant' => 'primary',
    'icon'    => 'arrow-right-alt',
    'data'    => [ 'modal-open' => 'advance-stage-modal' ],
] );
$stage_checklist .= '</div>';

// ── Build sidebar ──────────────────────────────────────────────────────────

// Project info
$sidebar_info  = EL_Admin_UI::detail_row( [ 'label' => __( 'Status', 'el-core' ),  'value' => ucfirst( $project->status ), 'icon' => 'marker' ] );
$sidebar_info .= EL_Admin_UI::detail_row( [ 'label' => __( 'Stage', 'el-core' ),   'value' => $current_stage . ' of 8 — ' . $module->get_stage_name( $current_stage ), 'icon' => 'flag' ] );
if ( $project->final_price > 0 ) {
    $sidebar_info .= EL_Admin_UI::detail_row( [ 'label' => __( 'Price', 'el-core' ), 'value' => '$' . number_format( $project->final_price, 2 ), 'icon' => 'money-alt' ] );
} elseif ( $project->budget_range_low > 0 ) {
    $sidebar_info .= EL_Admin_UI::detail_row( [ 'label' => __( 'Budget', 'el-core' ), 'value' => '$' . number_format( $project->budget_range_low, 0 ) . ' – $' . number_format( $project->budget_range_high, 0 ), 'icon' => 'money-alt' ] );
}
if ( $project->deadline ) {
    $is_overdue = strtotime( $project->deadline ) < time();
    $sidebar_info .= EL_Admin_UI::detail_row( [ 'label' => __( 'Deadline', 'el-core' ), 'value' => date_i18n( 'M j, Y', strtotime( $project->deadline ) ) . ( $is_overdue ? ' ⚠️' : '' ), 'icon' => 'calendar-alt' ] );
}
$sidebar_info .= EL_Admin_UI::detail_row( [ 'label' => __( 'Created', 'el-core' ), 'value' => date_i18n( 'M j, Y', strtotime( $project->created_at ) ), 'icon' => 'calendar' ] );
if ( $project->notes ) {
    $sidebar_info .= EL_Admin_UI::detail_row( [ 'label' => __( 'Notes', 'el-core' ), 'value' => wp_kses_post( nl2br( $project->notes ) ), 'icon' => 'editor-alignleft' ] );
}

// Team mini-list
$team_html = '';
if ( empty( $stakeholders ) ) {
    $team_html .= '<p class="el-es-sidebar-empty">No stakeholders yet.</p>';
} else {
    foreach ( $stakeholders as $sh ) {
        $user = get_userdata( $sh->user_id );
        if ( ! $user ) continue;
        $team_html .= '<div class="el-es-sidebar-person">';
        $team_html .= '<div class="el-es-sidebar-avatar">' . strtoupper( substr( $user->display_name, 0, 1 ) ) . '</div>';
        $team_html .= '<div class="el-es-sidebar-person-info">';
        $team_html .= '<div class="el-es-sidebar-person-name">' . esc_html( $user->display_name ) . '</div>';
        $team_html .= '<div class="el-es-sidebar-person-role">' . ( $sh->role === 'decision_maker' ? 'Decision Maker' : 'Contributor' ) . '</div>';
        $team_html .= '</div>';
        $team_html .= '</div>';
    }
}
$team_html .= '<div style="margin-top:10px;">';
$team_html .= EL_Admin_UI::btn( [ 'label' => __( 'Manage Team', 'el-core' ), 'variant' => 'ghost', 'icon' => 'groups', 'data' => [ 'modal-open' => 'add-stakeholder-modal' ] ] );
$team_html .= '</div>';

// Utilities (compact links)
$util_links = [
    [ 'label' => 'Deliverables',  'count' => count( $deliverables ),  'icon' => 'media-document', 'modal' => 'add-deliverable-modal',  'alert' => false ],
    [ 'label' => 'Feedback',      'count' => count( $feedback ),       'icon' => 'format-chat',    'modal' => null,                     'alert' => $pending_feedback > 0, 'badge' => $pending_feedback ?: null ],
    [ 'label' => 'Pages',         'count' => count( $pages ),          'icon' => 'admin-page',     'modal' => 'add-page-modal',         'alert' => false ],
    [ 'label' => 'Stage History', 'count' => count( $stage_history ),  'icon' => 'backup',         'modal' => null,                     'alert' => false ],
];

$utils_html = '<div class="el-es-utilities">';
foreach ( $util_links as $ul ) {
    $utils_html .= '<div class="el-es-utility-row">';
    $utils_html .= '<span class="el-es-utility-label">';
    $utils_html .= '<span class="dashicons dashicons-' . esc_attr( $ul['icon'] ) . '" style="font-size:14px;width:14px;height:14px;margin-right:6px;vertical-align:middle;color:var(--el-admin-gray);"></span>';
    $utils_html .= esc_html( $ul['label'] );
    $utils_html .= '</span>';
    $badge_v  = $ul['alert'] ? 'warning' : 'default';
    $badge_lbl = $ul['badge'] ?? $ul['count'];
    $utils_html .= EL_Admin_UI::badge( [ 'label' => (string)$badge_lbl, 'variant' => $badge_v ] );
    if ( $ul['modal'] ) {
        $utils_html .= ' <button type="button" class="el-es-utility-add" data-modal-open="' . esc_attr( $ul['modal'] ) . '" title="Add">+</button>';
    }
    $utils_html .= '</div>';
}
$utils_html .= '</div>';

// Stage history accordion (sidebar collapsed by default)
$history_html = '';
if ( ! empty( $stage_history ) ) {
    $history_html .= '<div class="el-es-history-list">';
    foreach ( array_slice( $stage_history, 0, 8 ) as $he ) {
        $history_html .= '<div class="el-es-history-item">';
        $history_html .= '<span class="el-es-history-stage">' . $module->get_stage_name( (int)$he->stage ) . '</span>';
        $history_html .= ' <span class="el-es-history-action ' . ( $he->action === 'approved' ? 'el-es-hist-approved' : 'el-es-hist-entered' ) . '">' . esc_html( $he->action ) . '</span>';
        $history_html .= '<span class="el-es-history-date">' . date_i18n( 'M j', strtotime( $he->created_at ) ) . '</span>';
        $history_html .= '</div>';
    }
    $history_html .= '</div>';
} else {
    $history_html = '<p class="el-es-sidebar-empty">No history yet.</p>';
}

// ── Feedback table (utility drawer, rendered below sidebar for full-width view)
$fb_rows = [];
foreach ( $feedback as $fb ) {
    $fb_user = get_userdata( $fb->user_id );
    $fb_rows[] = [
        'content' => '<div>' . wp_kses_post( wp_trim_words( $fb->content, 20 ) ) . '</div>',
        'stage'   => EL_Admin_UI::badge( [ 'label' => (int)$fb->stage . '. ' . $module->get_stage_name( (int)$fb->stage ), 'variant' => EL_Expand_Site_Module::get_stage_badge_variant( (int)$fb->stage ) ] ),
        'by'      => $fb_user ? esc_html( $fb_user->display_name ) : '—',
        'status'  => EL_Admin_UI::badge( [ 'label' => ucfirst( $fb->status ), 'variant' => match ( $fb->status ) { 'resolved' => 'success', 'acknowledged' => 'info', default => 'default' } ] ),
        'date'    => date_i18n( 'M j, Y', strtotime( $fb->created_at ) ),
        '__actions' => $fb->status === 'pending' ? ( EL_Admin_UI::btn( [ 'label' => 'Ack', 'variant' => 'ghost', 'class' => 'el-es-feedback-btn', 'data' => [ 'id' => $fb->id, 'status' => 'acknowledged' ] ] ) . EL_Admin_UI::btn( [ 'label' => 'Resolve', 'variant' => 'ghost', 'class' => 'el-es-feedback-btn', 'data' => [ 'id' => $fb->id, 'status' => 'resolved' ] ] ) ) : '',
    ];
}

// ── Deliverables table
$del_rows = [];
foreach ( $deliverables as $d ) {
    $del_rows[] = [
        'title'  => '<strong>' . esc_html( $d->title ) . '</strong>',
        'stage'  => EL_Admin_UI::badge( [ 'label' => (int)$d->stage . '. ' . EL_Expand_Site_Module::get_stage_name( (int)$d->stage ), 'variant' => EL_Expand_Site_Module::get_stage_badge_variant( (int)$d->stage ) ] ),
        'file'   => $d->file_url ? '<a href="' . esc_url( $d->file_url ) . '" target="_blank">View</a>' : '—',
        'status' => EL_Admin_UI::badge( [ 'label' => ucfirst( str_replace( '_', ' ', $d->review_status ) ), 'variant' => match ( $d->review_status ) { 'approved' => 'success', 'needs_revision' => 'warning', default => 'default' } ] ),
        '__actions' => EL_Admin_UI::btn( [ 'label' => 'Approve', 'variant' => 'ghost', 'icon' => 'yes',  'class' => 'el-es-review-btn', 'data' => [ 'id' => $d->id, 'status' => 'approved' ] ] )
                     . EL_Admin_UI::btn( [ 'label' => 'Revise',  'variant' => 'ghost', 'icon' => 'edit', 'class' => 'el-es-review-btn', 'data' => [ 'id' => $d->id, 'status' => 'needs_revision' ] ] ),
    ];
}

// ═══════════════════════════════════════════════════════════════════════
// RENDER
// ═══════════════════════════════════════════════════════════════════════
$html = '';

// Page header — minimal, project title + edit link
$html .= EL_Admin_UI::page_header( [
    'title'      => esc_html( $project->name ),
    'subtitle'   => esc_html( $project->client_name ),
    'back_url'   => admin_url( 'admin.php?page=el-core-projects' ),
    'back_label' => __( '← All Projects', 'el-core' ),
    'actions'    => [
        [
            'label'   => __( 'Edit Project Settings', 'el-core' ),
            'variant' => 'secondary',
            'icon'    => 'admin-settings',
            'url'     => admin_url( 'admin.php?page=el-core-projects&project=' . $project_id . '&action=edit' ),
        ],
    ],
] );

// ── Stage Pipeline Stepper ──────────────────────────────────────────────
$html .= '<div class="el-es-admin-pipeline">';
foreach ( $stages as $num => $stage ) {
    $state = 'upcoming';
    if ( $num < $current_stage )  $state = 'completed';
    if ( $num === $current_stage ) $state = 'current';

    $html .= '<div class="el-es-pipeline-step el-es-pipeline-' . $state . '">';
    $html .= '<div class="el-es-pipeline-dot">';
    if ( $state === 'completed' ) {
        $html .= '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>';
    } else {
        $html .= '<span>' . (int)$num . '</span>';
    }
    $html .= '</div>';
    $html .= '<div class="el-es-pipeline-label">' . esc_html( $stage['name'] ) . '</div>';
    if ( $num < 8 ) $html .= '<div class="el-es-pipeline-connector"></div>';
    $html .= '</div>';
}
$html .= '</div>';

// ── Two-column body ─────────────────────────────────────────────────────
$html .= '<div class="el-es-admin-body">';

// ─── LEFT: Stage panel ──────────────────────────────────────────────────
$alert_html = '';
if ( ! empty( $stage_alerts ) ) {
    foreach ( $stage_alerts as $alert_msg ) {
        $alert_html .= '<span class="el-es-panel-alert">' . esc_html( $alert_msg ) . '</span>';
    }
}

$html .= '<div class="el-es-stage-panel">';

// Panel header
$html .= '<div class="el-es-stage-panel-header">';
$html .= '<div class="el-es-stage-panel-title">';
$html .= '<span class="el-es-stage-panel-num">Stage ' . (int)$current_stage . '</span>';
$html .= '<span class="el-es-stage-panel-name">' . esc_html( $module->get_stage_name( $current_stage ) ) . '</span>';
$html .= '</div>';
if ( $alert_html ) $html .= '<div class="el-es-panel-alerts">' . $alert_html . '</div>';
$html .= '</div>';

// Checklist
$html .= '<div class="el-es-stage-checklist">';
$html .= '<div class="el-es-checklist-heading">Your checklist</div>';
$html .= $stage_checklist;
$html .= '</div>';

// Tools area
if ( $stage_tools ) {
    $html .= '<div class="el-es-stage-tools">';
    $html .= '<div class="el-es-tools-heading">Stage tools</div>';
    $html .= $stage_tools;
    $html .= '</div>';
}

$html .= '</div>'; // end stage panel

// ─── RIGHT: Sidebar ─────────────────────────────────────────────────────
$html .= '<div class="el-es-admin-sidebar">';

// Project info card
$html .= '<div class="el-es-sidebar-card">';
$html .= '<div class="el-es-sidebar-card-title">Project</div>';
$html .= $sidebar_info;
$html .= '</div>';

// Team card
$html .= '<div class="el-es-sidebar-card">';
$html .= '<div class="el-es-sidebar-card-title">Team (' . count( $stakeholders ) . ')</div>';
$html .= $team_html;
$html .= '</div>';

// Utilities card
$html .= '<div class="el-es-sidebar-card">';
$html .= '<div class="el-es-sidebar-card-title">Quick Access</div>';
$html .= $utils_html;
$html .= '</div>';

// Stage history card
$html .= '<div class="el-es-sidebar-card">';
$html .= '<div class="el-es-sidebar-card-title">Stage History</div>';
$html .= $history_html;
$html .= '</div>';

$html .= '</div>'; // end sidebar
$html .= '</div>'; // end two-column body

// ── Utility drawers (full-width, collapsed by default) ─────────────────
if ( ! empty( $fb_rows ) || ! empty( $del_rows ) ) {
    $html .= '<div class="el-es-utility-drawers">';

    // Feedback drawer
    $html .= '<details class="el-es-drawer" ' . ( $pending_feedback > 0 ? 'open' : '' ) . '>';
    $html .= '<summary class="el-es-drawer-summary">Client Feedback (' . count( $feedback ) . ')';
    if ( $pending_feedback > 0 ) $html .= ' ' . EL_Admin_UI::badge( [ 'label' => $pending_feedback . ' pending', 'variant' => 'warning' ] );
    $html .= '</summary>';
    $html .= '<div class="el-es-drawer-body">';
    $html .= EL_Admin_UI::data_table( [
        'columns' => [
            [ 'key' => 'content', 'label' => 'Feedback' ],
            [ 'key' => 'stage',   'label' => 'Stage' ],
            [ 'key' => 'by',      'label' => 'From' ],
            [ 'key' => 'status',  'label' => 'Status' ],
            [ 'key' => 'date',    'label' => 'Date' ],
        ],
        'rows'  => $fb_rows,
        'empty' => [ 'icon' => 'format-chat', 'title' => 'No feedback yet' ],
    ] );
    $html .= '</div></details>';

    // Deliverables drawer
    $html .= '<details class="el-es-drawer">';
    $html .= '<summary class="el-es-drawer-summary">All Deliverables (' . count( $deliverables ) . ')</summary>';
    $html .= '<div class="el-es-drawer-body">';
    $html .= EL_Admin_UI::btn( [ 'label' => __( 'Add Deliverable', 'el-core' ), 'variant' => 'secondary', 'icon' => 'plus-alt', 'data' => [ 'modal-open' => 'add-deliverable-modal' ] ] );
    $html .= EL_Admin_UI::data_table( [
        'columns' => [
            [ 'key' => 'title',  'label' => 'Deliverable' ],
            [ 'key' => 'stage',  'label' => 'Stage' ],
            [ 'key' => 'file',   'label' => 'File' ],
            [ 'key' => 'status', 'label' => 'Review' ],
        ],
        'rows'  => $del_rows,
        'empty' => [ 'icon' => 'media-document', 'title' => 'No deliverables yet' ],
    ] );
    $html .= '</div></details>';

    $html .= '</div>'; // end utility drawers
}

// ═══════════════════════════════════════════════════════════════════════
// ALL MODALS (unchanged, preserved at bottom)
// ═══════════════════════════════════════════════════════════════════════

// Advance Stage modal
$next_stage = min( $current_stage + 1, 8 );
$default_deadline_days = $module->get_stage_deadline_days( $next_stage );
$default_deadline = date( 'Y-m-d', strtotime( "+{$default_deadline_days} days" ) );
$advance_form  = '<form id="advance-stage-form">';
$advance_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$advance_form .= EL_Admin_UI::notice( [ 'message' => sprintf( __( 'This will approve <strong>Stage %d (%s)</strong> and advance to <strong>Stage %d (%s)</strong>.', 'el-core' ), $current_stage, $module->get_stage_name( $current_stage ), $next_stage, $module->get_stage_name( $next_stage ) ), 'type' => 'info' ] );
$advance_form .= EL_Admin_UI::form_row( [ 'name' => 'deadline', 'label' => __( 'Set Deadline for Next Stage', 'el-core' ), 'type' => 'date', 'value' => $default_deadline, 'help' => sprintf( __( 'Default: %d days from today', 'el-core' ), $default_deadline_days ) ] );
$advance_form .= EL_Admin_UI::form_row( [ 'name' => 'notes', 'label' => __( 'Approval Notes', 'el-core' ), 'type' => 'textarea', 'placeholder' => __( 'Optional notes...', 'el-core' ) ] );
$advance_form .= '<div class="el-form-row">' . EL_Admin_UI::btn( [ 'label' => __( 'Approve & Advance', 'el-core' ), 'variant' => 'primary', 'icon' => 'yes', 'type' => 'submit' ] ) . '</div>';
$advance_form .= '</form>';
$html .= EL_Admin_UI::modal( [ 'id' => 'advance-stage-modal', 'title' => __( 'Advance to Next Stage', 'el-core' ), 'content' => $advance_form ] );

// Add Deliverable modal
$del_form  = '<form id="add-deliverable-form">';
$del_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$del_form .= '<input type="hidden" name="stage" value="' . esc_attr( $current_stage ) . '">';
$del_form .= EL_Admin_UI::form_row( [ 'name' => 'title', 'label' => __( 'Title', 'el-core' ), 'required' => true, 'placeholder' => __( 'e.g., Homepage Wireframe', 'el-core' ) ] );
$del_form .= EL_Admin_UI::form_row( [ 'name' => 'description', 'label' => __( 'Description', 'el-core' ), 'type' => 'textarea' ] );
$del_form .= EL_Admin_UI::form_row( [ 'name' => 'file_url', 'label' => __( 'File URL', 'el-core' ), 'type' => 'url', 'placeholder' => 'https://' ] );
$del_form .= EL_Admin_UI::form_row( [ 'name' => 'file_type', 'label' => __( 'File Type', 'el-core' ), 'type' => 'select', 'options' => [ '' => 'Select type...', 'pdf' => 'PDF', 'image' => 'Image', 'link' => 'Link', 'document' => 'Document' ] ] );
$del_form .= '<div class="el-form-row">' . EL_Admin_UI::btn( [ 'label' => __( 'Add Deliverable', 'el-core' ), 'variant' => 'primary', 'icon' => 'plus-alt', 'type' => 'submit' ] ) . '</div>';
$del_form .= '</form>';
$html .= EL_Admin_UI::modal( [ 'id' => 'add-deliverable-modal', 'title' => __( 'Add Deliverable', 'el-core' ), 'content' => $del_form ] );

// Add Page modal
$page_form  = '<form id="add-page-form">';
$page_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$page_form .= EL_Admin_UI::form_row( [ 'name' => 'page_name', 'label' => __( 'Page Name', 'el-core' ), 'required' => true, 'placeholder' => __( 'e.g., Homepage', 'el-core' ) ] );
$page_form .= EL_Admin_UI::form_row( [ 'name' => 'page_url', 'label' => __( 'Page URL', 'el-core' ), 'type' => 'url', 'placeholder' => 'https://' ] );
$page_form .= EL_Admin_UI::form_row( [ 'name' => 'sort_order', 'label' => __( 'Sort Order', 'el-core' ), 'type' => 'number', 'value' => '0' ] );
$page_form .= '<div class="el-form-row">' . EL_Admin_UI::btn( [ 'label' => __( 'Add Page', 'el-core' ), 'variant' => 'primary', 'icon' => 'plus-alt', 'type' => 'submit' ] ) . '</div>';
$page_form .= '</form>';
$html .= EL_Admin_UI::modal( [ 'id' => 'add-page-modal', 'title' => __( 'Add Page', 'el-core' ), 'content' => $page_form ] );

// Add Stakeholder modal
$org_contacts_html = '';
$org_id = absint( $project->organization_id ?? 0 );
if ( $org_id && isset( $core ) && $core->organizations ) {
    $org_contacts = $core->organizations->get_contacts( $org_id );
    $existing_stakeholder_user_ids = array_map( fn( $s ) => (int) $s->user_id, $stakeholders );
    $available_contacts = array_filter( $org_contacts, fn( $c ) => $c->user_id > 0 && ! in_array( (int) $c->user_id, $existing_stakeholder_user_ids, true ) );
    if ( ! empty( $available_contacts ) ) {
        $org_contacts_html .= '<div style="margin-bottom:18px;">';
        $org_contacts_html .= '<p style="font-weight:600;margin:0 0 8px;font-size:13px;color:#374151;">' . __( 'Contacts from this organization:', 'el-core' ) . '</p>';
        $org_contacts_html .= '<div style="display:flex;flex-direction:column;gap:6px;">';
        foreach ( $available_contacts as $oc ) {
            $role_default = $oc->is_primary ? 'decision_maker' : 'contributor';
            $badge = $oc->is_primary ? ' <span style="font-size:10px;background:#dbeafe;color:#1d4ed8;padding:1px 6px;border-radius:9px;font-weight:600;">Primary</span>' : '';
            $org_contacts_html .= '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 10px;background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;">';
            $org_contacts_html .= '<div><strong style="font-size:13px;">' . esc_html( $oc->first_name . ' ' . $oc->last_name ) . '</strong>' . $badge;
            if ( $oc->title ) $org_contacts_html .= '<br><span style="font-size:12px;color:#6b7280;">' . esc_html( $oc->title ) . '</span>';
            $org_contacts_html .= '</div>';
            $org_contacts_html .= '<button type="button" class="el-btn el-btn-secondary el-quick-add-stakeholder-btn" style="font-size:12px;padding:4px 10px;" data-user-id="' . esc_attr( $oc->user_id ) . '" data-name="' . esc_attr( $oc->first_name . ' ' . $oc->last_name ) . '" data-role="' . esc_attr( $role_default ) . '" data-project-id="' . esc_attr( $project_id ) . '">' . __( 'Add', 'el-core' ) . '</button>';
            $org_contacts_html .= '</div>';
        }
        $org_contacts_html .= '</div><hr style="margin:14px 0;border:none;border-top:1px solid #e5e7eb;">';
        $org_contacts_html .= '</div>';
    }
}
$stakeholder_form  = '<form id="add-stakeholder-form">';
$stakeholder_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
if ( $org_contacts_html ) $stakeholder_form .= $org_contacts_html;
$stakeholder_form .= EL_Admin_UI::notice( [ 'message' => __( 'Search for an existing WordPress user or enter an email to create a new user account.', 'el-core' ), 'type' => 'info' ] );
$stakeholder_form .= '<div class="el-form-row"><label for="stakeholder-user-search" class="el-form-label">' . __( 'Search User', 'el-core' ) . '</label><div class="el-form-field"><input type="text" id="stakeholder-user-search" name="user_search" class="el-input" placeholder="' . esc_attr__( 'Start typing name or email...', 'el-core' ) . '"></div></div>';
$stakeholder_form .= '<div id="user-search-results" style="display:none;margin-bottom:15px;padding:10px;background:#f5f5f5;border-radius:4px;"></div>';
$stakeholder_form .= '<input type="hidden" name="user_id" id="selected-user-id">';
$stakeholder_form .= EL_Admin_UI::form_row( [ 'name' => 'new_user_email', 'label' => __( 'Or Create New User (Email)', 'el-core' ), 'type' => 'email', 'placeholder' => __( 'email@example.com', 'el-core' ) ] );
$stakeholder_form .= EL_Admin_UI::form_row( [ 'name' => 'new_user_first_name', 'label' => __( 'First Name', 'el-core' ), 'type' => 'text', 'placeholder' => __( 'John', 'el-core' ) ] );
$stakeholder_form .= EL_Admin_UI::form_row( [ 'name' => 'new_user_last_name', 'label' => __( 'Last Name', 'el-core' ), 'type' => 'text', 'placeholder' => __( 'Doe', 'el-core' ) ] );
$stakeholder_form .= EL_Admin_UI::form_row( [ 'name' => 'role', 'label' => __( 'Role', 'el-core' ), 'type' => 'select', 'options' => [ 'contributor' => __( 'Contributor (can provide input)', 'el-core' ), 'decision_maker' => __( 'Decision Maker (can approve/lock)', 'el-core' ) ] ] );
$stakeholder_form .= '<div class="el-form-row">' . EL_Admin_UI::btn( [ 'label' => __( 'Add Stakeholder', 'el-core' ), 'variant' => 'primary', 'icon' => 'plus-alt', 'type' => 'submit' ] ) . '</div>';
$stakeholder_form .= '</form>';
$html .= EL_Admin_UI::modal( [ 'id' => 'add-stakeholder-modal', 'title' => __( 'Add Stakeholder', 'el-core' ), 'content' => $stakeholder_form ] );

// Send Definition for Review modal
$send_review_form  = '<form id="send-definition-review-form">';
$send_review_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$send_review_form .= EL_Admin_UI::notice( [ 'message' => __( 'This will notify all stakeholders that the project definition is ready for their review.', 'el-core' ), 'type' => 'info' ] );
$send_review_form .= EL_Admin_UI::form_row( [ 'name' => 'deadline', 'label' => __( 'Response Deadline', 'el-core' ), 'type' => 'date', 'value' => date( 'Y-m-d', strtotime( '+7 days' ) ) ] );
$send_review_form .= '<div class="el-form-row">' . EL_Admin_UI::btn( [ 'label' => __( 'Send for Review', 'el-core' ), 'variant' => 'primary', 'icon' => 'email-alt', 'type' => 'submit' ] ) . '</div>';
$send_review_form .= '</form>';
$html .= EL_Admin_UI::modal( [ 'id' => 'send-definition-review-modal', 'title' => __( 'Send Definition for Client Review', 'el-core' ), 'content' => $send_review_form ] );

// Proposal edit modal
$edit_proposal_form  = '<form id="edit-proposal-form">';
$edit_proposal_form .= '<input type="hidden" name="proposal_id" id="edit-proposal-id" value="">';
$edit_proposal_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$edit_proposal_form .= '<div style="display:flex;gap:10px;margin-bottom:15px;">';
$edit_proposal_form .= EL_Admin_UI::btn( [ 'label' => __( 'Generate with AI', 'el-core' ), 'variant' => 'secondary', 'icon' => 'admin-generic', 'id' => 'generate-proposal-ai-btn', 'data' => [ 'project-id' => $project_id ] ] );
$edit_proposal_form .= '<span id="ai-proposal-status" style="line-height:36px;color:#666;"></span>';
$edit_proposal_form .= '</div>';
$edit_proposal_form .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;">';
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'proposal_title',      'label' => __( 'Proposal Title', 'el-core' ), 'required' => true, 'id' => 'prop-title' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'client_name',         'label' => __( 'Client Name', 'el-core' ),    'id' => 'prop-client-name' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'client_organization', 'label' => __( 'Organization', 'el-core' ),   'id' => 'prop-client-org' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'client_email',        'label' => __( 'Client Email', 'el-core' ),   'type' => 'email', 'id' => 'prop-client-email' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'project_dates',       'label' => __( 'Project Dates', 'el-core' ),  'placeholder' => 'e.g., March–May 2026', 'id' => 'prop-dates' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'project_location',    'label' => __( 'Location', 'el-core' ),       'id' => 'prop-location' ] );
$edit_proposal_form .= '</div>';
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_situation',     'label' => __( 'Situation', 'el-core' ),          'type' => 'textarea', 'id' => 'prop-situation',     'help' => __( 'Mirror the client\'s specific problem back to them.', 'el-core' ) ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_what_we_build', 'label' => __( 'What We\'re Building', 'el-core' ), 'type' => 'textarea', 'id' => 'prop-what-we-build', 'help' => __( 'Describe capabilities by user type.', 'el-core' ) ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_why_els',       'label' => __( 'Why ELS', 'el-core' ),             'type' => 'textarea', 'id' => 'prop-why-els',        'help' => __( 'Why Expanded Learning Solutions is the right partner.', 'el-core' ) ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_investment',    'label' => __( 'Investment', 'el-core' ),          'type' => 'textarea', 'id' => 'prop-investment',     'help' => __( 'Development cost + annual platform fee as monthly number.', 'el-core' ) ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_next_steps',    'label' => __( 'Next Steps', 'el-core' ),          'type' => 'textarea', 'id' => 'prop-next-steps',     'help' => __( 'Specific steps after acceptance.', 'el-core' ) ] );
$edit_proposal_form .= '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:15px;">';
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'budget_low',   'label' => __( 'Budget Low ($)', 'el-core' ),  'type' => 'number', 'id' => 'prop-budget-low' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'budget_high',  'label' => __( 'Budget High ($)', 'el-core' ), 'type' => 'number', 'id' => 'prop-budget-high' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'final_price',  'label' => __( 'Final Price ($)', 'el-core' ), 'type' => 'number', 'id' => 'prop-final-price' ] );
$edit_proposal_form .= '</div>';
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'payment_terms',    'label' => __( 'Payment Terms', 'el-core' ),     'type' => 'textarea', 'id' => 'prop-payment' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'terms_conditions', 'label' => __( 'Terms & Conditions', 'el-core' ), 'type' => 'textarea', 'id' => 'prop-terms' ] );
$edit_proposal_form .= '<div class="el-form-row">' . EL_Admin_UI::btn( [ 'label' => __( 'Save Proposal', 'el-core' ), 'variant' => 'primary', 'icon' => 'saved', 'type' => 'submit' ] ) . '</div>';
$edit_proposal_form .= '</form>';
$html .= EL_Admin_UI::modal( [ 'id' => 'edit-proposal-modal', 'title' => __( 'Edit Proposal', 'el-core' ), 'content' => $edit_proposal_form, 'size' => 'large' ] );

// Proposals JSON for JS
$proposals_json = [];
foreach ( $proposals as $prop ) {
    $proposals_json[ $prop->id ] = [
        'id' => $prop->id, 'proposal_title' => $prop->proposal_title, 'client_name' => $prop->client_name,
        'client_organization' => $prop->client_organization, 'client_email' => $prop->client_email,
        'project_dates' => $prop->project_dates, 'project_location' => $prop->project_location,
        'section_situation' => $prop->section_situation ?? '', 'section_what_we_build' => $prop->section_what_we_build ?? '',
        'section_why_els' => $prop->section_why_els ?? '', 'section_investment' => $prop->section_investment ?? '',
        'section_next_steps' => $prop->section_next_steps ?? '', 'budget_low' => $prop->budget_low,
        'budget_high' => $prop->budget_high, 'final_price' => $prop->final_price,
        'payment_terms' => $prop->payment_terms, 'terms_conditions' => $prop->terms_conditions, 'status' => $prop->status,
    ];
}
$html .= '<script>var elProposalsData = ' . wp_json_encode( $proposals_json ) . ';</script>';

// Create Review Session modal
$active_templates = $module->get_templates( [ 'is_active' => 1 ] );
$create_review_form  = '<form id="create-review-form">';
$create_review_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$create_review_form .= '<input type="hidden" name="review_type" value="mood_board">';
$create_review_form .= EL_Admin_UI::form_row( [ 'name' => 'title', 'label' => __( 'Session Title', 'el-core' ), 'type' => 'text', 'value' => __( 'Style Direction', 'el-core' ) ] );
$create_review_form .= EL_Admin_UI::form_row( [ 'name' => 'deadline', 'label' => __( 'Response Deadline (optional)', 'el-core' ), 'type' => 'date' ] );
$create_review_form .= '<div class="el-form-row"><label class="el-form-label">' . __( 'Select Templates for This Client', 'el-core' ) . '</label><div class="el-form-field">';
if ( empty( $active_templates ) ) {
    $create_review_form .= '<p style="color:#666;">' . __( 'No active templates. Add some in the Template Library first.', 'el-core' ) . '</p>';
} else {
    $tpl_by_cat = [];
    foreach ( $active_templates as $tpl ) { $tpl_by_cat[ $tpl->style_category ][] = $tpl; }
    $create_review_form .= '<div class="es-template-picker">';
    foreach ( $tpl_by_cat as $cat => $cat_tpls ) {
        $create_review_form .= '<div class="es-template-picker-category"><div class="es-template-picker-cat-label">' . esc_html( $cat ) . '</div><div class="es-template-picker-grid">';
        foreach ( $cat_tpls as $tpl ) {
            $img = esc_url( $tpl->image_url );
            $create_review_form .= '<label class="es-template-picker-card"><input type="checkbox" name="template_ids[]" value="' . esc_attr( $tpl->id ) . '">';
            $create_review_form .= $img ? '<img src="' . $img . '" alt="' . esc_attr( $tpl->title ) . '">' : '<div class="es-template-picker-no-img">No Image</div>';
            $create_review_form .= '<div class="es-template-picker-title">' . esc_html( $tpl->title ) . '</div></label>';
        }
        $create_review_form .= '</div></div>';
    }
    $create_review_form .= '</div>';
}
$create_review_form .= '</div></div>';
$create_review_form .= '<div class="el-form-row">' . EL_Admin_UI::btn( [ 'label' => __( 'Create Review Session', 'el-core' ), 'variant' => 'primary', 'icon' => 'plus-alt', 'type' => 'submit' ] ) . '</div>';
$create_review_form .= '</form>';
$html .= EL_Admin_UI::modal( [ 'id' => 'create-review-modal', 'title' => __( 'Create Mood Board Review Session', 'el-core' ), 'content' => $create_review_form ] );

echo EL_Admin_UI::wrap( $html );

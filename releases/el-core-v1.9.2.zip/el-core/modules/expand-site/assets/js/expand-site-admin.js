/**
 * Expand Site Module — Admin JavaScript
 * 
 * Handles project creation form submission via AJAX
 */

(function() {
    'use strict';

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        // Handle project creation form
        document.addEventListener('submit', handleProjectCreate);
    }

    function handleProjectCreate(e) {
        const form = e.target.closest('#create-project-form');
        if (!form) return;

        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn?.textContent || 'Create Project';

        // Gather form data
        const formData = new FormData(form);
        const data = {
            name: formData.get('name'),
            client_name: formData.get('client_name'),
            budget_range_low: formData.get('budget_range_low') || 0,
            budget_range_high: formData.get('budget_range_high') || 0,
            notes: formData.get('notes') || ''
        };

        // Validate required fields
        if (!data.name || !data.client_name) {
            alert('Project Name and Client Name are required.');
            return;
        }

        // Disable submit button
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Creating...';
        }

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_create_project');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('name', data.name);
        ajaxData.append('client_name', data.client_name);
        ajaxData.append('budget_range_low', data.budget_range_low);
        ajaxData.append('budget_range_high', data.budget_range_high);
        ajaxData.append('notes', data.notes);

        // Submit via AJAX using native fetch
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            
            // Success - redirect to project detail page
            if (result.data.project_id) {
                window.location.href = elExpandSiteAdmin.projectUrl.replace('PROJECT_ID', result.data.project_id);
            }
        })
        .catch(err => {
            alert(err.message || 'Failed to create project.');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
    }

})();

/**
 * Expand Site — Client Portal JavaScript
 *
 * Vanilla JS only. Uses ELCore.ajax(). Event delegation on document.
 * v1.14.0 - Added stage navigation
 * v1.14.1 - Modal-based UX for deliverables/feedback/definition
 */

(function() {
    'use strict';

    // ═══════════════════════════════════════════
    // MODALS — Open/Close
    // ═══════════════════════════════════════════

    // Open modal
    document.addEventListener('click', function(e) {
        const trigger = e.target.closest('.el-es-modal-trigger');
        if (!trigger) return;

        e.preventDefault();
        const modalId = trigger.dataset.modal;
        if (!modalId) return;

        const modal = document.getElementById(modalId);
        if (!modal) return;

        modal.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden'; // Prevent background scroll
    });

    // Close modal (close button or overlay click)
    document.addEventListener('click', function(e) {
        const closeBtn = e.target.closest('[data-close-modal]');
        if (!closeBtn) return;

        e.preventDefault();
        const modalId = closeBtn.dataset.closeModal;
        if (!modalId) return;

        const modal = document.getElementById(modalId);
        if (!modal) return;

        modal.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = ''; // Restore scroll
    });

    // Close modal on Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const openModal = document.querySelector('.el-es-modal[aria-hidden="false"]');
            if (openModal) {
                openModal.setAttribute('aria-hidden', 'true');
                document.body.style.overflow = '';
            }
        }
    });

    // ═══════════════════════════════════════════
    // STAGE NAVIGATION — Switch between stages
    // ═══════════════════════════════════════════

    document.addEventListener('click', function(e) {
        const stageBtn = e.target.closest('.el-es-stage-btn');
        if (!stageBtn || stageBtn.disabled) return;

        e.preventDefault();
        const targetStage = stageBtn.dataset.stage;
        if (!targetStage) return;

        // Update active button state
        const portal = stageBtn.closest('.el-es-portal');
        if (!portal) return;

        // Remove active class from all buttons
        portal.querySelectorAll('.el-es-stage-btn').forEach(btn => {
            btn.classList.remove('el-es-stage-active');
        });

        // Add active class to clicked button
        stageBtn.classList.add('el-es-stage-active');

        // Hide all stage content areas
        portal.querySelectorAll('.el-es-stage-content').forEach(content => {
            content.style.display = 'none';
        });

        // Show selected stage content
        const targetContent = portal.querySelector('.el-es-stage-content[data-stage="' + targetStage + '"]');
        if (targetContent) {
            targetContent.style.display = 'block';
            // Smooth scroll to content
            targetContent.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // Update URL hash (for bookmarking)
        history.replaceState(null, null, '#stage-' + targetStage);
    });

    // On page load, check for hash and activate that stage
    window.addEventListener('DOMContentLoaded', function() {
        const hash = window.location.hash;
        const match = hash.match(/#stage-(\d+)/);
        if (match) {
            const stage = match[1];
            const stageBtn = document.querySelector('.el-es-stage-btn[data-stage="' + stage + '"]');
            if (stageBtn && !stageBtn.disabled) {
                stageBtn.click();
            }
        }
    });

    // ═══════════════════════════════════════════
    // PAGE REVIEW — Approve / Request Revision
    // ═══════════════════════════════════════════

    document.addEventListener('click', function(e) {
        const approveBtn = e.target.closest('.el-es-approve-btn');
        const revisionBtn = e.target.closest('.el-es-revision-btn');
        const btn = approveBtn || revisionBtn;
        if (!btn) return;

        e.preventDefault();
        const pageId = btn.dataset.pageId;
        const status = btn.dataset.status;
        if (!pageId || !status) return;

        const container = btn.closest('.el-es-page-review');
        const statusEl = container?.querySelector('.el-es-page-status-msg');

        btn.disabled = true;

        ELCore.ajax('es_client_review_page', { page_id: pageId, status: status })
            .then(function(result) {
                if (statusEl) {
                    statusEl.textContent = result.message || (status === 'approved' ? 'Page approved!' : 'Revision requested.');
                    statusEl.style.display = 'block';
                    statusEl.className = 'el-es-page-status-msg el-notice el-notice-success';
                }
                const row = btn.closest('.el-es-page-row');
                if (row) {
                    const badge = row.querySelector('.el-es-page-status');
                    if (badge) {
                        badge.textContent = status === 'approved' ? 'Approved' : 'Needs revision';
                        badge.className = 'el-es-page-status el-es-status-' + status.replace(/_/g, '-');
                    }
                    btn.closest('.el-es-page-actions')?.remove();
                }
            })
            .catch(function(err) {
                if (statusEl) {
                    statusEl.textContent = err.message || 'Request failed.';
                    statusEl.style.display = 'block';
                    statusEl.className = 'el-es-page-status-msg el-notice el-notice-error';
                }
            })
            .finally(function() {
                btn.disabled = false;
            });
    });

    // ═══════════════════════════════════════════
    // FEEDBACK FORM — Submit
    // ═══════════════════════════════════════════

    document.addEventListener('submit', function(e) {
        const form = e.target.closest('.el-es-feedback-form-inner');
        if (!form) return;

        e.preventDefault();

        const wrapper = form.closest('.el-es-feedback-form');
        const statusEl = wrapper?.querySelector('.el-es-feedback-status');
        const submitBtn = form.querySelector('.el-es-feedback-submit');
        const originalText = submitBtn?.textContent;

        const projectId = wrapper?.dataset.projectId;
        const deliverableId = wrapper?.dataset.deliverableId;
        const content = form.querySelector('[name="content"]')?.value?.trim();
        const feedbackType = form.querySelector('[name="feedback_type"]')?.value;
        const stage = form.querySelector('[name="stage"]')?.value;

        if (!content) {
            if (statusEl) {
                statusEl.textContent = 'Feedback content is required.';
                statusEl.style.display = 'block';
                statusEl.className = 'el-es-feedback-status el-notice el-notice-error';
            }
            return;
        }

        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Submitting...';
        }
        if (statusEl) statusEl.style.display = 'none';

        const data = {
            project_id: projectId,
            stage: stage,
            feedback_type: feedbackType || 'revision',
            content: content
        };
        if (deliverableId && deliverableId !== '0') {
            data.deliverable_id = deliverableId;
        }

        ELCore.ajax('es_submit_feedback', data)
            .then(function(result) {
                if (statusEl) {
                    statusEl.textContent = result.message || 'Feedback submitted!';
                    statusEl.style.display = 'block';
                    statusEl.className = 'el-es-feedback-status el-notice el-notice-success';
                }
                form.reset();
            })
            .catch(function(err) {
                if (statusEl) {
                    statusEl.textContent = err.message || 'Failed to submit feedback.';
                    statusEl.style.display = 'block';
                    statusEl.className = 'el-es-feedback-status el-notice el-notice-error';
                }
            })
            .finally(function() {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText || 'Submit feedback';
                }
            });
    });

    // ═══════════════════════════════════════════
    // PROPOSAL ACCEPT / DECLINE
    // ═══════════════════════════════════════════

    document.addEventListener('click', function(e) {
        var acceptBtn = e.target.closest('.el-es-accept-proposal-btn');
        if (acceptBtn) {
            e.preventDefault();
            var proposalId = acceptBtn.dataset.proposalId;
            if (!proposalId) return;

            if (!confirm('Accept this proposal? This will finalize the scope of service and advance your project to the next stage.')) {
                return;
            }

            acceptBtn.disabled = true;
            acceptBtn.textContent = 'Accepting...';

            ELCore.ajax('es_accept_proposal', { proposal_id: proposalId })
                .then(function(result) {
                    alert(result.message || 'Proposal accepted!');
                    window.location.reload();
                })
                .catch(function(err) {
                    alert(err.message || 'Failed to accept proposal.');
                    acceptBtn.disabled = false;
                    acceptBtn.textContent = 'Accept Proposal';
                });
        }

        var declineBtn = e.target.closest('.el-es-decline-proposal-btn');
        if (declineBtn) {
            e.preventDefault();
            var proposalId = declineBtn.dataset.proposalId;
            if (!proposalId) return;

            if (!confirm('Decline this proposal? The agency will be notified and may send a revised proposal.')) {
                return;
            }

            declineBtn.disabled = true;
            declineBtn.textContent = 'Declining...';

            ELCore.ajax('es_decline_proposal', { proposal_id: proposalId })
                .then(function(result) {
                    alert(result.message || 'Proposal declined.');
                    window.location.reload();
                })
                .catch(function(err) {
                    alert(err.message || 'Failed to decline proposal.');
                    declineBtn.disabled = false;
                    declineBtn.textContent = 'Decline';
                });
        }
    });

})();

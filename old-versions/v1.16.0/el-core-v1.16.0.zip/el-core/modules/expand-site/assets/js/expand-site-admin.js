/**
 * Expand Site Module — Admin JavaScript
 * 
 * Handles project creation form submission via AJAX
 */

(function() {
    'use strict';

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function init() {
        // Handle project creation form
        document.addEventListener('submit', handleProjectCreate);
        
        // Handle stage advancement form
        document.addEventListener('submit', handleAdvanceStage);
        
        // Handle stakeholder forms
        document.addEventListener('submit', handleAddStakeholder);
        document.addEventListener('click', handleRemoveStakeholder);
        document.addEventListener('click', handleChangeRole);
        document.addEventListener('click', handleDeleteProject);
        
        // User search for stakeholder modal - use event delegation since modal is dynamic
        const debouncedSearch = debounce(handleUserSearch, 300);
        document.addEventListener('input', function(e) {
            if (e.target && e.target.id === 'stakeholder-user-search') {
                debouncedSearch(e);
            }
        });
        
        // Discovery transcript processing
        document.addEventListener('click', handleProcessTranscript);
        document.addEventListener('submit', handleSaveDefinition);
        document.addEventListener('click', handleLockDefinition);
        
        // Proposals
        document.addEventListener('click', handleNewProposal);
        document.addEventListener('click', handleEditProposal);
        document.addEventListener('submit', handleSaveProposalForm);
        document.addEventListener('click', handleSendProposal);
        document.addEventListener('click', handleDeleteProposal);
        document.addEventListener('click', handleGenerateProposalAI);
    }

    function handleProjectCreate(e) {
        const form = e.target.closest('#create-project-form');
        if (!form) return;

        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn?.textContent || 'Create Project';

        // Gather form data
        const formData = new FormData(form);
        const data = {
            name: formData.get('name'),
            client_name: formData.get('client_name'),
            budget_range_low: formData.get('budget_range_low') || 0,
            budget_range_high: formData.get('budget_range_high') || 0,
            notes: formData.get('notes') || ''
        };

        // Validate required fields
        if (!data.name || !data.client_name) {
            alert('Project Name and Client Name are required.');
            return;
        }

        // Disable submit button
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Creating...';
        }

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_create_project');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('name', data.name);
        ajaxData.append('client_name', data.client_name);
        ajaxData.append('budget_range_low', data.budget_range_low);
        ajaxData.append('budget_range_high', data.budget_range_high);
        ajaxData.append('notes', data.notes);

        // Submit via AJAX using native fetch
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            console.log('AJAX Response:', result);
            
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            
            // Success - redirect to project detail page
            // The project_id is nested at result.data.data.project_id
            const projectId = result.data?.data?.project_id || result.data?.project_id;
            console.log('Project ID:', projectId);
            
            if (projectId) {
                const redirectUrl = elExpandSiteAdmin.projectUrl.replace('PROJECT_ID', projectId);
                console.log('Redirecting to:', redirectUrl);
                window.location.href = redirectUrl;
            } else {
                alert('Project created but could not redirect. Please refresh the page.');
            }
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to create project.');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
    }

    function handleAdvanceStage(e) {
        const form = e.target.closest('#advance-stage-form');
        if (!form) return;

        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn?.textContent || 'Approve & Advance';

        // Gather form data
        const formData = new FormData(form);
        const data = {
            project_id: formData.get('project_id'),
            deadline: formData.get('deadline') || '',
            notes: formData.get('notes') || ''
        };

        // Disable submit button
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Advancing...';
        }

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_advance_stage');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('project_id', data.project_id);
        ajaxData.append('deadline', data.deadline);
        ajaxData.append('notes', data.notes);

        // Submit via AJAX
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            
            // Success - reload page to show new stage
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to advance stage.');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
    }

    function handleAddStakeholder(e) {
        const form = e.target.closest('#add-stakeholder-form');
        if (!form) return;

        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn?.textContent || 'Add Stakeholder';

        // Gather form data
        const formData = new FormData(form);
        const data = {
            project_id: formData.get('project_id'),
            user_id: formData.get('user_id') || 0,
            role: formData.get('role') || 'contributor',
            new_user_email: formData.get('new_user_email') || '',
            new_user_first_name: formData.get('new_user_first_name') || '',
            new_user_last_name: formData.get('new_user_last_name') || ''
        };

        // Validate: need either user_id or all three new user fields
        if (!data.user_id && (!data.new_user_email || !data.new_user_first_name || !data.new_user_last_name)) {
            alert('Please select an existing user or provide email, first name, and last name for a new user.');
            return;
        }

        // Disable submit button
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Adding...';
        }

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_add_stakeholder');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('project_id', data.project_id);
        ajaxData.append('user_id', data.user_id);
        ajaxData.append('role', data.role);
        ajaxData.append('new_user_email', data.new_user_email);
        ajaxData.append('new_user_first_name', data.new_user_first_name);
        ajaxData.append('new_user_last_name', data.new_user_last_name);

        // Submit via AJAX
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            
            // Success - reload page to show new stakeholder
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to add stakeholder.');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
    }

    function handleRemoveStakeholder(e) {
        const btn = e.target.closest('.el-es-remove-stakeholder-btn');
        if (!btn) return;

        e.preventDefault();

        // Check if button is disabled
        if (btn.classList.contains('disabled')) {
            const msg = btn.dataset.disabledMsg || 'This action is not available.';
            alert(msg);
            return;
        }

        if (!confirm('Are you sure you want to remove this stakeholder from the project?')) {
            return;
        }

        const stakeholderId = btn.dataset.stakeholderId;
        if (!stakeholderId) return;

        // Disable button
        btn.disabled = true;
        btn.textContent = 'Removing...';

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_remove_stakeholder');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('stakeholder_id', stakeholderId);

        // Submit via AJAX
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            
            // Success - reload page
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to remove stakeholder.');
            btn.disabled = false;
            btn.textContent = 'Remove';
        });
    }

    function handleChangeRole(e) {
        const btn = e.target.closest('.el-es-change-role-btn');
        if (!btn) return;

        e.preventDefault();

        // Check if button is disabled
        if (btn.classList.contains('disabled')) {
            const msg = btn.dataset.disabledMsg || 'This action is not available.';
            alert(msg);
            return;
        }

        const stakeholderId = btn.dataset.stakeholderId;
        const newRole = btn.dataset.newRole;
        if (!stakeholderId || !newRole) return;

        // Disable button
        btn.disabled = true;
        const originalText = btn.textContent;
        btn.textContent = 'Updating...';

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_change_stakeholder_role');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('stakeholder_id', stakeholderId);
        ajaxData.append('new_role', newRole);

        // Submit via AJAX
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            
            // Success - reload page
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to change role.');
            btn.disabled = false;
            btn.textContent = originalText;
        });
    }

    function handleUserSearch(e) {
        const input = e.target;
        const searchTerm = input.value.trim();
        const resultsDiv = document.getElementById('user-search-results');
        const userIdInput = document.getElementById('selected-user-id');

        console.log('User search triggered:', searchTerm);

        if (searchTerm.length < 2) {
            resultsDiv.style.display = 'none';
            return;
        }

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_search_users');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('search', searchTerm);

        console.log('Sending search request...');

        // Submit via AJAX
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            console.log('Search response:', result);
            
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            
            const users = result.data?.data?.users || result.data?.users || [];
            console.log('Found users:', users);
            
            if (users.length === 0) {
                resultsDiv.innerHTML = '<p style="margin: 0; color: #666;">No users found. Enter email below to create a new user.</p>';
                resultsDiv.style.display = 'block';
                return;
            }

            // Display results
            let html = '<p style="margin: 0 0 8px 0; font-weight: 600;">Select a user:</p>';
            users.forEach(user => {
                html += `<div style="padding: 8px; margin-bottom: 4px; background: white; border: 1px solid #ddd; border-radius: 3px; cursor: pointer;" 
                         class="user-search-result" data-user-id="${user.id}">
                    <strong>${user.name}</strong><br>
                    <small>${user.email}</small>
                </div>`;
            });
            resultsDiv.innerHTML = html;
            resultsDiv.style.display = 'block';

            // Add click handlers to results
            resultsDiv.querySelectorAll('.user-search-result').forEach(result => {
                result.addEventListener('click', function() {
                    const userId = this.dataset.userId;
                    const userName = this.querySelector('strong').textContent;
                    console.log('User selected:', userId, userName);
                    userIdInput.value = userId;
                    input.value = userName;
                    resultsDiv.style.display = 'none';
                });
            });
        })
        .catch(err => {
            console.error('Search error:', err);
            resultsDiv.innerHTML = '<p style="margin: 0; color: #d63638;">Search failed. Please try again.</p>';
            resultsDiv.style.display = 'block';
        });
    }

    function handleDeleteProject(e) {
        const btn = e.target.closest('.el-es-delete-project-btn');
        if (!btn) return;

        e.preventDefault();

        const projectId = btn.dataset.projectId;
        const projectName = btn.dataset.projectName;

        if (!projectId) return;

        if (!confirm(`Are you sure you want to delete "${projectName}"?\n\nThis will permanently delete:\n- The project\n- All stakeholders\n- All deliverables\n- All feedback\n- All pages\n- All stage history\n\nThis action cannot be undone.`)) {
            return;
        }

        // Disable button
        btn.disabled = true;
        const originalText = btn.textContent;
        btn.textContent = 'Deleting...';

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_delete_project');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('project_id', projectId);

        // Submit via AJAX
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            
            // Success - reload page
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to delete project.');
            btn.disabled = false;
            btn.textContent = originalText;
        });
    }

    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // ═══════════════════════════════════════════
    // DISCOVERY TRANSCRIPT & DEFINITION
    // ═══════════════════════════════════════════

    function handleProcessTranscript(e) {
        const btn = e.target.closest('#process-transcript-btn');
        if (!btn) return;

        e.preventDefault();

        const projectId = btn.dataset.projectId;
        const textarea = document.getElementById('discovery-transcript');
        const transcript = textarea ? textarea.value.trim() : '';

        if (!transcript) {
            alert('Please paste a transcript before processing.');
            return;
        }

        if (!confirm('This will process the transcript with AI and update the definition fields below. Continue?')) {
            return;
        }

        // Disable button
        btn.disabled = true;
        const originalText = btn.textContent;
        btn.textContent = 'Processing with AI...';

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_process_transcript');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('project_id', projectId);
        ajaxData.append('transcript', transcript);

        // Submit via AJAX
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }

            // Extract definition data from response
            const definition = result.data?.data?.definition || result.data?.definition;
            
            // Update form fields with extracted data
            if (definition) {
                const fields = ['site_description', 'primary_goal', 'secondary_goals', 'target_customers', 'user_types', 'site_type'];
                fields.forEach(field => {
                    const input = document.querySelector(`[name="${field}"]`);
                    if (input && definition[field]) {
                        input.value = definition[field];
                    }
                });
            }

            alert('Transcript processed successfully! Review the extracted data below and make any needed edits.');
            
            // Re-enable button
            btn.disabled = false;
            btn.textContent = originalText;
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to process transcript. Please try again or enter data manually.');
            btn.disabled = false;
            btn.textContent = originalText;
        });
    }

    function handleSaveDefinition(e) {
        const form = e.target.closest('#project-definition-form');
        if (!form) return;

        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn?.textContent || 'Save Definition';

        // Gather form data
        const formData = new FormData(form);
        const data = {
            project_id: formData.get('project_id'),
            site_description: formData.get('site_description') || '',
            primary_goal: formData.get('primary_goal') || '',
            secondary_goals: formData.get('secondary_goals') || '',
            target_customers: formData.get('target_customers') || '',
            user_types: formData.get('user_types') || '',
            site_type: formData.get('site_type') || ''
        };

        // Disable submit button
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Saving...';
        }

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_save_definition');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        Object.keys(data).forEach(key => {
            ajaxData.append(key, data[key]);
        });

        // Submit via AJAX
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }

            alert('Definition saved successfully!');
            
            // Re-enable button
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to save definition.');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
    }

    function handleLockDefinition(e) {
        const btn = e.target.closest('#lock-definition-btn');
        if (!btn) return;

        e.preventDefault();

        const projectId = btn.dataset.projectId;

        if (!confirm('Are you sure you want to lock this definition?\n\nOnce locked, it cannot be edited. This confirms the project scope is finalized.')) {
            return;
        }

        // Disable button
        btn.disabled = true;
        const originalText = btn.textContent;
        btn.textContent = 'Locking...';

        // Build FormData for WordPress AJAX
        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_lock_definition');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('project_id', projectId);

        // Submit via AJAX
        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }

            // Success - reload page to show locked state
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to lock definition.');
            btn.disabled = false;
            btn.textContent = originalText;
        });
    }

    // ═══════════════════════════════════════════
    // PROPOSALS
    // ═══════════════════════════════════════════

    function handleNewProposal(e) {
        const btn = e.target.closest('.el-es-new-proposal-btn');
        if (!btn) return;
        e.preventDefault();

        const projectId = btn.dataset.projectId;
        if (!projectId) return;

        btn.disabled = true;
        const originalText = btn.textContent;
        btn.textContent = 'Creating...';

        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_create_proposal');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('project_id', projectId);

        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to create proposal.');
            btn.disabled = false;
            btn.textContent = originalText;
        });
    }

    function handleEditProposal(e) {
        const btn = e.target.closest('.el-es-edit-proposal-btn');
        if (!btn) return;
        e.preventDefault();

        const proposalId = btn.dataset.proposalId;
        if (!proposalId || typeof elProposalsData === 'undefined') return;

        const data = elProposalsData[proposalId];
        if (!data) return;

        // Populate modal form
        const fields = {
            'edit-proposal-id': data.id,
            'prop-title': data.proposal_title,
            'prop-client-name': data.client_name,
            'prop-client-org': data.client_organization,
            'prop-client-email': data.client_email,
            'prop-dates': data.project_dates,
            'prop-location': data.project_location,
            'prop-situation': data.section_situation,
            'prop-what-we-build': data.section_what_we_build,
            'prop-why-els': data.section_why_els,
            'prop-investment': data.section_investment,
            'prop-next-steps': data.section_next_steps,
            'prop-budget-low': data.budget_low,
            'prop-budget-high': data.budget_high,
            'prop-final-price': data.final_price,
            'prop-payment': data.payment_terms,
            'prop-terms': data.terms_conditions,
        };

        Object.keys(fields).forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = fields[id] || '';
        });

        // Open the modal
        const modal = document.getElementById('edit-proposal-modal');
        if (modal) {
            modal.style.display = 'flex';
            modal.classList.add('el-modal--active');
        }
    }

    function handleSaveProposalForm(e) {
        const form = e.target.closest('#edit-proposal-form');
        if (!form) return;
        e.preventDefault();

        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn?.textContent || 'Save Proposal';

        const formData = new FormData(form);
        const proposalId = formData.get('proposal_id');

        if (!proposalId) {
            alert('No proposal selected.');
            return;
        }

        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Saving...';
        }

        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_save_proposal');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);

        for (const [key, value] of formData.entries()) {
            ajaxData.append(key, value);
        }

        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to save proposal.');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }
        });
    }

    function handleSendProposal(e) {
        const btn = e.target.closest('.el-es-send-proposal-btn');
        if (!btn) return;
        e.preventDefault();

        const proposalId = btn.dataset.proposalId;
        if (!proposalId) return;

        if (!confirm('Mark this proposal as sent to the client?\n\nThe client will be able to view, accept, or decline it in their portal.')) {
            return;
        }

        btn.disabled = true;
        btn.textContent = 'Sending...';

        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_send_proposal');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('proposal_id', proposalId);

        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to send proposal.');
            btn.disabled = false;
            btn.textContent = 'Send';
        });
    }

    function handleDeleteProposal(e) {
        const btn = e.target.closest('.el-es-delete-proposal-btn');
        if (!btn) return;
        e.preventDefault();

        const proposalId = btn.dataset.proposalId;
        if (!proposalId) return;

        if (!confirm('Delete this proposal? This cannot be undone.')) {
            return;
        }

        btn.disabled = true;
        btn.textContent = 'Deleting...';

        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_delete_proposal');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('proposal_id', proposalId);

        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }
            window.location.reload();
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to delete proposal.');
            btn.disabled = false;
            btn.textContent = 'Delete';
        });
    }

    function handleGenerateProposalAI(e) {
        const btn = e.target.closest('#generate-proposal-ai-btn');
        if (!btn) return;
        e.preventDefault();

        const projectId = btn.dataset.projectId;
        if (!projectId) return;

        if (!confirm('Generate proposal content using AI?\n\nThis will use the locked project definition and discovery transcript to draft the proposal fields.')) {
            return;
        }

        btn.disabled = true;
        const originalText = btn.textContent;
        btn.textContent = 'Generating...';

        const statusEl = document.getElementById('ai-proposal-status');
        if (statusEl) statusEl.textContent = 'AI is generating proposal content...';

        const ajaxData = new FormData();
        ajaxData.append('action', 'el_core_action');
        ajaxData.append('el_action', 'es_generate_proposal_ai');
        ajaxData.append('nonce', elExpandSiteAdmin.nonce);
        ajaxData.append('project_id', projectId);

        fetch(elExpandSiteAdmin.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: ajaxData
        })
        .then(response => response.json())
        .then(result => {
            if (!result.success) {
                throw new Error(result.data?.message || 'Request failed');
            }

            const rd = result.data?.data || result.data;
            if (rd) {
                const narrativeMap = {
                    'situation': 'prop-situation',
                    'what_we_are_building': 'prop-what-we-build',
                    'why_els': 'prop-why-els',
                    'investment': 'prop-investment',
                    'next_steps': 'prop-next-steps',
                };

                Object.keys(narrativeMap).forEach(key => {
                    const el = document.getElementById(narrativeMap[key]);
                    if (el) el.value = rd[key] || '';
                });
            }

            if (statusEl) statusEl.textContent = 'Content generated! Review and edit as needed.';
            btn.disabled = false;
            btn.textContent = originalText;
        })
        .catch(err => {
            console.error('AJAX Error:', err);
            alert(err.message || 'Failed to generate proposal content.');
            if (statusEl) statusEl.textContent = '';
            btn.disabled = false;
            btn.textContent = originalText;
        });
    }

})();

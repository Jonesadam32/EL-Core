<?php
/**
 * Admin View: Expand Site — Project Detail
 *
 * Two-layer layout:
 *   Layer 1 — Utility tabs (Overview, Stakeholders, Stage History)
 *   Layer 2 — Phase bar (8 phases) + phase content panels
 *
 * Uses EL_Admin_UI components for all rendering.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$module     = EL_Expand_Site_Module::instance();
$core       = EL_Core::instance();
$project_id = absint( $_GET['project'] ?? 0 );
$project    = $module->get_project( $project_id );

if ( ! $project ) {
    echo EL_Admin_UI::wrap(
        EL_Admin_UI::notice( [ 'message' => __( 'Project not found.', 'el-core' ), 'type' => 'error' ] )
    );
    return;
}

$stage_history  = $module->get_stage_history( $project_id );
$deliverables   = $module->get_deliverables( $project_id );
$feedback       = $module->get_feedback( $project_id );
$pages          = $module->get_pages( $project_id );
$change_orders  = $module->get_change_orders( $project_id );
$stakeholders   = $module->get_stakeholders( $project_id );
$definition     = $module->get_project_definition( $project_id );
$proposals      = $module->get_proposals( $project_id );
$current_stage  = (int) $project->current_stage;

// Discovery / review data (needed by multiple panels)
$review_status = ( $definition && isset( $definition->review_status ) ) ? $definition->review_status : 'draft';
$active_review = $module->get_active_definition_review( $project_id );
$reviews       = $module->get_definition_reviews( $project_id );
$comments      = $active_review ? $module->get_definition_comments( (int) $active_review->id ) : [];
$verdicts      = $active_review ? $module->get_definition_verdicts( (int) $active_review->id ) : [];
$is_locked     = $definition && $definition->locked_at;

$pending_feedback = count( array_filter( $feedback, fn( $f ) => $f->status === 'pending' ) );

$html = '';

// ═══════════════════════════════════════════
// PAGE HEADER
// ═══════════════════════════════════════════

$html .= EL_Admin_UI::page_header( [
    'title'      => esc_html( $project->name ),
    'subtitle'   => esc_html( $project->client_name ),
    'back_url'   => admin_url( 'admin.php?page=el-core-projects' ),
    'back_label' => __( '← All Projects', 'el-core' ),
    'actions'    => [
        [
            'label'   => __( 'Edit Project', 'el-core' ),
            'variant' => 'secondary',
            'icon'    => 'edit',
            'url'     => admin_url( 'admin.php?page=el-core-projects&project=' . $project_id . '&action=edit' ),
        ],
        [
            'label'   => __( 'Advance Stage', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'arrow-right-alt',
            'data'    => [ 'modal-open' => 'advance-stage-modal' ],
        ],
    ],
] );

// ═══════════════════════════════════════════
// STATS GRID
// ═══════════════════════════════════════════

$html .= EL_Admin_UI::stats_grid( [
    [
        'icon'    => 'flag',
        'number'  => $current_stage . '/9',
        'label'   => $module->get_stage_name( $current_stage ),
        'variant' => EL_Expand_Site_Module::get_stage_badge_variant( $current_stage ),
    ],
    [
        'icon'    => 'update',
        'number'  => ucfirst( $project->status ),
        'label'   => __( 'Status', 'el-core' ),
        'variant' => EL_Expand_Site_Module::get_status_badge_variant( $project->status ),
    ],
    [
        'icon'    => 'media-document',
        'number'  => count( $deliverables ),
        'label'   => __( 'Deliverables', 'el-core' ),
        'variant' => 'info',
    ],
    [
        'icon'    => 'format-chat',
        'number'  => $pending_feedback,
        'label'   => __( 'Pending Feedback', 'el-core' ),
        'variant' => $pending_feedback > 0 ? 'warning' : 'success',
    ],
] );

// ═══════════════════════════════════════════
// LAYER 1 — UTILITY TABS
// ═══════════════════════════════════════════

$html .= EL_Admin_UI::tab_nav( [
    'group' => 'util-tabs',
    'tabs'  => [
        [ 'id' => 'util-overview',     'label' => __( 'Overview', 'el-core' ),      'icon' => 'dashboard',  'active' => true ],
        [ 'id' => 'util-stakeholders', 'label' => __( 'Stakeholders', 'el-core' ),  'icon' => 'groups',     'badge' => count( $stakeholders ) ],
        [ 'id' => 'util-history',      'label' => __( 'Stage History', 'el-core' ), 'icon' => 'backup' ],
    ],
] );

// ── Utility Tab: Overview ──
$overview = '';
$overview .= EL_Admin_UI::detail_row( [ 'label' => __( 'Client', 'el-core' ),        'value' => esc_html( $project->client_name ), 'icon' => 'businessperson' ] );
$overview .= EL_Admin_UI::detail_row( [ 'label' => __( 'Current Phase', 'el-core' ),  'value' => $current_stage . '. ' . $module->get_stage_name( $current_stage ), 'icon' => 'flag' ] );
$overview .= EL_Admin_UI::detail_row( [ 'label' => __( 'Status', 'el-core' ),         'value' => ucfirst( $project->status ), 'icon' => 'marker' ] );

if ( $project->final_price > 0 ) {
    $overview .= EL_Admin_UI::detail_row( [ 'label' => __( 'Final Price', 'el-core' ), 'value' => '$' . number_format( $project->final_price, 2 ), 'icon' => 'money-alt' ] );
} elseif ( $project->budget_range_low > 0 || $project->budget_range_high > 0 ) {
    $overview .= EL_Admin_UI::detail_row( [
        'label' => __( 'Budget Range', 'el-core' ),
        'value' => '$' . number_format( $project->budget_range_low, 0 ) . ' – $' . number_format( $project->budget_range_high, 0 ),
        'icon'  => 'money-alt',
    ] );
}

if ( $project->scope_locked_at ) {
    $overview .= EL_Admin_UI::detail_row( [ 'label' => __( 'Scope Locked', 'el-core' ), 'value' => date_i18n( 'M j, Y g:i A', strtotime( $project->scope_locked_at ) ), 'icon' => 'lock' ] );
}

$overview .= EL_Admin_UI::detail_row( [ 'label' => __( 'Created', 'el-core' ), 'value' => date_i18n( 'M j, Y', strtotime( $project->created_at ) ), 'icon' => 'calendar' ] );

if ( $project->notes ) {
    $overview .= EL_Admin_UI::detail_row( [ 'label' => __( 'Notes', 'el-core' ), 'value' => wp_kses_post( nl2br( $project->notes ) ), 'icon' => 'editor-alignleft' ] );
}

if ( ! empty( $change_orders ) ) {
    $co_total = array_sum( array_map( fn( $co ) => (float) $co->change_order_price, $change_orders ) );
    $overview .= EL_Admin_UI::notice( [
        'message' => sprintf(
            __( '<strong>%d change order(s)</strong> totaling <strong>$%s</strong>', 'el-core' ),
            count( $change_orders ),
            number_format( $co_total, 2 )
        ),
        'type' => 'warning',
    ] );
}

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'util-overview',
    'group'   => 'util-tabs',
    'content' => EL_Admin_UI::card( [ 'title' => __( 'Project Details', 'el-core' ), 'icon' => 'info-outline', 'content' => $overview ] ),
    'active'  => true,
] );

// ── Utility Tab: Stakeholders ──
$stakeholder_rows = [];
foreach ( $stakeholders as $sh ) {
    $user = get_userdata( $sh->user_id );
    if ( ! $user ) continue;

    $has_contact_record = false;
    global $wpdb;
    $contacts_table = $wpdb->prefix . 'el_contacts';
    $ct_exists = $wpdb->get_var( "SHOW TABLES LIKE '{$contacts_table}'" );
    if ( $ct_exists ) {
        $has_contact_record = (bool) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$contacts_table} WHERE user_id = %d",
            $sh->user_id
        ) );
    }

    $role_badge = EL_Admin_UI::badge( [
        'label'   => $sh->role === 'decision_maker' ? __( 'Decision Maker', 'el-core' ) : __( 'Contributor', 'el-core' ),
        'variant' => $sh->role === 'decision_maker' ? 'success' : 'info',
    ] );

    $actions = '';
    $dm_count         = count( array_filter( $stakeholders, fn( $s ) => $s->role === 'decision_maker' ) );
    $stakeholder_count = count( $stakeholders );

    $new_role  = $sh->role === 'decision_maker' ? 'c' : 'dm';
    $btn_label = $sh->role === 'decision_maker' ? __( 'Make Contributor', 'el-core' ) : __( 'Make Decision Maker', 'el-core' );
    $is_only_dm = ( $sh->role === 'decision_maker' && $dm_count === 1 );

    $actions .= EL_Admin_UI::btn( [
        'label'   => $btn_label,
        'variant' => 'ghost',
        'icon'    => 'update',
        'class'   => 'el-es-change-role-btn' . ( $is_only_dm ? ' disabled' : '' ),
        'data'    => [
            'stakeholder-id' => $sh->id,
            'new-role'       => $new_role,
            'disabled-msg'   => $is_only_dm ? __( 'Promote another stakeholder to Decision Maker first', 'el-core' ) : '',
        ],
    ] );

    $cannot_remove = ( $stakeholder_count === 1 ) || ( $sh->role === 'decision_maker' && $dm_count === 1 );
    $remove_msg    = '';
    if ( $stakeholder_count === 1 ) {
        $remove_msg = __( 'Cannot remove the only stakeholder', 'el-core' );
    } elseif ( $sh->role === 'decision_maker' && $dm_count === 1 ) {
        $remove_msg = __( 'Promote another stakeholder to Decision Maker first', 'el-core' );
    }

    $actions .= EL_Admin_UI::btn( [
        'label'   => __( 'Remove', 'el-core' ),
        'variant' => 'ghost',
        'icon'    => 'no',
        'class'   => 'el-es-remove-stakeholder-btn' . ( $cannot_remove ? ' disabled' : '' ),
        'data'    => [
            'stakeholder-id' => $sh->id,
            'disabled-msg'   => $remove_msg,
        ],
    ] );

    if ( current_user_can( 'manage_options' ) ) {
        $switch_url = add_query_arg( [
            'action'   => 'switch_to_user',
            'user_id'  => $user->ID,
            '_wpnonce' => wp_create_nonce( 'switch_to_user_' . $user->ID ),
        ], admin_url( 'admin.php' ) );

        $actions .= EL_Admin_UI::btn( [
            'label'   => __( 'Login As', 'el-core' ),
            'variant' => 'ghost',
            'icon'    => 'admin-users',
            'url'     => $switch_url,
        ] );
    }

    $stakeholder_rows[] = [
        'user'   => '<strong>' . esc_html( $user->display_name ) . '</strong><br><small>' . esc_html( $user->user_email ) . '</small>'
            . ( ! $has_contact_record ? '<br><span style="color:#d97706;font-size:0.75rem;">⚠ Not linked to a contact — won\'t see Client Dashboard. Add them as a contact in EL Core → Clients.</span>' : '' ),
        'role'   => $role_badge,
        'added'  => date_i18n( 'M j, Y', strtotime( $sh->added_at ) ),
        '__actions' => $actions,
    ];
}

$stakeholders_content = EL_Admin_UI::data_table( [
    'columns' => [
        [ 'key' => 'user',  'label' => __( 'User', 'el-core' ) ],
        [ 'key' => 'role',  'label' => __( 'Role', 'el-core' ) ],
        [ 'key' => 'added', 'label' => __( 'Added', 'el-core' ) ],
    ],
    'rows'  => $stakeholder_rows,
    'empty' => [
        'icon'    => 'groups',
        'title'   => __( 'No stakeholders yet', 'el-core' ),
        'message' => __( 'Add stakeholders to give clients access to this project.', 'el-core' ),
        'action'  => [ 'label' => __( 'Add Stakeholder', 'el-core' ), 'variant' => 'primary', 'data' => [ 'modal-open' => 'add-stakeholder-modal' ] ],
    ],
] );

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'util-stakeholders',
    'group'   => 'util-tabs',
    'content' => EL_Admin_UI::card( [
        'title'   => __( 'Project Stakeholders', 'el-core' ),
        'icon'    => 'groups',
        'content' => $stakeholders_content,
        'actions' => [
            [ 'label' => __( 'Add Stakeholder', 'el-core' ), 'variant' => 'secondary', 'icon' => 'plus-alt', 'data' => [ 'modal-open' => 'add-stakeholder-modal' ] ],
        ],
    ] ),
    'active'  => false,
] );

// ── Utility Tab: Stage History ──
$history_rows = [];
foreach ( $stage_history as $entry ) {
    $action_badge = EL_Admin_UI::badge( [
        'label'   => ucfirst( $entry->action ),
        'variant' => match ( $entry->action ) {
            'approved' => 'success',
            'rejected' => 'error',
            default    => 'info',
        },
    ] );

    $actor = $entry->acted_by ? get_userdata( $entry->acted_by ) : null;

    $history_rows[] = [
        'stage'  => EL_Admin_UI::badge( [
            'label'   => $entry->stage . '. ' . $module->get_stage_name( (int) $entry->stage ),
            'variant' => EL_Expand_Site_Module::get_stage_badge_variant( (int) $entry->stage ),
        ] ),
        'action' => $action_badge,
        'notes'  => esc_html( $entry->notes ?: '—' ),
        'by'     => $actor ? esc_html( $actor->display_name ) : '—',
        'date'   => date_i18n( 'M j, Y g:i A', strtotime( $entry->created_at ) ),
    ];
}

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'util-history',
    'group'   => 'util-tabs',
    'content' => EL_Admin_UI::card( [
        'title'   => __( 'Stage History', 'el-core' ),
        'icon'    => 'backup',
        'content' => EL_Admin_UI::data_table( [
            'columns' => [
                [ 'key' => 'stage',  'label' => __( 'Stage', 'el-core' ) ],
                [ 'key' => 'action', 'label' => __( 'Action', 'el-core' ) ],
                [ 'key' => 'notes',  'label' => __( 'Notes', 'el-core' ) ],
                [ 'key' => 'by',     'label' => __( 'By', 'el-core' ) ],
                [ 'key' => 'date',   'label' => __( 'Date', 'el-core' ) ],
            ],
            'rows'  => $history_rows,
            'empty' => [ 'icon' => 'backup', 'title' => __( 'No stage history yet', 'el-core' ) ],
        ] ),
    ] ),
    'active'  => false,
] );

// ═══════════════════════════════════════════
// LAYER 2 — PHASE BAR
// ═══════════════════════════════════════════

$phase_bar_html  = '<div class="el-es-phase-bar-wrap">';
$phase_bar_html .= '<div class="el-es-phase-bar-label">' . __( 'Project Phases', 'el-core' ) . '</div>';
$phase_bar_html .= '<div class="el-es-phase-bar">';

foreach ( EL_Expand_Site_Module::STAGES as $phase_num => $phase_info ) {
    $pill_class = 'el-es-phase-pill el-tab-btn';
    $pill_class .= ' data-group="phase-tabs"';
    $is_active_phase = ( $phase_num === $current_stage );

    if ( $phase_num < $current_stage ) {
        $pill_class .= ' el-es-phase-complete';
        $icon = '<span class="dashicons dashicons-yes"></span>';
    } elseif ( $phase_num === $current_stage ) {
        $pill_class .= ' el-es-phase-current';
        $icon = '';
    } else {
        $pill_class .= ' el-es-phase-upcoming';
        $icon = '';
    }

    $phase_bar_html .= sprintf(
        '<button type="button" class="%s" data-tab="phase-%d" data-group="phase-tabs"%s>%s<span class="el-es-phase-num">%d.</span> %s</button>',
        esc_attr( $pill_class ),
        $phase_num,
        $is_active_phase ? ' aria-selected="true"' : '',
        $icon,
        $phase_num,
        esc_html( $phase_info['name'] )
    );
}

$phase_bar_html .= '</div>';
$phase_bar_html .= '</div>';

$html .= $phase_bar_html;

// ═══════════════════════════════════════════
// PHASE CONTENT PANELS
// ═══════════════════════════════════════════

// ── Phase 1: Qualification ──
$p1 = '';

$p1 .= EL_Admin_UI::notice( [
    'message' => __( 'Capture intake information before the discovery call. No client-facing interaction in this phase.', 'el-core' ),
    'type'    => 'info',
] );

$p1_form  = '<form id="qualification-form">';
$p1_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';

$p1_form .= EL_Admin_UI::form_row( [
    'name'        => 'project_goal',
    'label'       => __( 'Project Goal', 'el-core' ),
    'type'        => 'textarea',
    'value'       => esc_textarea( $project->project_goal ?? '' ),
    'help'        => __( 'What does the client want to achieve with this project?', 'el-core' ),
    'placeholder' => __( 'e.g., Replace outdated site, attract new families, streamline enrollment...', 'el-core' ),
] );

// Call scheduled date
$p1_form .= EL_Admin_UI::form_row( [
    'name'  => 'deadline',
    'label' => __( 'Discovery Call Date', 'el-core' ),
    'type'  => 'date',
    'value' => $project->deadline ? date( 'Y-m-d', strtotime( $project->deadline ) ) : '',
    'help'  => __( 'When is the discovery call scheduled?', 'el-core' ),
] );

// Call completed toggle
$call_completed = ! empty( $project->deadline ) && strtotime( $project->deadline ) < time();
$p1_form .= '<div class="el-form-row">';
$p1_form .= '<label class="el-form-label">' . __( 'Call Completed', 'el-core' ) . '</label>';
$p1_form .= '<div class="el-form-field">';
$p1_form .= '<label style="display:inline-flex;align-items:center;gap:8px;cursor:pointer;">';
$p1_form .= '<input type="checkbox" name="call_completed" id="call-completed-toggle" value="1"' . checked( $call_completed, true, false ) . ' style="width:16px;height:16px;">';
$p1_form .= '<span>' . __( 'Discovery call has been completed', 'el-core' ) . '</span>';
$p1_form .= '</label>';
$p1_form .= '<p class="el-form-help">' . __( 'Check this when the call is done. Signals readiness to advance to Phase 2 (Discovery).', 'el-core' ) . '</p>';
$p1_form .= '</div>';
$p1_form .= '</div>';

$p1_form .= EL_Admin_UI::form_row( [
    'name'  => 'notes',
    'label' => __( 'Internal Notes', 'el-core' ),
    'type'  => 'textarea',
    'value' => esc_textarea( $project->notes ?? '' ),
    'help'  => __( 'Admin-only notes about this project (not visible to client).', 'el-core' ),
] );

$p1_form .= '<div class="el-form-row">';
$p1_form .= EL_Admin_UI::btn( [
    'label'   => __( 'Save', 'el-core' ),
    'variant' => 'primary',
    'icon'    => 'saved',
    'type'    => 'submit',
] );
$p1_form .= '</div>';
$p1_form .= '</form>';

$p1 .= EL_Admin_UI::card( [ 'title' => __( 'Qualification Intake', 'el-core' ), 'icon' => 'edit', 'content' => $p1_form ] );

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'phase-1',
    'group'   => 'phase-tabs',
    'content' => $p1,
    'active'  => $current_stage === 1,
] );

// ── Phase 2: Discovery ──
$p2 = '';

// Status badge
$status_labels   = [
    'draft'          => __( 'Draft', 'el-core' ),
    'pending_review' => __( 'Sent for Review', 'el-core' ),
    'approved'       => __( 'Client Approved', 'el-core' ),
    'locked'         => __( 'Locked', 'el-core' ),
];
$status_variants = [
    'draft'          => 'default',
    'pending_review' => 'info',
    'approved'       => 'success',
    'locked'         => 'success',
];
$effective_status = $is_locked ? 'locked' : $review_status;

$p2 .= '<div class="el-es-definition-status-row" style="margin-bottom:16px;">';
$p2 .= EL_Admin_UI::badge( [
    'label'   => $status_labels[ $effective_status ] ?? ucfirst( $effective_status ),
    'variant' => $status_variants[ $effective_status ] ?? 'default',
] );
$p2 .= '</div>';

// Amber lock banner
if ( $effective_status === 'approved' && ! $is_locked ) {
    $p2 .= '<div class="el-es-lock-action-banner" style="background:#fffbeb;border:2px solid #f59e0b;border-radius:8px;padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;">';
    $p2 .= '<span class="dashicons dashicons-warning" style="color:#d97706;font-size:22px;flex-shrink:0;"></span>';
    $p2 .= '<div style="flex:1;min-width:200px;">';
    $p2 .= '<strong style="color:#92400e;">' . __( 'The client has approved the Project Definition.', 'el-core' ) . '</strong>';
    $p2 .= '<p style="margin:4px 0 0;color:#78350f;font-size:13px;">' . __( 'Lock it now to proceed to the next phase.', 'el-core' ) . '</p>';
    $p2 .= '</div>';
    $p2 .= EL_Admin_UI::btn( [
        'label'   => __( 'Lock Definition', 'el-core' ),
        'variant' => 'primary',
        'icon'    => 'lock',
        'id'      => 'lock-definition-banner-btn',
        'data'    => [
            'project-id'    => $project_id,
            'review-status' => $review_status,
        ],
    ] );
    $p2 .= '</div>';
}

// Send for Review button (only from draft; once sent, admin waits or uses Reset to Draft)
$can_send = ! $is_locked && $effective_status === 'draft';
if ( $can_send ) {
    $p2 .= '<div class="el-es-definition-actions-row" style="margin-bottom:16px;">';
    $p2 .= EL_Admin_UI::btn( [
        'label'   => __( 'Send to Client for Review', 'el-core' ),
        'variant' => 'primary',
        'icon'    => 'email',
        'id'      => 'send-definition-review-btn',
        'data'    => [ 'project-id' => $project_id, 'modal-open' => 'send-definition-review-modal' ],
    ] );
    $p2 .= '</div>';
}

// Reset to Draft escape hatch (shown when review is pending, before DM accepts)
if ( $effective_status === 'pending_review' && ! $is_locked ) {
    $p2 .= '<div class="el-es-definition-actions-row" style="margin-bottom:16px;">';
    $p2 .= EL_Admin_UI::btn( [
        'label'   => __( 'Reset to Draft', 'el-core' ),
        'variant' => 'ghost',
        'icon'    => 'undo',
        'id'      => 'reset-definition-draft-btn',
        'data'    => [ 'project-id' => $project_id ],
    ] );
    $p2 .= '</div>';
}

// Stakeholder verdicts summary
if ( $active_review && $active_review->status === 'open' && ! empty( $verdicts ) ) {
    $fields_accepted = 0;
    $fields_revision = 0;
    foreach ( $verdicts as $v ) {
        if ( ( $v['needs_revision'] ?? 0 ) > 0 ) {
            $fields_revision++;
        } elseif ( ( $v['approved'] ?? 0 ) > 0 ) {
            $fields_accepted++;
        }
    }
    $p2 .= '<div class="el-es-verdict-summary-card el-card" style="margin-bottom:20px;">';
    $p2 .= '<div class="el-card__header"><h3 class="el-card__title">' . esc_html__( 'Stakeholder Verdicts', 'el-core' ) . '</h3></div>';
    $p2 .= '<div class="el-card__body">';
    $p2 .= '<p>' . sprintf( __( '%1$d fields accepted, %2$d need revision', 'el-core' ), (int) $fields_accepted, (int) $fields_revision ) . '</p>';
    if ( $active_review->deadline ) {
        $p2 .= '<p><small>' . sprintf( __( 'Deadline: %s', 'el-core' ), date_i18n( 'M j, Y g:i A', strtotime( $active_review->deadline ) ) ) . '</small></p>';
    }
    $p2 .= '</div></div>';
}

// Per-field stakeholder comments
if ( $active_review && ! empty( $comments ) ) {
    $def_field_labels = [
        'site_description' => __( 'Site Description', 'el-core' ),
        'primary_goal'     => __( 'Primary Goal', 'el-core' ),
        'secondary_goals'  => __( 'Secondary Goals', 'el-core' ),
        'target_customers' => __( 'Target Customers', 'el-core' ),
        'user_types'       => __( 'User Types', 'el-core' ),
        'site_type'        => __( 'Site Type', 'el-core' ),
        'overall'          => __( 'Overall', 'el-core' ),
    ];
    $p2 .= '<div class="el-es-definition-comments-panel el-card" style="margin-bottom:20px;">';
    $p2 .= '<div class="el-card__header"><h3 class="el-card__title">' . esc_html__( 'Stakeholder Comments', 'el-core' ) . '</h3></div>';
    $p2 .= '<div class="el-card__body el-es-comments-list">';
    foreach ( $comments as $field_key => $field_comments ) {
        $label = $def_field_labels[ $field_key ] ?? $field_key;
        $p2 .= '<div class="el-es-comments-field" data-field-key="' . esc_attr( $field_key ) . '">';
        $p2 .= '<h4 class="el-es-comments-field-title">' . esc_html( $label ) . '</h4>';
        foreach ( $field_comments as $c ) {
            $p2 .= '<div class="el-es-comment-item' . ( $c->parent_id ? ' el-es-comment-reply' : '' ) . '">';
            $p2 .= '<div class="el-es-comment-meta">' . esc_html( $c->display_name ?? 'Unknown' );
            if ( $c->verdict ) {
                $p2 .= ' <span class="el-es-comment-verdict el-es-verdict-' . esc_attr( $c->verdict ) . '">'
                     . ( $c->verdict === 'approved' ? '✓ Approved Field' : '⚑ Flagged for changes' )
                     . '</span>';
            }
            $p2 .= ' <span class="el-es-comment-date">' . esc_html( date_i18n( 'M j, g:i A', strtotime( $c->created_at ) ) ) . '</span></div>';
            $p2 .= '<div class="el-es-comment-text">' . nl2br( esc_html( $c->comment ) ) . '</div>';
            $p2 .= '</div>';
            foreach ( $c->replies ?? [] as $r ) {
                $p2 .= '<div class="el-es-comment-item el-es-comment-reply">';
                $p2 .= '<div class="el-es-comment-meta">' . esc_html( $r->display_name ?? 'Unknown' );
                if ( ! empty( $r->verdict ) ) {
                    $p2 .= ' <span class="el-es-comment-verdict el-es-verdict-' . esc_attr( $r->verdict ) . '">'
                         . ( $r->verdict === 'approved' ? '✓ Approved Field' : '⚑ Flagged for changes' )
                         . '</span>';
                }
                $p2 .= ' <span class="el-es-comment-date">' . esc_html( date_i18n( 'M j, g:i A', strtotime( $r->created_at ) ) ) . '</span></div>';
                $p2 .= '<div class="el-es-comment-text">' . nl2br( esc_html( $r->comment ) ) . '</div>';
                $p2 .= '</div>';
            }
        }
        $p2 .= '</div>';
    }
    $p2 .= '</div></div>';
}

// Version history
$reviews_with_snapshots = array_filter( $reviews, fn( $r ) => ! empty( $r->snapshot ) );
if ( count( $reviews_with_snapshots ) >= 2 ) {
    $history_reviews = array_values( $reviews_with_snapshots );
    $def_field_labels = [
        'site_description' => __( 'Site Description', 'el-core' ),
        'primary_goal'     => __( 'Primary Goal', 'el-core' ),
        'secondary_goals'  => __( 'Secondary Goals', 'el-core' ),
        'target_customers' => __( 'Target Customers', 'el-core' ),
        'user_types'       => __( 'User Types', 'el-core' ),
        'site_type'        => __( 'Site Type', 'el-core' ),
    ];

    $history_html  = '<details class="el-es-version-history-details" style="margin-bottom:20px;">';
    $history_html .= '<summary style="cursor:pointer;font-weight:600;color:#4f46e5;padding:12px 16px;background:#f5f3ff;border:1px solid #ddd6fe;border-radius:6px;list-style:none;display:flex;align-items:center;gap:8px;">';
    $history_html .= '<span class="dashicons dashicons-backup" style="font-size:16px;"></span>';
    $history_html .= esc_html__( 'Version History', 'el-core' );
    $history_html .= ' <span style="font-size:12px;font-weight:400;color:#6b7280;">' . sprintf( __( '(%d rounds)', 'el-core' ), count( $history_reviews ) ) . '</span>';
    $history_html .= '</summary>';
    $history_html .= '<div style="border:1px solid #ddd6fe;border-top:none;border-radius:0 0 6px 6px;padding:16px;">';

    foreach ( array_reverse( $history_reviews ) as $rev ) {
        $rev_index    = array_search( $rev, $history_reviews );
        $prev_rev     = $rev_index > 0 ? $history_reviews[ $rev_index - 1 ] : null;
        $sent_by_user = get_userdata( $rev->sent_by );
        $sent_by_name = $sent_by_user ? $sent_by_user->display_name : __( 'Unknown', 'el-core' );

        $history_html .= '<div class="el-es-version-round" style="margin-bottom:20px;padding-bottom:20px;border-bottom:1px solid #f3f4f6;">';
        $history_html .= '<h4 style="margin:0 0 6px;font-size:14px;color:#111827;">';
        $history_html .= sprintf( __( 'Round %d', 'el-core' ), (int) $rev->round );
        $history_html .= ' <span style="font-size:12px;font-weight:400;color:#6b7280;">— ' . sprintf( __( 'Sent by %s on %s', 'el-core' ), esc_html( $sent_by_name ), date_i18n( 'M j, Y g:i A', strtotime( $rev->sent_at ) ) ) . '</span>';
        $history_html .= '</h4>';

        if ( $rev->dm_decision ) {
            $dm_user       = get_userdata( $rev->dm_decided_by );
            $dm_name       = $dm_user ? $dm_user->display_name : __( 'Decision Maker', 'el-core' );
            $decision_color = $rev->dm_decision === 'accepted' ? '#059669' : '#dc2626';
            $decision_label = $rev->dm_decision === 'accepted' ? __( 'Accepted', 'el-core' ) : __( 'Needs Revision', 'el-core' );
            $history_html  .= '<p style="font-size:13px;margin:0 0 6px;">';
            $history_html  .= '<strong style="color:' . $decision_color . ';">' . esc_html( $decision_label ) . '</strong>';
            $history_html  .= ' — ' . esc_html( $dm_name );
            if ( $rev->dm_decided_at ) {
                $history_html .= ' (' . date_i18n( 'M j, Y', strtotime( $rev->dm_decided_at ) ) . ')';
            }
            if ( $rev->dm_note ) {
                $history_html .= '<br><em style="color:#6b7280;">' . esc_html( $rev->dm_note ) . '</em>';
            }
            $history_html .= '</p>';
        }

        if ( $prev_rev && ! empty( $prev_rev->snapshot ) ) {
            $diffs = $module->diff_definition_snapshots( $prev_rev->snapshot, $rev->snapshot );
            if ( ! empty( $diffs ) ) {
                $history_html .= '<div style="font-size:12px;color:#6b7280;margin-top:8px;">' . __( 'Changed from previous round:', 'el-core' ) . '</div>';
                $history_html .= '<div style="display:flex;flex-direction:column;gap:6px;margin-top:6px;">';
                foreach ( $diffs as $field_key => $diff ) {
                    $label         = $def_field_labels[ $field_key ] ?? $field_key;
                    $history_html .= '<div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:4px;padding:8px 10px;">';
                    $history_html .= '<strong style="font-size:12px;color:#374151;">' . esc_html( $label ) . '</strong><br>';
                    if ( $diff['old'] !== '' ) {
                        $history_html .= '<span style="font-size:12px;color:#dc2626;text-decoration:line-through;">' . esc_html( mb_strimwidth( $diff['old'], 0, 200, '…' ) ) . '</span><br>';
                    }
                    $history_html .= '<span style="font-size:12px;color:#059669;">' . esc_html( mb_strimwidth( $diff['new'], 0, 200, '…' ) ) . '</span>';
                    $history_html .= '</div>';
                }
                $history_html .= '</div>';
            } else {
                $history_html .= '<p style="font-size:12px;color:#9ca3af;margin:4px 0 0;">' . __( 'No field changes from previous round.', 'el-core' ) . '</p>';
            }
        }
        $history_html .= '</div>';
    }
    $history_html .= '</div></details>';
    $p2 .= $history_html;
} elseif ( count( $reviews_with_snapshots ) === 1 ) {
    $p2 .= '<p style="font-size:12px;color:#9ca3af;margin-bottom:12px;">' . __( 'Version history will appear after a second review round is sent.', 'el-core' ) . '</p>';
}

if ( $is_locked ) {
    $locked_by = get_userdata( $definition->locked_by );
    $p2 .= EL_Admin_UI::notice( [
        'message' => sprintf(
            __( '<strong>Definition Locked</strong> — Locked by %s on %s. Changes cannot be made.', 'el-core' ),
            $locked_by ? esc_html( $locked_by->display_name ) : 'Unknown',
            date_i18n( 'M j, Y g:i A', strtotime( $definition->locked_at ) )
        ),
        'type' => 'success',
    ] );
}

// Transcript input
if ( ! $is_locked ) {
    $transcript_value = esc_textarea( wp_unslash( $project->discovery_transcript ?? '' ) );
    $has_transcript   = ! empty( $project->discovery_transcript );

    $p2 .= '<div class="el-card" style="margin-bottom:20px;">';
    $p2 .= '<div class="el-card__header"><h3 class="el-card__title">' . __( 'Meeting Transcript', 'el-core' ) . '</h3></div>';
    $p2 .= '<div class="el-card__body">';
    $p2 .= EL_Admin_UI::notice( [
        'message' => __( 'Paste your Fathom meeting summary or any discovery call transcript. The AI will extract project requirements and pre-fill the definition below.', 'el-core' ),
        'type'    => 'info',
    ] );
    $p2 .= '<textarea id="discovery-transcript" rows="12" style="width:100%;font-family:monospace;padding:10px;border:1px solid #ddd;border-radius:4px;">' . $transcript_value . '</textarea>';
    $p2 .= '<div style="margin-top:15px;">';
    $p2 .= EL_Admin_UI::btn( [
        'label'   => __( 'Process with AI', 'el-core' ),
        'variant' => 'primary',
        'icon'    => 'admin-generic',
        'id'      => 'process-transcript-btn',
        'data'    => [ 'project-id' => $project_id ],
    ] );
    if ( $has_transcript ) {
        $p2 .= ' <span style="color:#666;font-size:13px;">' . sprintf(
            __( 'Last processed: %s', 'el-core' ),
            $project->discovery_extracted_at ? date_i18n( 'M j, Y g:i A', strtotime( $project->discovery_extracted_at ) ) : 'Never'
        ) . '</span>';
    }
    $p2 .= '</div></div></div>';
}

// Issue 6: Draft-state helper notice
if ( $effective_status === 'draft' && ! $is_locked ) {
    $p2 .= EL_Admin_UI::notice( [
        'message' => __( 'This definition is in draft. Fill in the fields and click <strong>Send to Client for Review</strong> when ready. The <strong>Reset to Draft</strong> button appears only after you\'ve sent a review to the client.', 'el-core' ),
        'type'    => 'info',
    ] );
}

// Issue 5: Approved-state editing notice
if ( $effective_status === 'approved' && ! $is_locked ) {
    $p2 .= EL_Admin_UI::notice( [
        'message' => __( 'The client has approved this definition. You can still make final edits below before locking. Saving now uses the admin Save Definition handler.', 'el-core' ),
        'type'    => 'info',
    ] );
}

// Definition form
$def_form  = '<form id="project-definition-form">';
$def_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$def_form .= EL_Admin_UI::form_row( [ 'name' => 'site_description',  'label' => __( 'Site Description', 'el-core' ),  'type' => 'textarea', 'value' => $definition?->site_description ?? '', 'readonly' => $is_locked, 'help' => __( 'A brief overview of what this website will be.', 'el-core' ) ] );
$def_form .= EL_Admin_UI::form_row( [ 'name' => 'primary_goal',      'label' => __( 'Primary Goal', 'el-core' ),       'type' => 'textarea', 'value' => $definition?->primary_goal ?? '', 'readonly' => $is_locked, 'help' => __( 'The main objective this website should achieve.', 'el-core' ) ] );
$def_form .= EL_Admin_UI::form_row( [ 'name' => 'secondary_goals',   'label' => __( 'Secondary Goals', 'el-core' ),    'type' => 'textarea', 'value' => $definition?->secondary_goals ?? '', 'readonly' => $is_locked, 'help' => __( 'Additional objectives (one per line or comma-separated).', 'el-core' ) ] );
$def_form .= EL_Admin_UI::form_row( [ 'name' => 'target_customers',  'label' => __( 'Target Customers', 'el-core' ),   'type' => 'textarea', 'value' => $definition?->target_customers ?? '', 'readonly' => $is_locked, 'help' => __( 'Who is this site designed to reach?', 'el-core' ) ] );
$def_form .= EL_Admin_UI::form_row( [ 'name' => 'user_types',        'label' => __( 'User Types', 'el-core' ),         'type' => 'textarea', 'value' => $definition?->user_types ?? '', 'readonly' => $is_locked, 'help' => __( 'Different types of users and their roles (e.g., "Students", "Teachers", "Administrators").', 'el-core' ) ] );
$def_form .= EL_Admin_UI::form_row( [ 'name' => 'site_type',         'label' => __( 'Site Type', 'el-core' ),          'type' => 'text',     'value' => $definition?->site_type ?? '', 'readonly' => $is_locked, 'help' => __( 'e.g., "E-commerce", "Educational Portal", "Corporate Website"', 'el-core' ) ] );
if ( ! $is_locked ) {
    $def_form .= '<div class="el-form-row">';
    $def_form .= EL_Admin_UI::btn( [ 'label' => __( 'Save Definition', 'el-core' ), 'variant' => 'secondary', 'icon' => 'saved', 'type' => 'submit' ] );
    $def_form .= ' ';
    $def_form .= EL_Admin_UI::btn( [
        'label'   => __( 'Confirm & Lock Definition', 'el-core' ),
        'variant' => 'primary',
        'icon'    => 'lock',
        'id'      => 'lock-definition-btn',
        'data'    => [ 'project-id' => $project_id, 'review-status' => $review_status ],
    ] );
    $def_form .= '</div>';
}
$def_form .= '</form>';

$p2 .= EL_Admin_UI::card( [ 'title' => __( 'Project Definition', 'el-core' ), 'icon' => 'edit-page', 'content' => $def_form ] );

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'phase-2',
    'group'   => 'phase-tabs',
    'content' => $p2,
    'active'  => $current_stage === 2,
] );

// ── Phase 3: Proposal ──
$p3 = '';

$accepted_proposal = $module->get_accepted_proposal( $project_id );
if ( $accepted_proposal ) {
    $accepted_by_user = get_userdata( $accepted_proposal->accepted_by );
    $p3 .= EL_Admin_UI::notice( [
        'message' => sprintf(
            __( '<strong>Proposal Accepted</strong> — %s accepted on %s. Final price: $%s', 'el-core' ),
            $accepted_by_user ? esc_html( $accepted_by_user->display_name ) : 'Client',
            date_i18n( 'M j, Y g:i A', strtotime( $accepted_proposal->accepted_at ) ),
            number_format( (float) $accepted_proposal->final_price, 2 )
        ),
        'type' => 'success',
    ] );
}

$proposal_rows = [];
foreach ( $proposals as $prop ) {
    $status_variant = match ( $prop->status ) {
        'draft'    => 'default',
        'sent'     => 'info',
        'accepted' => 'success',
        'declined' => 'error',
        'revised'  => 'warning',
        default    => 'default',
    };

    $prop_actions = '';
    if ( $prop->status === 'draft' ) {
        $prop_actions .= EL_Admin_UI::btn( [ 'label' => __( 'Edit', 'el-core' ),   'variant' => 'ghost', 'icon' => 'edit',  'class' => 'el-es-edit-proposal-btn',   'data' => [ 'proposal-id' => $prop->id ] ] );
        $prop_actions .= EL_Admin_UI::btn( [ 'label' => __( 'Send', 'el-core' ),   'variant' => 'ghost', 'icon' => 'email', 'class' => 'el-es-send-proposal-btn',   'data' => [ 'proposal-id' => $prop->id ] ] );
        $prop_actions .= EL_Admin_UI::btn( [ 'label' => __( 'Delete', 'el-core' ), 'variant' => 'ghost', 'icon' => 'trash', 'class' => 'el-es-delete-proposal-btn', 'data' => [ 'proposal-id' => $prop->id ] ] );
    } elseif ( $prop->status === 'sent' ) {
        $prop_actions .= EL_Admin_UI::btn( [ 'label' => __( 'Edit', 'el-core' ), 'variant' => 'ghost', 'icon' => 'edit', 'class' => 'el-es-edit-proposal-btn', 'data' => [ 'proposal-id' => $prop->id ] ] );
    }

    $proposal_rows[] = [
        'number'     => '<strong>' . esc_html( $prop->proposal_number ) . '</strong>',
        'title'      => esc_html( $prop->proposal_title ?: '—' ),
        'price'      => $prop->final_price > 0 ? '$' . number_format( (float) $prop->final_price, 2 ) : ( $prop->budget_low > 0 ? '$' . number_format( (float) $prop->budget_low, 0 ) . '–$' . number_format( (float) $prop->budget_high, 0 ) : '—' ),
        'status'     => EL_Admin_UI::badge( [ 'label' => ucfirst( $prop->status ), 'variant' => $status_variant ] ),
        'date'       => date_i18n( 'M j, Y', strtotime( $prop->created_at ) ),
        '__actions'  => $prop_actions,
    ];
}

$p3 .= EL_Admin_UI::data_table( [
    'columns' => [
        [ 'key' => 'number', 'label' => __( '#', 'el-core' ) ],
        [ 'key' => 'title',  'label' => __( 'Title', 'el-core' ) ],
        [ 'key' => 'price',  'label' => __( 'Price', 'el-core' ) ],
        [ 'key' => 'status', 'label' => __( 'Status', 'el-core' ) ],
        [ 'key' => 'date',   'label' => __( 'Created', 'el-core' ) ],
    ],
    'rows'  => $proposal_rows,
    'empty' => [
        'icon'    => 'media-document',
        'title'   => __( 'No proposals yet', 'el-core' ),
        'message' => __( 'Create a proposal to send to the client for approval.', 'el-core' ),
        'action'  => [ 'label' => __( 'New Proposal', 'el-core' ), 'variant' => 'primary', 'class' => 'el-es-new-proposal-btn', 'data' => [ 'project-id' => $project_id ] ],
    ],
] );

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'phase-3',
    'group'   => 'phase-tabs',
    'content' => EL_Admin_UI::card( [
        'title'   => __( 'Scope of Service Proposals', 'el-core' ),
        'icon'    => 'media-document',
        'content' => $p3,
        'actions' => [
            [ 'label' => __( 'New Proposal', 'el-core' ), 'variant' => 'secondary', 'icon' => 'plus-alt', 'class' => 'el-es-new-proposal-btn', 'data' => [ 'project-id' => $project_id ] ],
        ],
    ] ),
    'active'  => $current_stage === 3,
] );

// ── Phase 4: User Journey ──
$p_uj = '';

// Load journey rows for this project
global $wpdb;
$journeys_table  = $wpdb->prefix . 'el_es_user_journeys';
$jreviews_table  = $wpdb->prefix . 'el_es_journey_reviews';
$journeys        = $wpdb->get_results( $wpdb->prepare(
    "SELECT * FROM {$journeys_table} WHERE project_id = %d ORDER BY id ASC",
    $project_id
) );
$total_journeys  = count( $journeys );
$locked_journeys = count( array_filter( $journeys, fn( $j ) => $j->status === 'locked' ) );

// Stakeholder list for assignment dropdowns
$journey_stakeholders = $module->get_stakeholders( $project_id );

// Progress badge
$progress_variant = ( $total_journeys > 0 && $locked_journeys === $total_journeys ) ? 'success' : 'warning';
$progress_label   = $total_journeys === 0
    ? __( 'No user types yet', 'el-core' )
    : sprintf( __( '%1$d of %2$d journeys locked', 'el-core' ), $locked_journeys, $total_journeys );

$p_uj .= '<div class="el-es-uj-header" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">';
$p_uj .= '<div style="display:flex;align-items:center;gap:10px;">';
$p_uj .= EL_Admin_UI::badge( [ 'label' => $progress_label, 'variant' => $progress_variant ] );
if ( $locked_journeys < $total_journeys ) {
    $p_uj .= '<span style="font-size:12px;color:#d97706;">' . __( 'Visual Identity will unlock once all journeys are locked.', 'el-core' ) . '</span>';
}
$p_uj .= '</div>';
$p_uj .= '<div style="display:flex;align-items:center;gap:8px;">';
// "Send List to Client" button — only shown when list not yet approved and at least 1 journey row exists
$journey_list_approved = ! empty( $project->journey_list_approved_at );
if ( ! $journey_list_approved && $total_journeys > 0 ) {
    $p_uj .= EL_Admin_UI::btn( [
        'label'   => __( 'Send List to Client', 'el-core' ),
        'variant' => 'primary',
        'icon'    => 'email-alt',
        'data'    => [ 'action' => 'approve_journey_list', 'project-id' => $project_id ],
        'class'   => 'el-es-uj-approve-list-btn',
    ] );
} elseif ( $journey_list_approved ) {
    $p_uj .= '<span style="font-size:12px;color:#059669;font-weight:500;">' . esc_html__( 'List sent to client', 'el-core' ) . '</span>';
}
$p_uj .= EL_Admin_UI::btn( [
    'label'   => __( 'Add User Type', 'el-core' ),
    'variant' => 'secondary',
    'icon'    => 'plus-alt',
    'data'    => [ 'modal-open' => 'add-user-type-modal', 'project-id' => $project_id ],
] );
$p_uj .= '</div>';
$p_uj .= '</div>';

if ( empty( $journeys ) ) {
    $p_uj .= EL_Admin_UI::notice( [
        'message' => __( 'No user journey rows yet. Advance to Phase 4 to auto-seed from the project definition, or click "Add User Type" above.', 'el-core' ),
        'type'    => 'info',
    ] );
}

// Status badge colour map
$uj_status_variants = [
    'pending_assignment' => 'default',
    'awaiting_input'     => 'info',
    'pending_dm_review'  => 'warning',
    'awaiting_ai'        => 'warning',
    'ai_generated'       => 'warning',
    'admin_refined'      => 'warning',
    'in_review'          => 'info',
    'approved'           => 'success',
    'locked'             => 'success',
];
$uj_status_labels = [
    'pending_assignment' => __( 'Pending Assignment', 'el-core' ),
    'awaiting_input'     => __( 'Awaiting Input', 'el-core' ),
    'pending_dm_review'  => __( 'DM Review', 'el-core' ),
    'awaiting_ai'        => __( 'Ready for AI', 'el-core' ),
    'ai_generated'       => __( 'AI Generated', 'el-core' ),
    'admin_refined'      => __( 'Admin Refined', 'el-core' ),
    'in_review'          => __( 'In Review', 'el-core' ),
    'approved'           => __( 'Approved', 'el-core' ),
    'locked'             => __( 'Locked', 'el-core' ),
];

foreach ( $journeys as $jny ) {
    $jstatus      = $jny->status;
    $jid          = (int) $jny->id;
    $jassigned_id = (int) ( $jny->assigned_to ?? 0 );
    $assigned_user = $jassigned_id ? get_userdata( $jassigned_id ) : null;
    $assigned_name = $assigned_user ? $assigned_user->display_name : '';

    // Active review for this journey
    $active_jreview = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$jreviews_table} WHERE journey_id = %d AND status = 'open' ORDER BY id DESC LIMIT 1",
        $jid
    ) );
    $jcomments_table = $wpdb->prefix . 'el_es_journey_comments';

    $p_uj .= '<div class="el-es-uj-card" data-journey-id="' . esc_attr( $jid ) . '" data-status="' . esc_attr( $jstatus ) . '">';

    // Card header - always visible
    $p_uj .= '<div class="el-es-uj-card__header" data-toggle="el-es-uj-card-body-' . esc_attr( $jid ) . '">';

    // Left column: name + assignee + inline edit form
    $p_uj .= '<div class="el-es-uj-card__left">';
    $p_uj .= '<strong class="el-es-uj-type-display">' . esc_html( $jny->user_type ) . '</strong>';
    $p_uj .= '<div class="el-es-uj-card__assignee">' . ( $assigned_name ? esc_html( $assigned_name ) : '<em class="el-es-uj-unassigned">' . esc_html__( 'Unassigned', 'el-core' ) . '</em>' ) . '</div>';
    if ( in_array( $jstatus, [ 'pending_assignment', 'awaiting_input' ], true ) ) {
        $p_uj .= '<div class="el-es-uj-edit-type-form" data-journey-id="' . esc_attr( $jid ) . '" style="display:none;">';
        $p_uj .= '<input type="text" class="el-es-uj-edit-type-input" value="' . esc_attr( $jny->user_type ) . '" />';
        $p_uj .= '<div class="el-es-uj-edit-type-actions">';
        $p_uj .= '<button type="button" class="el-btn el-btn-primary el-es-uj-save-type-btn" data-journey-id="' . esc_attr( $jid ) . '" data-project-id="' . esc_attr( $project_id ) . '">' . esc_html__( 'Save', 'el-core' ) . '</button>';
        $p_uj .= '<button type="button" class="el-btn el-btn-secondary el-es-uj-cancel-edit-type-btn" data-journey-id="' . esc_attr( $jid ) . '">' . esc_html__( 'Cancel', 'el-core' ) . '</button>';
        $p_uj .= '</div>';
        $p_uj .= '</div>';
    }
    $p_uj .= '</div>'; // .el-es-uj-card__left

    // Right column: status badge + action icons + expand arrow
    $p_uj .= '<div class="el-es-uj-card__right">';
    $p_uj .= EL_Admin_UI::badge( [
        'label'   => $uj_status_labels[ $jstatus ] ?? ucfirst( $jstatus ),
        'variant' => $uj_status_variants[ $jstatus ] ?? 'default',
    ] );
    if ( in_array( $jstatus, [ 'pending_assignment', 'awaiting_input' ], true ) ) {
        $p_uj .= '<div class="el-es-uj-card__actions">';
        $p_uj .= '<button type="button" class="el-es-uj-icon-btn el-es-uj-edit-type-btn" title="' . esc_attr__( 'Rename user type', 'el-core' ) . '" data-journey-id="' . esc_attr( $jid ) . '" data-project-id="' . esc_attr( $project_id ) . '"><span class="dashicons dashicons-edit"></span></button>';
        if ( $jstatus === 'pending_assignment' ) {
            $p_uj .= '<button type="button" class="el-es-uj-icon-btn el-es-uj-icon-btn--danger el-es-uj-delete-type-btn" title="' . esc_attr__( 'Delete user type', 'el-core' ) . '" data-journey-id="' . esc_attr( $jid ) . '" data-project-id="' . esc_attr( $project_id ) . '" data-user-type="' . esc_attr( $jny->user_type ) . '"><span class="dashicons dashicons-trash"></span></button>';
        }
        $p_uj .= '</div>';
    }
    $p_uj .= '<span class="el-es-uj-expand-icon dashicons dashicons-arrow-down-alt2"></span>';
    $p_uj .= '</div>'; // .el-es-uj-card__right

    $p_uj .= '</div>'; // end header
    // Card body — expanded state
    $p_uj .= '<div class="el-es-uj-card__body" id="el-es-uj-card-body-' . esc_attr( $jid ) . '" style="display:none;">';

    // ── pending_assignment ──
    if ( $jstatus === 'pending_assignment' ) {
        $p_uj .= '<p class="el-es-uj-msg">' . __( 'Assign a stakeholder to describe how this user type moves through the site.', 'el-core' ) . '</p>';
        $p_uj .= '<div class="el-es-uj-assign-row">';
        $p_uj .= '<select class="el-input el-es-uj-assign-select" data-journey-id="' . esc_attr( $jid ) . '">';
        $p_uj .= '<option value="">' . esc_html__( '— Select stakeholder —', 'el-core' ) . '</option>';
        foreach ( $journey_stakeholders as $sh ) {
            $sh_user = get_userdata( $sh->user_id );
            if ( ! $sh_user ) continue;
            $p_uj .= '<option value="' . esc_attr( $sh->user_id ) . '">' . esc_html( $sh_user->display_name ) . ' (' . esc_html( $sh->role === 'decision_maker' ? __( 'DM', 'el-core' ) : __( 'Contributor', 'el-core' ) ) . ')</option>';
        }
        $p_uj .= '</select>';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Assign', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'yes-alt',
            'class'   => 'el-es-uj-assign-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id ],
        ] );
        $p_uj .= '</div>';
    }

    // ── awaiting_input ──
    if ( $jstatus === 'awaiting_input' ) {
        $p_uj .= '<p class="el-es-uj-msg">';
        $p_uj .= sprintf(
            __( 'Waiting for <strong>%s</strong> to complete their input.', 'el-core' ),
            esc_html( $assigned_name ?: __( 'the assigned stakeholder', 'el-core' ) )
        );
        $p_uj .= '</p>';
        $p_uj .= '<div class="el-es-uj-reassign-row">';
        $p_uj .= '<a href="#" class="el-es-uj-reassign-link" data-journey-id="' . esc_attr( $jid ) . '">' . __( 'Reassign to a different stakeholder', 'el-core' ) . '</a>';
        $p_uj .= '<div class="el-es-uj-reassign-form" style="display:none;margin-top:10px;">';
        $p_uj .= '<select class="el-input el-es-uj-assign-select" data-journey-id="' . esc_attr( $jid ) . '">';
        $p_uj .= '<option value="">' . esc_html__( '— Select stakeholder —', 'el-core' ) . '</option>';
        foreach ( $journey_stakeholders as $sh ) {
            $sh_user = get_userdata( $sh->user_id );
            if ( ! $sh_user ) continue;
            $p_uj .= '<option value="' . esc_attr( $sh->user_id ) . '">' . esc_html( $sh_user->display_name ) . ' (' . esc_html( $sh->role === 'decision_maker' ? __( 'DM', 'el-core' ) : __( 'Contributor', 'el-core' ) ) . ')</option>';
        }
        $p_uj .= '</select>';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Reassign', 'el-core' ),
            'variant' => 'secondary',
            'icon'    => 'update',
            'class'   => 'el-es-uj-assign-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id ],
        ] );
        $p_uj .= '</div>';
        $p_uj .= '</div>';
    }

    // ── pending_dm_review — answers submitted, DM hasn't sent to admin yet ──
    if ( $jstatus === 'pending_dm_review' ) {
        $guided = $jny->guided_answers ? json_decode( $jny->guided_answers, true ) : [];
        if ( ! empty( $guided ) ) {
            $p_uj .= '<div class="el-es-uj-section">';
            $p_uj .= '<h4 class="el-es-uj-section-title">' . __( 'Answers submitted — awaiting DM review', 'el-core' ) . '</h4>';
            foreach ( $guided as $qa ) {
                $p_uj .= '<div class="el-es-uj-qa">';
                $p_uj .= '<p class="el-es-uj-qa__q"><strong>' . esc_html( $qa['question'] ?? '' ) . '</strong></p>';
                $p_uj .= '<p class="el-es-uj-qa__a">' . esc_html( $qa['answer'] ?? '' ) . '</p>';
                $p_uj .= '</div>';
            }
            $p_uj .= '</div>';
        }
        $p_uj .= EL_Admin_UI::notice( [
            'message' => __( 'The Decision Maker is reviewing these answers. Once they send them forward, you will be able to generate the AI workflow.', 'el-core' ),
            'type'    => 'info',
        ] );
    }

    // ── awaiting_ai — DM has sent answers forward; admin generates AI ──
    if ( $jstatus === 'awaiting_ai' ) {
        $guided = $jny->guided_answers ? json_decode( $jny->guided_answers, true ) : [];
        if ( ! empty( $guided ) ) {
            $p_uj .= '<div class="el-es-uj-section">';
            $p_uj .= '<h4 class="el-es-uj-section-title">' . __( 'What the team described', 'el-core' ) . '</h4>';
            if ( ! empty( $jny->admin_notes ) ) {
                $p_uj .= EL_Admin_UI::notice( [
                    'message' => '<strong>' . __( 'DM notes:', 'el-core' ) . '</strong> ' . esc_html( $jny->admin_notes ),
                    'type'    => 'info',
                ] );
            }
            foreach ( $guided as $qa ) {
                $p_uj .= '<div class="el-es-uj-qa">';
                $p_uj .= '<p class="el-es-uj-qa__q"><strong>' . esc_html( $qa['question'] ?? '' ) . '</strong></p>';
                $p_uj .= '<p class="el-es-uj-qa__a">' . esc_html( $qa['answer'] ?? '' ) . '</p>';
                $p_uj .= '</div>';
            }
            $p_uj .= '</div>';
        }
        $p_uj .= '<div class="el-es-uj-btn-row" style="margin-top:12px;">';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Generate with AI', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'admin-generic',
            'class'   => 'el-es-uj-generate-ai-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id ],
        ] );
        $p_uj .= '<span class="el-es-uj-generate-status" style="margin-left:10px;color:#6b7280;font-size:13px;"></span>';
        $p_uj .= '</div>';
    }

    // ── ai_generated ──
    if ( $jstatus === 'ai_generated' ) {
        // Q&A pairs
        $guided = $jny->guided_answers ? json_decode( $jny->guided_answers, true ) : [];
        if ( ! empty( $guided ) ) {
            $p_uj .= '<div class="el-es-uj-section">';
            $p_uj .= '<h4 class="el-es-uj-section-title">' . __( 'What the team described', 'el-core' ) . '</h4>';
            foreach ( $guided as $qa ) {
                $p_uj .= '<div class="el-es-uj-qa">';
                $p_uj .= '<p class="el-es-uj-qa__q"><strong>' . esc_html( $qa['question'] ?? '' ) . '</strong></p>';
                $p_uj .= '<p class="el-es-uj-qa__a">' . esc_html( $qa['answer'] ?? '' ) . '</p>';
                $p_uj .= '</div>';
            }
            $p_uj .= '</div>';
        }

        // AI workflow output
        $ai_wf = $jny->ai_workflow ? json_decode( $jny->ai_workflow, true ) : null;
        if ( $ai_wf ) {
            $p_uj .= '<div class="el-es-uj-section">';
            $p_uj .= '<h4 class="el-es-uj-section-title">' . __( 'AI-generated workflow', 'el-core' ) . '</h4>';
            if ( ! empty( $ai_wf['summary'] ) ) {
                $p_uj .= '<p class="el-es-uj-summary">' . esc_html( $ai_wf['summary'] ) . '</p>';
            }
            if ( ! empty( $ai_wf['steps'] ) ) {
                $p_uj .= '<ol class="el-es-uj-steps">';
                foreach ( $ai_wf['steps'] as $step ) {
                    $p_uj .= '<li><strong>' . esc_html( $step['label'] ?? '' ) . '</strong>: ' . esc_html( $step['description'] ?? '' );
                    if ( ! empty( $step['branch'] ) ) {
                        $p_uj .= ' <em class="el-es-uj-branch">→ ' . sprintf( __( 'Branch: %s', 'el-core' ), esc_html( $step['branch']['condition'] ?? '' ) ) . '</em>';
                    }
                    $p_uj .= '</li>';
                }
                $p_uj .= '</ol>';
            }
            if ( ! empty( $ai_wf['implied_pages'] ) ) {
                $p_uj .= '<p class="el-es-uj-implied"><strong>' . __( 'Implied pages:', 'el-core' ) . '</strong> ' . esc_html( implode( ', ', $ai_wf['implied_pages'] ) ) . '</p>';
            }
            if ( ! empty( $ai_wf['open_questions'] ) ) {
                $p_uj .= EL_Admin_UI::notice( [
                    'message' => '<strong>' . __( 'Open questions:', 'el-core' ) . '</strong><br>' . esc_html( implode( "\n", $ai_wf['open_questions'] ) ),
                    'type'    => 'warning',
                ] );
            }
            $p_uj .= '</div>';
        }

        // Mermaid diagram placeholder
        $p_uj .= '<div class="el-es-uj-diagram-container" data-journey-id="' . esc_attr( $jid ) . '" data-workflow-source="ai">';
        $p_uj .= '<div class="el-es-uj-diagram-inner mermaid"></div>';
        $p_uj .= '</div>';

        // Admin notes + Refine button
        $p_uj .= '<div class="el-es-uj-section">';
        $p_uj .= '<h4 class="el-es-uj-section-title">' . __( 'Refine with AI', 'el-core' ) . '</h4>';
        $p_uj .= '<div class="el-form-row">';
        $p_uj .= '<label class="el-form-label">' . __( 'Admin notes for AI', 'el-core' ) . '</label>';
        $p_uj .= '<div class="el-form-field">';
        $p_uj .= '<textarea class="el-textarea el-es-uj-admin-notes" data-journey-id="' . esc_attr( $jid ) . '" rows="3" placeholder="' . esc_attr__( 'Describe what to add, change, or clarify...', 'el-core' ) . '">' . esc_textarea( $jny->admin_notes ?? '' ) . '</textarea>';
        $p_uj .= '</div></div>';
        $p_uj .= '<div class="el-es-uj-btn-row">';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Refine with AI', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'admin-generic',
            'class'   => 'el-es-uj-refine-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id ],
        ] );
        $p_uj .= '<span class="el-es-uj-refine-status" style="margin-left:10px;color:#6b7280;font-size:13px;"></span>';
        $p_uj .= '</div>';
        $p_uj .= '</div>';

        // Manual edit section (structured form — no raw JSON)
        $ai_wf_edit = $jny->ai_workflow ? json_decode( $jny->ai_workflow, true ) : [];
        $p_uj .= '<div class="el-es-uj-section el-es-uj-manual-edit-section">';
        $p_uj .= '<button type="button" class="el-es-uj-manual-edit-toggle" data-journey-id="' . esc_attr( $jid ) . '">';
        $p_uj .= el_es_icon( 'edit', 14 ) . ' ' . esc_html__( 'Manually edit workflow', 'el-core' );
        $p_uj .= '</button>';
        $p_uj .= '<div class="el-es-uj-manual-edit-form" data-journey-id="' . esc_attr( $jid ) . '" style="display:none;margin-top:12px;">';
        $p_uj .= '<p class="el-es-uj-manual-edit-hint">' . esc_html__( 'Edit the summary and steps below. Each step has a short label and a one-sentence description.', 'el-core' ) . '</p>';
        $p_uj .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Summary', 'el-core' ) . '</label>';
        $p_uj .= '<div class="el-form-field"><textarea class="el-textarea el-es-uj-edit-summary" data-journey-id="' . esc_attr( $jid ) . '" rows="3" style="resize:both;width:100%;">' . esc_textarea( $ai_wf_edit['summary'] ?? '' ) . '</textarea></div></div>';
        $p_uj .= '<div class="el-es-uj-edit-steps" data-journey-id="' . esc_attr( $jid ) . '">';
        foreach ( ( $ai_wf_edit['steps'] ?? [] ) as $sidx => $step ) {
            $snum = $sidx + 1;
            $p_uj .= '<div class="el-es-uj-edit-step" data-step-index="' . esc_attr( $sidx ) . '">';
            $p_uj .= '<p class="el-es-uj-edit-step-num">' . sprintf( esc_html__( 'Step %d', 'el-core' ), $snum );
            $p_uj .= ' <button type="button" class="el-es-uj-remove-step-btn" style="margin-left:8px;font-size:11px;color:#EF4444;background:none;border:none;cursor:pointer;">✕ ' . esc_html__( 'Remove', 'el-core' ) . '</button></p>';
            $p_uj .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Label', 'el-core' ) . '</label>';
            $p_uj .= '<div class="el-form-field"><input type="text" class="el-input el-es-uj-edit-step-label" value="' . esc_attr( $step['label'] ?? '' ) . '" style="width:100%;"></div></div>';
            $p_uj .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Description', 'el-core' ) . '</label>';
            $p_uj .= '<div class="el-form-field"><textarea class="el-textarea el-es-uj-edit-step-desc" rows="2" style="resize:both;width:100%;">' . esc_textarea( $step['description'] ?? '' ) . '</textarea></div></div>';
            $p_uj .= '</div>';
        }
        $p_uj .= '</div>';
        $p_uj .= '<button type="button" class="el-es-uj-add-step-btn" data-journey-id="' . esc_attr( $jid ) . '" style="margin:8px 0 12px;font-size:13px;color:#6366F1;background:none;border:1px dashed #6366F1;border-radius:4px;padding:4px 12px;cursor:pointer;">+ ' . esc_html__( 'Add Step', 'el-core' ) . '</button>';
        $p_uj .= '<div class="el-es-uj-btn-row" style="margin-top:12px;">';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Save Manual Edits', 'el-core' ),
            'variant' => 'secondary',
            'icon'    => 'yes',
            'class'   => 'el-es-uj-save-workflow-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id, 'source' => 'ai' ],
        ] );
        $p_uj .= '<span class="el-es-uj-save-workflow-status" style="margin-left:10px;color:#6b7280;font-size:13px;"></span>';
        $p_uj .= '</div>';
        $p_uj .= '</div>';
        $p_uj .= '</div>';
    }

    // ── admin_refined ──
    if ( $jstatus === 'admin_refined' ) {
        $admin_wf = $jny->admin_workflow ? json_decode( $jny->admin_workflow, true ) : null;
        if ( $admin_wf ) {
            $p_uj .= '<div class="el-es-uj-section">';
            $p_uj .= '<h4 class="el-es-uj-section-title">' . __( 'Refined workflow', 'el-core' ) . '</h4>';
            if ( ! empty( $admin_wf['summary'] ) ) {
                $p_uj .= '<p class="el-es-uj-summary">' . esc_html( $admin_wf['summary'] ) . '</p>';
            }
            if ( ! empty( $admin_wf['steps'] ) ) {
                $p_uj .= '<ol class="el-es-uj-steps">';
                foreach ( $admin_wf['steps'] as $step ) {
                    $p_uj .= '<li><strong>' . esc_html( $step['label'] ?? '' ) . '</strong>: ' . esc_html( $step['description'] ?? '' );
                    if ( ! empty( $step['branch'] ) ) {
                        $p_uj .= ' <em class="el-es-uj-branch">→ ' . sprintf( __( 'Branch: %s', 'el-core' ), esc_html( $step['branch']['condition'] ?? '' ) ) . '</em>';
                    }
                    $p_uj .= '</li>';
                }
                $p_uj .= '</ol>';
            }
            if ( ! empty( $admin_wf['implied_pages'] ) ) {
                $p_uj .= '<p class="el-es-uj-implied"><strong>' . __( 'Implied pages:', 'el-core' ) . '</strong> ' . esc_html( implode( ', ', $admin_wf['implied_pages'] ) ) . '</p>';
            }
            if ( ! empty( $admin_wf['open_questions'] ) ) {
                $p_uj .= EL_Admin_UI::notice( [
                    'message' => '<strong>' . __( 'Open questions:', 'el-core' ) . '</strong><br>' . esc_html( implode( "\n", $admin_wf['open_questions'] ) ),
                    'type'    => 'warning',
                ] );
            }
            $p_uj .= '</div>';
        }

        $p_uj .= '<div class="el-es-uj-diagram-container" data-journey-id="' . esc_attr( $jid ) . '" data-workflow-source="admin">';
        $p_uj .= '<div class="el-es-uj-diagram-inner mermaid"></div>';
        $p_uj .= '</div>';

        // Admin notes still available for further rounds
        $p_uj .= '<div class="el-es-uj-section">';
        $p_uj .= '<h4 class="el-es-uj-section-title">' . __( 'Further refinement', 'el-core' ) . '</h4>';
        $p_uj .= '<div class="el-form-row">';
        $p_uj .= '<label class="el-form-label">' . __( 'Admin notes for AI', 'el-core' ) . '</label>';
        $p_uj .= '<div class="el-form-field">';
        $p_uj .= '<textarea class="el-textarea el-es-uj-admin-notes" data-journey-id="' . esc_attr( $jid ) . '" rows="3" placeholder="' . esc_attr__( 'Describe what to add, change, or clarify...', 'el-core' ) . '">' . esc_textarea( $jny->admin_notes ?? '' ) . '</textarea>';
        $p_uj .= '</div></div>';
        $p_uj .= '<div class="el-es-uj-btn-row">';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Refine with AI Again', 'el-core' ),
            'variant' => 'secondary',
            'icon'    => 'admin-generic',
            'class'   => 'el-es-uj-refine-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id ],
        ] );
        $p_uj .= '<span class="el-es-uj-refine-status" style="margin-left:10px;color:#6b7280;font-size:13px;"></span>';
        $p_uj .= '</div>';
        $p_uj .= '</div>';

        // Manual edit section (structured form — no raw JSON)
        $admin_wf_edit = $jny->admin_workflow ? json_decode( $jny->admin_workflow, true ) : [];
        $p_uj .= '<div class="el-es-uj-section el-es-uj-manual-edit-section">';
        $p_uj .= '<button type="button" class="el-es-uj-manual-edit-toggle" data-journey-id="' . esc_attr( $jid ) . '">';
        $p_uj .= el_es_icon( 'edit', 14 ) . ' ' . esc_html__( 'Manually edit workflow', 'el-core' );
        $p_uj .= '</button>';
        $p_uj .= '<div class="el-es-uj-manual-edit-form" data-journey-id="' . esc_attr( $jid ) . '" style="display:none;margin-top:12px;">';
        $p_uj .= '<p class="el-es-uj-manual-edit-hint">' . esc_html__( 'Edit the summary and steps below. Each step has a short label and a one-sentence description.', 'el-core' ) . '</p>';
        $p_uj .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Summary', 'el-core' ) . '</label>';
        $p_uj .= '<div class="el-form-field"><textarea class="el-textarea el-es-uj-edit-summary" data-journey-id="' . esc_attr( $jid ) . '" rows="3" style="resize:both;width:100%;">' . esc_textarea( $admin_wf_edit['summary'] ?? '' ) . '</textarea></div></div>';
        $p_uj .= '<div class="el-es-uj-edit-steps" data-journey-id="' . esc_attr( $jid ) . '">';
        foreach ( ( $admin_wf_edit['steps'] ?? [] ) as $sidx => $step ) {
            $snum = $sidx + 1;
            $p_uj .= '<div class="el-es-uj-edit-step" data-step-index="' . esc_attr( $sidx ) . '">';
            $p_uj .= '<p class="el-es-uj-edit-step-num">' . sprintf( esc_html__( 'Step %d', 'el-core' ), $snum );
            $p_uj .= ' <button type="button" class="el-es-uj-remove-step-btn" style="margin-left:8px;font-size:11px;color:#EF4444;background:none;border:none;cursor:pointer;">✕ ' . esc_html__( 'Remove', 'el-core' ) . '</button></p>';
            $p_uj .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Label', 'el-core' ) . '</label>';
            $p_uj .= '<div class="el-form-field"><input type="text" class="el-input el-es-uj-edit-step-label" value="' . esc_attr( $step['label'] ?? '' ) . '" style="width:100%;"></div></div>';
            $p_uj .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Description', 'el-core' ) . '</label>';
            $p_uj .= '<div class="el-form-field"><textarea class="el-textarea el-es-uj-edit-step-desc" rows="2" style="resize:both;width:100%;">' . esc_textarea( $step['description'] ?? '' ) . '</textarea></div></div>';
            $p_uj .= '</div>';
        }
        $p_uj .= '</div>';
        $p_uj .= '<button type="button" class="el-es-uj-add-step-btn" data-journey-id="' . esc_attr( $jid ) . '" style="margin:8px 0 12px;font-size:13px;color:#6366F1;background:none;border:1px dashed #6366F1;border-radius:4px;padding:4px 12px;cursor:pointer;">+ ' . esc_html__( 'Add Step', 'el-core' ) . '</button>';
        $p_uj .= '<div class="el-es-uj-btn-row" style="margin-top:12px;">';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Save Manual Edits', 'el-core' ),
            'variant' => 'secondary',
            'icon'    => 'yes',
            'class'   => 'el-es-uj-save-workflow-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id, 'source' => 'admin' ],
        ] );
        $p_uj .= '<span class="el-es-uj-save-workflow-status" style="margin-left:10px;color:#6b7280;font-size:13px;"></span>';
        $p_uj .= '</div>';
        $p_uj .= '</div>';
        $p_uj .= '</div>';

        // Send for Review
        $p_uj .= '<div class="el-es-uj-btn-row" style="margin-top:16px;">';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Send for Review', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'email-alt',
            'class'   => 'el-es-uj-send-review-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id, 'modal-open' => 'send-journey-review-modal-' . $jid ],
        ] );
        $p_uj .= '</div>';
    }

    // ── in_review ──
    if ( $jstatus === 'in_review' ) {
        if ( $active_jreview ) {
            $p_uj .= '<div class="el-es-uj-review-info">';
            $p_uj .= EL_Admin_UI::detail_row( [
                'label' => __( 'Review Round', 'el-core' ),
                'value' => sprintf( __( 'Round %d', 'el-core' ), $active_jreview->round ),
                'icon'  => 'update',
            ] );
            $p_uj .= EL_Admin_UI::detail_row( [
                'label' => __( 'Sent', 'el-core' ),
                'value' => date_i18n( 'M j, Y g:i A', strtotime( $active_jreview->created_at ) ),
                'icon'  => 'calendar-alt',
            ] );
            if ( $active_jreview->deadline ) {
                $p_uj .= EL_Admin_UI::detail_row( [
                    'label' => __( 'Deadline', 'el-core' ),
                    'value' => date_i18n( 'M j, Y', strtotime( $active_jreview->deadline ) ),
                    'icon'  => 'clock',
                ] );
            }
            if ( $active_jreview->dm_decision ) {
                $dm_badge = $active_jreview->dm_decision === 'approved'
                    ? EL_Admin_UI::badge( [ 'label' => __( 'DM Approved', 'el-core' ), 'variant' => 'success' ] )
                    : EL_Admin_UI::badge( [ 'label' => __( 'DM Requested Revisions', 'el-core' ), 'variant' => 'warning' ] );
                $p_uj .= EL_Admin_UI::detail_row( [ 'label' => __( 'DM Decision', 'el-core' ), 'value' => $dm_badge, 'icon' => 'yes-alt' ] );
                // Show DM's edit notes if they left any
                if ( ! empty( $active_jreview->dm_note ) ) {
                    $p_uj .= '<div class="el-es-uj-dm-notes-box">';
                    $p_uj .= '<p class="el-es-uj-dm-notes-label">' . el_es_icon( 'edit', 14 ) . ' <strong>' . esc_html__( 'DM\'s suggested edits:', 'el-core' ) . '</strong></p>';
                    $p_uj .= '<p class="el-es-uj-dm-notes-text">' . nl2br( esc_html( $active_jreview->dm_note ) ) . '</p>';
                    $p_uj .= '</div>';
                }
            } else {
                $p_uj .= EL_Admin_UI::detail_row( [ 'label' => __( 'DM Decision', 'el-core' ), 'value' => __( 'Awaiting DM decision', 'el-core' ), 'icon' => 'clock' ] );
            }
            $p_uj .= '</div>';
        }

        // Show admin_workflow (read-only)
        $in_review_wf = $jny->admin_workflow ? json_decode( $jny->admin_workflow, true ) : null;
        if ( $in_review_wf ) {
            $p_uj .= '<div class="el-es-uj-section">';
            $p_uj .= '<h4 class="el-es-uj-section-title">' . __( 'Workflow under review', 'el-core' ) . '</h4>';
            if ( ! empty( $in_review_wf['summary'] ) ) {
                $p_uj .= '<p class="el-es-uj-summary">' . esc_html( $in_review_wf['summary'] ) . '</p>';
            }
            if ( ! empty( $in_review_wf['steps'] ) ) {
                $p_uj .= '<ol class="el-es-uj-steps">';
                foreach ( $in_review_wf['steps'] as $step ) {
                    $p_uj .= '<li><strong>' . esc_html( $step['label'] ?? '' ) . '</strong>: ' . esc_html( $step['description'] ?? '' );
                    if ( ! empty( $step['branch'] ) ) {
                        $p_uj .= ' <em class="el-es-uj-branch">→ ' . sprintf( __( 'Branch: %s', 'el-core' ), esc_html( $step['branch']['condition'] ?? '' ) ) . '</em>';
                    }
                    $p_uj .= '</li>';
                }
                $p_uj .= '</ol>';
            }
            $p_uj .= '</div>';
        }

        // Comments from stakeholders (read-only for admin)
        $journey_comments = $active_jreview ? $wpdb->get_results( $wpdb->prepare(
            "SELECT c.*, u.display_name FROM {$jcomments_table} c LEFT JOIN {$wpdb->users} u ON c.user_id = u.ID WHERE c.review_id = %d AND c.parent_id = 0 ORDER BY c.created_at ASC",
            $active_jreview->id
        ) ) : [];
        if ( ! empty( $journey_comments ) ) {
            $p_uj .= '<div class="el-es-uj-section">';
            $p_uj .= '<h4 class="el-es-uj-section-title">' . __( 'Stakeholder comments', 'el-core' ) . '</h4>';
            $p_uj .= '<div class="el-es-uj-comments-list">';
            foreach ( $journey_comments as $jc ) {
                $step_label = $jc->step_key ? sprintf( __( 'Step %s', 'el-core' ), esc_html( $jc->step_key ) ) : __( 'Overall', 'el-core' );
                $p_uj .= '<div class="el-es-uj-comment">';
                $p_uj .= '<div class="el-es-uj-comment__meta"><span class="el-es-uj-comment__author">' . esc_html( $jc->display_name ?? 'Unknown' ) . '</span>';
                $p_uj .= ' <span class="el-es-uj-comment__step">— ' . $step_label . '</span>';
                $p_uj .= ' <span class="el-es-uj-comment__date">' . esc_html( date_i18n( 'M j, Y g:i A', strtotime( $jc->created_at ) ) ) . '</span></div>';
                $p_uj .= '<div class="el-es-uj-comment__text">' . esc_html( $jc->comment ) . '</div>';
                if ( $jc->verdict ) {
                    $vbadge = $jc->verdict === 'approved'
                        ? EL_Admin_UI::badge( [ 'label' => __( '✓ Looks good', 'el-core' ), 'variant' => 'success' ] )
                        : EL_Admin_UI::badge( [ 'label' => __( '⚑ Flag for changes', 'el-core' ), 'variant' => 'warning' ] );
                    $p_uj .= '<div class="el-es-uj-comment__verdict">' . $vbadge . '</div>';
                }
                $p_uj .= '</div>';
            }
            $p_uj .= '</div>';
            $p_uj .= '</div>';
        }

        $p_uj .= '<div class="el-es-uj-btn-row" style="margin-top:16px;">';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Reset to Draft', 'el-core' ),
            'variant' => 'secondary',
            'icon'    => 'undo',
            'class'   => 'el-es-uj-reset-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id ],
        ] );
        $p_uj .= '</div>';
    }

    // ── approved ──
    if ( $jstatus === 'approved' ) {
        $p_uj .= EL_Admin_UI::notice( [
            'message' => __( '<strong>Client Approved.</strong> Lock this journey to contribute to the Phase 5 gate.', 'el-core' ),
            'type'    => 'warning',
        ] );
        $approved_wf = $jny->admin_workflow ? json_decode( $jny->admin_workflow, true ) : null;
        if ( $approved_wf && ! empty( $approved_wf['summary'] ) ) {
            $p_uj .= '<p class="el-es-uj-summary">' . esc_html( $approved_wf['summary'] ) . '</p>';
        }
        $p_uj .= '<div class="el-es-uj-btn-row">';
        $p_uj .= EL_Admin_UI::btn( [
            'label'   => __( 'Lock Journey', 'el-core' ),
            'variant' => 'primary',
            'icon'    => 'lock',
            'class'   => 'el-es-uj-lock-btn',
            'data'    => [ 'journey-id' => $jid, 'project-id' => $project_id ],
        ] );
        $p_uj .= '</div>';
    }

    // ── locked ──
    if ( $jstatus === 'locked' ) {
        $locked_wf = $jny->admin_workflow ? json_decode( $jny->admin_workflow, true ) : ( $jny->ai_workflow ? json_decode( $jny->ai_workflow, true ) : null );
        if ( $locked_wf ) {
            if ( ! empty( $locked_wf['summary'] ) ) {
                $p_uj .= '<p class="el-es-uj-summary">' . esc_html( $locked_wf['summary'] ) . '</p>';
            }
            if ( ! empty( $locked_wf['steps'] ) ) {
                $p_uj .= '<ol class="el-es-uj-steps">';
                foreach ( $locked_wf['steps'] as $step ) {
                    $p_uj .= '<li><strong>' . esc_html( $step['label'] ?? '' ) . '</strong>: ' . esc_html( $step['description'] ?? '' ) . '</li>';
                }
                $p_uj .= '</ol>';
            }
            if ( ! empty( $locked_wf['implied_pages'] ) ) {
                $p_uj .= '<p class="el-es-uj-implied"><strong>' . __( 'Implied pages:', 'el-core' ) . '</strong> ' . esc_html( implode( ', ', $locked_wf['implied_pages'] ) ) . '</p>';
            }
        }
        $p_uj .= '<div class="el-es-uj-locked-badge">';
        $p_uj .= EL_Admin_UI::badge( [ 'label' => __( '🔒 Locked', 'el-core' ), 'variant' => 'success' ] );
        if ( $jny->locked_at ) {
            $locked_by_user = $jny->locked_by ? get_userdata( (int) $jny->locked_by ) : null;
            $p_uj .= '<span class="el-es-uj-lock-meta"> ' . sprintf(
                __( 'Locked %s by %s', 'el-core' ),
                esc_html( date_i18n( 'M j, Y', strtotime( $jny->locked_at ) ) ),
                esc_html( $locked_by_user ? $locked_by_user->display_name : __( 'Admin', 'el-core' ) )
            ) . '</span>';
        }
        $p_uj .= '</div>';
    }

    $p_uj .= '</div>'; // end card body
    $p_uj .= '</div>'; // end card
}

// Inline "Send for Review" deadline modals (one per admin_refined journey)
foreach ( $journeys as $jny ) {
    if ( $jny->status !== 'admin_refined' ) continue;
    $jid        = (int) $jny->id;
    $srf_form   = '<form class="el-es-uj-send-review-form" data-journey-id="' . esc_attr( $jid ) . '" data-project-id="' . esc_attr( $project_id ) . '">';
    $srf_form  .= '<input type="hidden" name="journey_id" value="' . esc_attr( $jid ) . '">';
    $srf_form  .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
    $srf_form  .= EL_Admin_UI::form_row( [
        'name'  => 'deadline',
        'label' => __( 'Review deadline (optional)', 'el-core' ),
        'type'  => 'date',
        'help'  => __( 'Stakeholders will have until this date to provide input.', 'el-core' ),
    ] );
    $srf_form  .= '<div class="el-form-row">';
    $srf_form  .= EL_Admin_UI::btn( [ 'label' => __( 'Send for Review', 'el-core' ), 'variant' => 'primary', 'icon' => 'email-alt', 'type' => 'submit' ] );
    $srf_form  .= '</div>';
    $srf_form  .= '</form>';
    $p_uj .= EL_Admin_UI::modal( [
        'id'      => 'send-journey-review-modal-' . $jid,
        'title'   => sprintf( __( 'Send %s Journey for Review', 'el-core' ), esc_html( $jny->user_type ) ),
        'content' => $srf_form,
    ] );
}

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'phase-4',
    'group'   => 'phase-tabs',
    'content' => EL_Admin_UI::card( [
        'title'   => __( 'User Journey', 'el-core' ),
        'icon'    => 'networking',
        'content' => $p_uj,
    ] ),
    'active'  => $current_stage === 4,
] );

// ── Phase 5: Visual Identity ──
$p4 = '';
$review_items = $module->get_review_items( $project_id, 'mood_board' );

$p4 .= '<div id="es-branding-tab" data-project-id="' . esc_attr( $project_id ) . '">';

if ( empty( $review_items ) ) {
    $p4 .= EL_Admin_UI::notice( [
        'message' => __( 'No mood board review sessions for this project yet. Create one to let your team vote on style direction.', 'el-core' ),
        'type'    => 'info',
    ] );
} else {
    foreach ( $review_items as $ri ) {
        $dm_dec    = $ri->dm_decision ? json_decode( $ri->dm_decision, true ) : [];
        $sel_ids   = $dm_dec['selected_template_ids'] ?? [];
        $conf_ids  = $dm_dec['confirmed_template_ids'] ?? [];
        $is_closed = ( $ri->status === 'closed' );

        $all_votes  = $module->get_review_votes( (int) $ri->id );
        $voted_ids  = array_map( fn( $v ) => (int) $v->user_id, $all_votes );
        $sh_all     = $module->get_stakeholders( $project_id );
        $total_sh   = count( $sh_all );
        $responded  = count( array_filter( $sh_all, fn( $s ) => in_array( (int) $s->user_id, $voted_ids, true ) ) );

        $badge_class = $is_closed ? 'el-badge el-badge-success' : 'el-badge el-badge-warning';
        $badge_label = $is_closed ? __( 'Closed', 'el-core' ) : __( 'Open', 'el-core' );

        $p4 .= '<div class="el-card" style="margin-bottom:20px;">';
        $p4 .= '<div class="el-card__header" style="display:flex;justify-content:space-between;align-items:center;">';
        $p4 .= '<h3 class="el-card__title">' . esc_html( $ri->title ) . '</h3>';
        $p4 .= '<span class="' . $badge_class . '">' . $badge_label . '</span>';
        $p4 .= '</div><div class="el-card__body">';

        $p4 .= EL_Admin_UI::detail_row( [ 'label' => __( 'Templates selected', 'el-core' ), 'value' => count( $sel_ids ), 'icon' => 'images-alt2' ] );
        $p4 .= EL_Admin_UI::detail_row( [
            'label' => __( 'Responses', 'el-core' ),
            'value' => sprintf( __( '%1$d of %2$d team members', 'el-core' ), $responded, $total_sh ),
            'icon'  => 'groups',
        ] );

        if ( $ri->deadline ) {
            $p4 .= EL_Admin_UI::detail_row( [
                'label' => __( 'Deadline', 'el-core' ),
                'value' => date_i18n( 'M j, Y', strtotime( $ri->deadline ) ),
                'icon'  => 'calendar-alt',
            ] );
        }

        if ( $is_closed && ! empty( $conf_ids ) ) {
            $tbl    = $wpdb->prefix . 'el_es_templates';
            $ph     = implode( ',', array_fill( 0, count( $conf_ids ), '%d' ) );
            $ctpl   = $wpdb->get_results( $wpdb->prepare( "SELECT title FROM {$tbl} WHERE id IN ({$ph})", ...$conf_ids ) );
            $labels = implode( ', ', array_map( fn( $t ) => esc_html( $t->title ), $ctpl ) );
            $p4    .= EL_Admin_UI::detail_row( [ 'label' => __( 'Confirmed Direction', 'el-core' ), 'value' => $labels, 'icon' => 'yes-alt' ] );
        }

        $p4 .= '<div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;">';
        if ( ! $is_closed ) {
            $p4 .= EL_Admin_UI::btn( [
                'label'   => $ri->deadline ? __( 'Extend Deadline', 'el-core' ) : __( 'Set Deadline', 'el-core' ),
                'variant' => 'secondary',
                'icon'    => 'calendar-alt',
                'data'    => [ 'action' => 'set-review-deadline', 'review-item-id' => $ri->id ],
            ] );
        }
        $p4 .= '</div>';
        $p4 .= '</div></div>';
    }
}

$p4 .= EL_Admin_UI::btn( [
    'label'   => __( 'Create Mood Board Session', 'el-core' ),
    'variant' => 'primary',
    'icon'    => 'plus-alt',
    'data'    => [ 'modal-open' => 'create-review-modal' ],
] );

$p4 .= '</div>';

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'phase-5',
    'group'   => 'phase-tabs',
    'content' => EL_Admin_UI::card( [ 'title' => __( 'Visual Identity — Branding Review', 'el-core' ), 'icon' => 'art', 'content' => $p4 ] ),
    'active'  => $current_stage === 5,
] );

// ── Phase 5: Wireframes ──
$page_rows = [];
foreach ( $pages as $pg ) {
    $pg_status_badge = EL_Admin_UI::badge( [
        'label'   => ucfirst( str_replace( '_', ' ', $pg->status ) ),
        'variant' => match ( $pg->status ) {
            'approved'    => 'success',
            'review'      => 'warning',
            'in_progress' => 'info',
            default       => 'default',
        },
    ] );

    $pg_url = $pg->page_url
        ? '<a href="' . esc_url( $pg->page_url ) . '" target="_blank">' . esc_html( $pg->page_url ) . '</a>'
        : '—';

    $page_rows[] = [
        'name'   => '<strong>' . esc_html( $pg->page_name ) . '</strong>',
        'url'    => $pg_url,
        'status' => $pg_status_badge,
    ];
}

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'phase-6',
    'group'   => 'phase-tabs',
    'content' => EL_Admin_UI::card( [
        'title'   => __( 'Wireframe Pages', 'el-core' ),
        'icon'    => 'admin-page',
        'content' => EL_Admin_UI::data_table( [
            'columns' => [
                [ 'key' => 'name',   'label' => __( 'Page Name', 'el-core' ) ],
                [ 'key' => 'url',    'label' => __( 'URL', 'el-core' ) ],
                [ 'key' => 'status', 'label' => __( 'Status', 'el-core' ) ],
            ],
            'rows'  => $page_rows,
            'empty' => [
                'icon'    => 'admin-page',
                'title'   => __( 'No wireframe pages yet', 'el-core' ),
                'message' => __( 'Add pages to track wireframe progress.', 'el-core' ),
                'action'  => [ 'label' => __( 'Add Page', 'el-core' ), 'variant' => 'primary', 'data' => [ 'modal-open' => 'add-page-modal' ] ],
            ],
        ] ),
        'actions' => [
            [ 'label' => __( 'Add Page', 'el-core' ), 'variant' => 'secondary', 'icon' => 'plus-alt', 'data' => [ 'modal-open' => 'add-page-modal' ] ],
        ],
    ] ),
    'active'  => $current_stage === 6,
] );

// ── Phase 7: Final Design ──
$p6  = EL_Admin_UI::notice( [
    'message' => __( '<strong>Final Design phase</strong> — Full-color mockups and client content entry. Content entry and design approval tools are coming in a future update.', 'el-core' ),
    'type'    => 'info',
] );

// Show same pages list, labelled as design pages
$p6 .= EL_Admin_UI::card( [
    'title'   => __( 'Design & Content Pages', 'el-core' ),
    'icon'    => 'admin-page',
    'content' => EL_Admin_UI::data_table( [
        'columns' => [
            [ 'key' => 'name',   'label' => __( 'Page Name', 'el-core' ) ],
            [ 'key' => 'url',    'label' => __( 'URL', 'el-core' ) ],
            [ 'key' => 'status', 'label' => __( 'Status', 'el-core' ) ],
        ],
        'rows'  => $page_rows,
        'empty' => [
            'icon'    => 'admin-page',
            'title'   => __( 'No pages yet', 'el-core' ),
            'message' => __( 'Pages are managed in Phase 5 (Wireframes).', 'el-core' ),
        ],
    ] ),
] );

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'phase-7',
    'group'   => 'phase-tabs',
    'content' => $p6,
    'active'  => $current_stage === 7,
] );

// ── Phase 8: Build ──
$del_rows = [];
foreach ( $deliverables as $d ) {
    $review_badge = EL_Admin_UI::badge( [
        'label'   => ucfirst( str_replace( '_', ' ', $d->review_status ) ),
        'variant' => match ( $d->review_status ) {
            'approved'       => 'success',
            'needs_revision' => 'warning',
            default          => 'default',
        },
    ] );

    $file_link = $d->file_url
        ? '<a href="' . esc_url( $d->file_url ) . '" target="_blank">' . esc_html( $d->file_type ?: __( 'View', 'el-core' ) ) . '</a>'
        : '—';

    $del_actions  = EL_Admin_UI::btn( [ 'label' => __( 'Approve', 'el-core' ), 'variant' => 'ghost', 'icon' => 'yes',  'class' => 'el-es-review-btn', 'data' => [ 'id' => $d->id, 'status' => 'approved' ] ] );
    $del_actions .= EL_Admin_UI::btn( [ 'label' => __( 'Revise', 'el-core' ),  'variant' => 'ghost', 'icon' => 'edit', 'class' => 'el-es-review-btn', 'data' => [ 'id' => $d->id, 'status' => 'needs_revision' ] ] );

    $del_rows[] = [
        'title'  => '<strong>' . esc_html( $d->title ) . '</strong>'
                  . ( $d->description ? '<br><small>' . esc_html( wp_trim_words( $d->description, 15 ) ) . '</small>' : '' ),
        'stage'  => EL_Admin_UI::badge( [
            'label'   => (int) $d->stage . '. ' . EL_Expand_Site_Module::get_stage_name( (int) $d->stage ),
            'variant' => EL_Expand_Site_Module::get_stage_badge_variant( (int) $d->stage ),
        ] ),
        'file'   => $file_link,
        'status' => $review_badge,
        '__actions' => $del_actions,
    ];
}

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'phase-8',
    'group'   => 'phase-tabs',
    'content' => EL_Admin_UI::card( [
        'title'   => __( 'Build — Deliverables', 'el-core' ),
        'icon'    => 'media-document',
        'content' => EL_Admin_UI::data_table( [
            'columns' => [
                [ 'key' => 'title',  'label' => __( 'Deliverable', 'el-core' ) ],
                [ 'key' => 'stage',  'label' => __( 'Stage', 'el-core' ) ],
                [ 'key' => 'file',   'label' => __( 'File', 'el-core' ) ],
                [ 'key' => 'status', 'label' => __( 'Review', 'el-core' ) ],
            ],
            'rows'  => $del_rows,
            'empty' => [
                'icon'    => 'media-document',
                'title'   => __( 'No deliverables yet', 'el-core' ),
                'message' => __( 'Add deliverables for the client to review.', 'el-core' ),
                'action'  => [ 'label' => __( 'Add Deliverable', 'el-core' ), 'variant' => 'primary', 'data' => [ 'modal-open' => 'add-deliverable-modal' ] ],
            ],
        ] ),
        'actions' => [
            [ 'label' => __( 'Add Deliverable', 'el-core' ), 'variant' => 'secondary', 'icon' => 'plus-alt', 'data' => [ 'modal-open' => 'add-deliverable-modal' ] ],
        ],
    ] ),
    'active'  => $current_stage === 8,
] );

// ── Phase 9: Delivery ──
$fb_rows = [];
foreach ( $feedback as $fb ) {
    $fb_user = get_userdata( $fb->user_id );
    $fb_type = EL_Admin_UI::badge( [
        'label'   => ucfirst( str_replace( '_', ' ', $fb->feedback_type ) ),
        'variant' => match ( $fb->feedback_type ) {
            'approval'     => 'success',
            'change_order' => 'error',
            'question'     => 'info',
            default        => 'default',
        },
    ] );

    $fb_status_badge = EL_Admin_UI::badge( [
        'label'   => ucfirst( $fb->status ),
        'variant' => match ( $fb->status ) {
            'resolved'     => 'success',
            'acknowledged' => 'info',
            'deferred'     => 'warning',
            default        => 'default',
        },
    ] );

    $co_flag = '';
    if ( $fb->is_change_order ) {
        $co_flag = ' ' . EL_Admin_UI::badge( [ 'label' => '$' . number_format( $fb->change_order_price, 0 ), 'variant' => 'error' ] );
    }

    $fb_actions = '';
    if ( $fb->status === 'pending' ) {
        $fb_actions .= EL_Admin_UI::btn( [ 'label' => __( 'Ack', 'el-core' ),    'variant' => 'ghost', 'class' => 'el-es-feedback-btn', 'data' => [ 'id' => $fb->id, 'status' => 'acknowledged' ] ] );
        $fb_actions .= EL_Admin_UI::btn( [ 'label' => __( 'Resolve', 'el-core' ), 'variant' => 'ghost', 'class' => 'el-es-feedback-btn', 'data' => [ 'id' => $fb->id, 'status' => 'resolved' ] ] );
    }

    $fb_rows[] = [
        'content'   => '<div>' . wp_kses_post( wp_trim_words( $fb->content, 25 ) ) . '</div>' . $co_flag,
        'type'      => $fb_type,
        'stage'     => EL_Admin_UI::badge( [
            'label'   => (int) $fb->stage . '. ' . $module->get_stage_name( (int) $fb->stage ),
            'variant' => EL_Expand_Site_Module::get_stage_badge_variant( (int) $fb->stage ),
        ] ),
        'by'        => $fb_user ? esc_html( $fb_user->display_name ) : '—',
        'status'    => $fb_status_badge,
        'date'      => date_i18n( 'M j, Y', strtotime( $fb->created_at ) ),
        '__actions' => $fb_actions,
    ];
}

// Deliverables summary for Phase 8
$p8_del_count  = count( $deliverables );
$p8_del_notice = sprintf(
    /* translators: %1$d = deliverable count */
    _n( '%1$d deliverable tracked.', '%1$d deliverables tracked.', $p8_del_count, 'el-core' ),
    $p8_del_count
);

$p8  = EL_Admin_UI::notice( [
    'message' => $p8_del_notice . ' ' . __( 'See Phase 7 (Build) for the full deliverables list.', 'el-core' ),
    'type'    => 'info',
] );

$p8 .= EL_Admin_UI::data_table( [
    'columns' => [
        [ 'key' => 'content', 'label' => __( 'Feedback', 'el-core' ) ],
        [ 'key' => 'type',    'label' => __( 'Type', 'el-core' ) ],
        [ 'key' => 'stage',   'label' => __( 'Stage', 'el-core' ) ],
        [ 'key' => 'by',      'label' => __( 'From', 'el-core' ) ],
        [ 'key' => 'status',  'label' => __( 'Status', 'el-core' ) ],
        [ 'key' => 'date',    'label' => __( 'Date', 'el-core' ) ],
    ],
    'rows'  => $fb_rows,
    'empty' => [ 'icon' => 'format-chat', 'title' => __( 'No feedback yet', 'el-core' ) ],
] );

$html .= EL_Admin_UI::tab_panel( [
    'id'      => 'phase-9',
    'group'   => 'phase-tabs',
    'content' => EL_Admin_UI::card( [
        'title'   => __( 'Delivery — Client Feedback', 'el-core' ),
        'icon'    => 'format-chat',
        'content' => $p8,
    ] ),
    'active'  => $current_stage === 9,
] );

// ═══════════════════════════════════════════
// MODALS
// ═══════════════════════════════════════════

// Advance Stage modal
$next_stage            = min( $current_stage + 1, 9 );
$default_deadline_days = $module->get_stage_deadline_days( $next_stage );
$default_deadline      = date( 'Y-m-d', strtotime( "+{$default_deadline_days} days" ) );

$advance_form  = '<form id="advance-stage-form">';
$advance_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$advance_form .= EL_Admin_UI::notice( [
    'message' => sprintf(
        __( 'This will approve <strong>Phase %d (%s)</strong> and advance to <strong>Phase %d (%s)</strong>.', 'el-core' ),
        $current_stage,
        $module->get_stage_name( $current_stage ),
        $next_stage,
        $module->get_stage_name( $next_stage )
    ),
    'type' => 'info',
] );
$advance_form .= EL_Admin_UI::form_row( [
    'name'  => 'deadline',
    'label' => __( 'Set Deadline for Next Phase', 'el-core' ),
    'type'  => 'date',
    'value' => $default_deadline,
    'help'  => sprintf( __( 'Default: %d days from today', 'el-core' ), $default_deadline_days ),
] );
$advance_form .= EL_Admin_UI::form_row( [
    'name'        => 'notes',
    'label'       => __( 'Approval Notes', 'el-core' ),
    'type'        => 'textarea',
    'placeholder' => __( 'Optional notes about this phase approval...', 'el-core' ),
] );
$advance_form .= '<div class="el-form-row">';
$advance_form .= EL_Admin_UI::btn( [ 'label' => __( 'Approve & Advance', 'el-core' ), 'variant' => 'primary', 'icon' => 'yes', 'type' => 'submit' ] );
$advance_form .= '</div>';
$advance_form .= '</form>';

$html .= EL_Admin_UI::modal( [
    'id'      => 'advance-stage-modal',
    'title'   => __( 'Advance to Next Phase', 'el-core' ),
    'content' => $advance_form,
] );

// Send Definition for Review modal
$default_review_deadline = date( 'Y-m-d', strtotime( '+7 days' ) );
$send_review_form  = '<form id="send-definition-review-form">';
$send_review_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$send_review_form .= EL_Admin_UI::form_row( [
    'name'   => 'deadline',
    'label'  => __( 'Response Deadline', 'el-core' ),
    'type'   => 'date',
    'value'  => $default_review_deadline,
    'helper' => __( 'Stakeholders must respond by this date. Decision Maker can decide after deadline even if others haven\'t responded.', 'el-core' ),
] );
$send_review_form .= '<div class="el-form-row">';
$send_review_form .= EL_Admin_UI::btn( [ 'label' => __( 'Send for Review', 'el-core' ), 'variant' => 'primary', 'icon' => 'email', 'type' => 'submit' ] );
$send_review_form .= '</div>';
$send_review_form .= '</form>';

$html .= EL_Admin_UI::modal( [
    'id'      => 'send-definition-review-modal',
    'title'   => __( 'Send Definition to Client for Review', 'el-core' ),
    'content' => $send_review_form,
] );

// Add Deliverable modal
$del_form  = '<form id="add-deliverable-form">';
$del_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$del_form .= '<input type="hidden" name="stage" value="' . esc_attr( $current_stage ) . '">';
$del_form .= EL_Admin_UI::form_row( [ 'name' => 'title',       'label' => __( 'Title', 'el-core' ),       'required' => true, 'placeholder' => __( 'e.g., Homepage Design', 'el-core' ) ] );
$del_form .= EL_Admin_UI::form_row( [ 'name' => 'description', 'label' => __( 'Description', 'el-core' ), 'type' => 'textarea' ] );
$del_form .= EL_Admin_UI::form_row( [ 'name' => 'file_url',    'label' => __( 'File URL', 'el-core' ),    'type' => 'url', 'placeholder' => 'https://' ] );
$del_form .= EL_Admin_UI::form_row( [
    'name'    => 'file_type',
    'label'   => __( 'File Type', 'el-core' ),
    'type'    => 'select',
    'options' => [
        ''         => __( 'Select type...', 'el-core' ),
        'pdf'      => 'PDF',
        'image'    => __( 'Image', 'el-core' ),
        'link'     => __( 'Link', 'el-core' ),
        'document' => __( 'Document', 'el-core' ),
    ],
] );
$del_form .= '<div class="el-form-row">';
$del_form .= EL_Admin_UI::btn( [ 'label' => __( 'Add Deliverable', 'el-core' ), 'variant' => 'primary', 'icon' => 'plus-alt', 'type' => 'submit' ] );
$del_form .= '</div>';
$del_form .= '</form>';

$html .= EL_Admin_UI::modal( [
    'id'      => 'add-deliverable-modal',
    'title'   => __( 'Add Deliverable', 'el-core' ),
    'content' => $del_form,
] );

// Add Page modal
$page_form  = '<form id="add-page-form">';
$page_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$page_form .= EL_Admin_UI::form_row( [ 'name' => 'page_name',  'label' => __( 'Page Name', 'el-core' ),  'required' => true, 'placeholder' => __( 'e.g., Homepage, About Us', 'el-core' ) ] );
$page_form .= EL_Admin_UI::form_row( [ 'name' => 'page_url',   'label' => __( 'Page URL', 'el-core' ),   'type' => 'url', 'placeholder' => 'https://' ] );
$page_form .= EL_Admin_UI::form_row( [ 'name' => 'sort_order', 'label' => __( 'Sort Order', 'el-core' ), 'type' => 'number', 'value' => '0' ] );
$page_form .= '<div class="el-form-row">';
$page_form .= EL_Admin_UI::btn( [ 'label' => __( 'Add Page', 'el-core' ), 'variant' => 'primary', 'icon' => 'plus-alt', 'type' => 'submit' ] );
$page_form .= '</div>';
$page_form .= '</form>';

$html .= EL_Admin_UI::modal( [
    'id'      => 'add-page-modal',
    'title'   => __( 'Add Page', 'el-core' ),
    'content' => $page_form,
] );

// Add Stakeholder modal
$org_contacts_html = '';
$org_id = absint( $project->organization_id ?? 0 );
if ( $org_id && isset( $core ) && $core->organizations ) {
    $org_contacts = $core->organizations->get_contacts( $org_id );
    $existing_stakeholder_user_ids = array_map( fn( $s ) => (int) $s->user_id, $stakeholders );

    $available_contacts = array_filter( $org_contacts, fn( $c ) =>
        $c->user_id > 0 && ! in_array( (int) $c->user_id, $existing_stakeholder_user_ids, true )
    );

    if ( ! empty( $available_contacts ) ) {
        $org_contacts_html .= '<div style="margin-bottom:18px;">';
        $org_contacts_html .= '<p style="font-weight:600;margin:0 0 8px;font-size:13px;color:#374151;">' . __( 'Contacts from this organization:', 'el-core' ) . '</p>';
        $org_contacts_html .= '<div style="display:flex;flex-direction:column;gap:6px;">';
        foreach ( $available_contacts as $oc ) {
            $role_default = $oc->is_primary ? 'dm' : 'c';
            $badge        = $oc->is_primary
                ? ' <span style="font-size:10px;background:#dbeafe;color:#1d4ed8;padding:1px 6px;border-radius:9px;font-weight:600;">Primary</span>'
                : '';
            $org_contacts_html .= '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 10px;background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;">';
            $org_contacts_html .= '<div>';
            $org_contacts_html .= '<strong style="font-size:13px;">' . esc_html( $oc->first_name . ' ' . $oc->last_name ) . '</strong>' . $badge;
            if ( $oc->title ) {
                $org_contacts_html .= '<br><span style="font-size:12px;color:#6b7280;">' . esc_html( $oc->title ) . '</span>';
            }
            $org_contacts_html .= '</div>';
            $org_contacts_html .= '<button type="button" class="el-btn el-btn-secondary el-quick-add-stakeholder-btn" '
                . 'style="font-size:12px;padding:4px 10px;" '
                . 'data-user-id="' . esc_attr( $oc->user_id ) . '" '
                . 'data-name="' . esc_attr( $oc->first_name . ' ' . $oc->last_name ) . '" '
                . 'data-role="' . esc_attr( $role_default ) . '" '
                . 'data-project-id="' . esc_attr( $project_id ) . '">'
                . __( 'Add', 'el-core' )
                . '</button>';
            $org_contacts_html .= '</div>';
        }
        $org_contacts_html .= '</div>';
        $org_contacts_html .= '<hr style="margin:14px 0;border:none;border-top:1px solid #e5e7eb;">';
        $org_contacts_html .= '</div>';
    }
}

$stakeholder_form  = '<form id="add-stakeholder-form">';
$stakeholder_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
if ( $org_contacts_html ) {
    $stakeholder_form .= $org_contacts_html;
}
$stakeholder_form .= EL_Admin_UI::notice( [
    'message' => __( 'Search for an existing WordPress user or enter an email to create a new user account.', 'el-core' ),
    'type'    => 'info',
] );
$stakeholder_form .= '<div class="el-form-row">';
$stakeholder_form .= '<label for="stakeholder-user-search" class="el-form-label">' . __( 'Search User', 'el-core' ) . '</label>';
$stakeholder_form .= '<div class="el-form-field">';
$stakeholder_form .= '<input type="text" id="stakeholder-user-search" name="user_search" class="el-input" placeholder="' . esc_attr__( 'Start typing name or email...', 'el-core' ) . '">';
$stakeholder_form .= '</div></div>';
$stakeholder_form .= '<div id="user-search-results" style="display:none;margin-bottom:15px;padding:10px;background:#f5f5f5;border-radius:4px;"></div>';
$stakeholder_form .= '<input type="hidden" name="user_id" id="selected-user-id">';
$stakeholder_form .= EL_Admin_UI::form_row( [ 'name' => 'new_user_email',      'label' => __( 'Or Create New User (Email)', 'el-core' ), 'type' => 'email', 'placeholder' => __( 'email@example.com', 'el-core' ) ] );
$stakeholder_form .= EL_Admin_UI::form_row( [ 'name' => 'new_user_first_name', 'label' => __( 'First Name', 'el-core' ),                 'type' => 'text',  'placeholder' => __( 'John', 'el-core' ) ] );
$stakeholder_form .= EL_Admin_UI::form_row( [ 'name' => 'new_user_last_name',  'label' => __( 'Last Name', 'el-core' ),                  'type' => 'text',  'placeholder' => __( 'Doe', 'el-core' ) ] );
$stakeholder_form .= EL_Admin_UI::form_row( [
    'name'    => 'role',
    'label'   => __( 'Role', 'el-core' ),
    'type'    => 'select',
    'options' => [
        'c'  => __( 'Contributor (can provide input)', 'el-core' ),
        'dm' => __( 'Decision Maker (can approve/lock)', 'el-core' ),
    ],
] );
$stakeholder_form .= '<div class="el-form-row">';
$stakeholder_form .= EL_Admin_UI::btn( [ 'label' => __( 'Add Stakeholder', 'el-core' ), 'variant' => 'primary', 'icon' => 'plus-alt', 'type' => 'submit' ] );
$stakeholder_form .= '</div>';
$stakeholder_form .= '</form>';

$html .= EL_Admin_UI::modal( [
    'id'      => 'add-stakeholder-modal',
    'title'   => __( 'Add Stakeholder', 'el-core' ),
    'content' => $stakeholder_form,
] );

// Proposal Edit Modal
$edit_proposal_form  = '<form id="edit-proposal-form">';
$edit_proposal_form .= '<input type="hidden" name="proposal_id" id="edit-proposal-id" value="">';
$edit_proposal_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$edit_proposal_form .= '<div style="display:flex;gap:10px;margin-bottom:15px;">';
$edit_proposal_form .= EL_Admin_UI::btn( [ 'label' => __( 'Generate with AI', 'el-core' ), 'variant' => 'secondary', 'icon' => 'admin-generic', 'id' => 'generate-proposal-ai-btn', 'data' => [ 'project-id' => $project_id ] ] );
$edit_proposal_form .= '<span id="ai-proposal-status" style="line-height:36px;color:#666;"></span>';
$edit_proposal_form .= '</div>';
$edit_proposal_form .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;">';
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'proposal_title',     'label' => __( 'Proposal Title', 'el-core' ),  'required' => true, 'id' => 'prop-title' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'client_name',        'label' => __( 'Client Name', 'el-core' ),     'id' => 'prop-client-name' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'client_organization','label' => __( 'Organization', 'el-core' ),    'id' => 'prop-client-org' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'client_email',       'label' => __( 'Client Email', 'el-core' ),    'type' => 'email', 'id' => 'prop-client-email' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'project_dates',      'label' => __( 'Project Dates', 'el-core' ),   'placeholder' => 'e.g., March–May 2026', 'id' => 'prop-dates' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'project_location',   'label' => __( 'Location', 'el-core' ),        'id' => 'prop-location' ] );
$edit_proposal_form .= '</div>';
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_situation',    'label' => __( 'Situation', 'el-core' ),            'type' => 'textarea', 'id' => 'prop-situation',    'help' => __( 'Mirror the client\'s specific problem back to them.', 'el-core' ) ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_what_we_build','label' => __( 'What We\'re Building', 'el-core' ), 'type' => 'textarea', 'id' => 'prop-what-we-build', 'help' => __( 'Describe capabilities by user type.', 'el-core' ) ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_why_els',      'label' => __( 'Why ELS', 'el-core' ),               'type' => 'textarea', 'id' => 'prop-why-els',      'help' => __( 'Why Expanded Learning Solutions is the right partner.', 'el-core' ) ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_investment',   'label' => __( 'Investment', 'el-core' ),            'type' => 'textarea', 'id' => 'prop-investment',   'help' => __( 'Development cost + annual platform fee + ROI comparison.', 'el-core' ) ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'section_next_steps',   'label' => __( 'Next Steps', 'el-core' ),            'type' => 'textarea', 'id' => 'prop-next-steps',   'help' => __( 'Specific steps that happen after acceptance.', 'el-core' ) ] );
$edit_proposal_form .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;">';
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'final_price',           'label' => __( 'Final Price ($)', 'el-core' ),              'type' => 'number', 'id' => 'prop-final-price' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'annual_platform_fee',   'label' => __( 'Annual Platform Fee ($)', 'el-core' ),       'type' => 'number', 'id' => 'prop-platform-fee' ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'first_payment_amount',  'label' => __( 'First Payment (25%) Amount ($)', 'el-core' ), 'type' => 'number', 'id' => 'prop-first-payment', 'help' => __( 'Auto-calculated as 25% of final price. Override if needed.', 'el-core' ) ] );
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'final_payment_amount',  'label' => __( 'Final Payment (75%) Amount ($)', 'el-core' ), 'type' => 'number', 'id' => 'prop-final-payment', 'help' => __( 'Auto-calculated as 75% of final price. Override if needed.', 'el-core' ) ] );
$edit_proposal_form .= '</div>';
$edit_proposal_form .= EL_Admin_UI::form_row( [ 'name' => 'terms_conditions', 'label' => __( 'Terms & Conditions', 'el-core' ), 'type' => 'textarea', 'id' => 'prop-terms' ] );
$edit_proposal_form .= '<div class="el-form-row">';
$edit_proposal_form .= EL_Admin_UI::btn( [ 'label' => __( 'Save Proposal', 'el-core' ), 'variant' => 'primary', 'icon' => 'saved', 'type' => 'submit' ] );
$edit_proposal_form .= '</div>';
$edit_proposal_form .= '</form>';

$html .= EL_Admin_UI::modal( [
    'id'      => 'edit-proposal-modal',
    'title'   => __( 'Edit Proposal', 'el-core' ),
    'content' => $edit_proposal_form,
    'size'    => 'large',
] );

// Proposal data for JS
$proposals_json = [];
foreach ( $proposals as $prop ) {
    $proposals_json[ $prop->id ] = [
        'id'                     => $prop->id,
        'proposal_title'         => $prop->proposal_title,
        'client_name'            => $prop->client_name,
        'client_organization'    => $prop->client_organization,
        'client_email'           => $prop->client_email,
        'project_dates'          => $prop->project_dates,
        'project_location'       => $prop->project_location,
        'scope_description'      => $prop->scope_description,
        'goals_objectives'       => $prop->goals_objectives,
        'activities_description' => $prop->activities_description,
        'deliverables_text'      => $prop->deliverables_text,
        'section_situation'      => $prop->section_situation ?? '',
        'section_what_we_build'  => $prop->section_what_we_build ?? '',
        'section_why_els'        => $prop->section_why_els ?? '',
        'section_investment'     => $prop->section_investment ?? '',
        'section_next_steps'     => $prop->section_next_steps ?? '',
        'budget_low'             => $prop->budget_low,
        'budget_high'            => $prop->budget_high,
        'final_price'            => $prop->final_price,
        'annual_platform_fee'    => $prop->annual_platform_fee ?? 0,
        'first_payment_amount'   => $prop->first_payment_amount ?? 0,
        'final_payment_amount'   => $prop->final_payment_amount ?? 0,
        'payment_terms'          => $prop->payment_terms,
        'terms_conditions'       => $prop->terms_conditions,
        'status'                 => $prop->status,
    ];
}
$html .= '<script>var elProposalsData = ' . wp_json_encode( $proposals_json ) . ';</script>';

// Create Review Session modal (Visual Identity / Phase 4)
$active_templates = $module->get_templates( [ 'is_active' => 1 ] );

$create_review_form  = '<form id="create-review-form">';
$create_review_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$create_review_form .= '<input type="hidden" name="review_type" value="mood_board">';
$create_review_form .= EL_Admin_UI::form_row( [ 'name' => 'title',    'label' => __( 'Session Title', 'el-core' ),           'type' => 'text', 'value' => __( 'Style Direction', 'el-core' ), 'placeholder' => __( 'e.g. Style Direction', 'el-core' ) ] );
$create_review_form .= EL_Admin_UI::form_row( [ 'name' => 'deadline', 'label' => __( 'Response Deadline (optional)', 'el-core' ), 'type' => 'date' ] );
$create_review_form .= '<div class="el-form-row">';
$create_review_form .= '<label class="el-form-label">' . __( 'Select Templates for This Client', 'el-core' ) . '</label>';
$create_review_form .= '<div class="el-form-field">';

if ( empty( $active_templates ) ) {
    $create_review_form .= '<p style="color:#666;">' . __( 'No active templates found. Add some in the Template Library first.', 'el-core' ) . '</p>';
} else {
    $tpl_by_cat = [];
    foreach ( $active_templates as $tpl ) {
        $tpl_by_cat[ $tpl->style_category ][] = $tpl;
    }
    $create_review_form .= '<div class="es-template-picker">';
    foreach ( $tpl_by_cat as $cat => $cat_tpls ) {
        $create_review_form .= '<div class="es-template-picker-category">';
        $create_review_form .= '<div class="es-template-picker-cat-label">' . esc_html( $cat ) . '</div>';
        $create_review_form .= '<div class="es-template-picker-grid">';
        foreach ( $cat_tpls as $tpl ) {
            $img = esc_url( $tpl->image_url );
            $create_review_form .= '<label class="es-template-picker-card">';
            $create_review_form .= '<input type="checkbox" name="template_ids[]" value="' . esc_attr( $tpl->id ) . '">';
            if ( $img ) {
                $create_review_form .= '<img src="' . $img . '" alt="' . esc_attr( $tpl->title ) . '">';
            } else {
                $create_review_form .= '<div class="es-template-picker-no-img">No Image</div>';
            }
            $create_review_form .= '<div class="es-template-picker-title">' . esc_html( $tpl->title ) . '</div>';
            $create_review_form .= '</label>';
        }
        $create_review_form .= '</div></div>';
    }
    $create_review_form .= '</div>';
}

$create_review_form .= '</div></div>';
$create_review_form .= '<div class="el-form-row">';
$create_review_form .= EL_Admin_UI::btn( [ 'label' => __( 'Create Review Session', 'el-core' ), 'variant' => 'primary', 'icon' => 'plus-alt', 'type' => 'submit' ] );
$create_review_form .= '</div>';
$create_review_form .= '</form>';

$html .= EL_Admin_UI::modal( [
    'id'      => 'create-review-modal',
    'title'   => __( 'Create Mood Board Review Session', 'el-core' ),
    'content' => $create_review_form,
] );

// Add User Type modal (Phase 4)
$aut_form  = '<form id="add-user-type-form">';
$aut_form .= '<input type="hidden" name="project_id" value="' . esc_attr( $project_id ) . '">';
$aut_form .= EL_Admin_UI::form_row( [
    'name'        => 'user_type',
    'label'       => __( 'User Type Name', 'el-core' ),
    'required'    => true,
    'placeholder' => __( 'e.g., Parent, Student, Teacher', 'el-core' ),
    'help'        => __( 'The type of user who will be navigating the site.', 'el-core' ),
] );
$aut_form .= '<div class="el-form-row">';
$aut_form .= EL_Admin_UI::btn( [ 'label' => __( 'Add User Type', 'el-core' ), 'variant' => 'primary', 'icon' => 'plus-alt', 'type' => 'submit' ] );
$aut_form .= '</div>';
$aut_form .= '</form>';

$html .= EL_Admin_UI::modal( [
    'id'      => 'add-user-type-modal',
    'title'   => __( 'Add User Type', 'el-core' ),
    'content' => $aut_form,
] );

echo EL_Admin_UI::wrap( $html );

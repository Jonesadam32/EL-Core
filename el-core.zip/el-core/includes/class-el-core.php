<?php
/**
 * EL Core Orchestrator
 * 
 * Central class that initializes all subsystems in the correct order
 * and provides a single access point for the entire system.
 * 
 * Usage: $core = EL_Core::instance();
 *        $core->settings->get('brand', 'primary_color');
 *        $core->modules->is_active('lms');
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class EL_Core {

    private static ?EL_Core $instance = null;

    // ── Subsystems (public for easy access) ──
    public ?EL_Settings       $settings      = null;
    public ?EL_Database       $database      = null;
    public ?EL_Roles          $roles         = null;
    public ?EL_Module_Loader  $modules       = null;
    public ?EL_Asset_Loader   $assets        = null;
    public ?EL_AJAX_Handler   $ajax          = null;
    public ?EL_AI_Client      $ai            = null;
    public ?EL_Organizations  $organizations = null;

    /**
     * Get the single instance
     */
    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Boot sequence — order matters!
     */
    private function __construct() {
        $this->load_dependencies();
        $this->boot();
    }

    /**
     * Load all core class files
     */
    private function load_dependencies(): void {
        $includes = EL_CORE_DIR . 'includes/';

        require_once $includes . 'class-admin-ui.php';
        require_once $includes . 'class-settings.php';
        require_once $includes . 'class-database.php';
        require_once $includes . 'class-roles.php';
        require_once $includes . 'class-module-loader.php';
        require_once $includes . 'class-asset-loader.php';
        require_once $includes . 'class-ajax-handler.php';
        require_once $includes . 'class-ai-client.php';
        require_once $includes . 'class-organizations.php';
        require_once $includes . 'class-canvas-page.php';
    }

    /**
     * Initialize subsystems in dependency order
     * 
     * Order:
     * 1. Settings    — everything reads config
     * 2. Database    — modules need schema management
     * 3. Roles       — modules need capability checking
     * 4. Modules     — discovers and activates feature modules
     * 5. Assets      — CSS/JS with brand variables
     * 6. AJAX        — request handling
     * 7. AI Client   — shared AI integration
     * 8. Canvas Page — custom page template system
     */
    private function boot(): void {
        // 1. Settings first — everything depends on configuration
        $this->settings = new EL_Settings();

        // 2. Database — modules need tables before they can run
        $this->database = new EL_Database();

        // 3. Roles — modules need capability checking
        $this->roles = new EL_Roles( $this->settings );

        // 4. Module Loader — discovers and activates modules
        $this->modules = new EL_Module_Loader( $this );

        // 5. Asset Loader — CSS/JS with brand injection
        $this->assets = new EL_Asset_Loader( $this->settings );

        // 6. AJAX Handler — standardized request processing
        $this->ajax = new EL_AJAX_Handler();

        // 7. AI Client — shared API wrapper
        $this->ai = new EL_AI_Client( $this->settings );

        // 8. Organizations — core client management infrastructure
        $this->database->ensure_core_tables();
        $this->organizations = new EL_Organizations( $this->database );

        // 9. Canvas Page — AI-generated page system
        EL_Canvas_Page::instance();

        // Hook into WordPress admin
        if ( is_admin() ) {
            $this->init_admin();
        }
    }

    /**
     * Initialize admin-side functionality
     */
    private function init_admin(): void {
        add_action( 'admin_menu', [ $this, 'register_admin_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );

        // Brand settings AJAX handlers
        add_action( 'el_core_ajax_el_analyze_logo',        [ $this, 'ajax_analyze_logo' ] );
        add_action( 'el_core_ajax_el_save_brand_selection', [ $this, 'ajax_save_brand_selection' ] );
    }

    /**
     * Register the EL Core admin menu and subpages
     */
    public function register_admin_menu(): void {
        // Main menu
        add_menu_page(
            'EL Core',                          // Page title
            'EL Core',                          // Menu title
            'manage_options',                   // Capability required
            'el-core',                          // Menu slug
            [ $this, 'render_admin_page' ],     // Callback
            'dashicons-building',               // Icon
            3                                   // Position
        );

        // Explicitly register Dashboard as the first submenu item with the same
        // slug as the parent. This suppresses WordPress's auto-generated duplicate
        // and ensures it stays labeled "Dashboard" when other submenus are added.
        add_submenu_page( 'el-core', 'EL Core Dashboard', 'Dashboard', 'manage_options', 'el-core', [ $this, 'render_admin_page' ] );
        add_submenu_page( 'el-core', 'Brand Settings', 'Brand', 'manage_options', 'el-core-brand', [ $this, 'render_brand_page' ] );
        add_submenu_page( 'el-core', 'Module Manager', 'Modules', 'manage_options', 'el-core-modules', [ $this, 'render_modules_page' ] );
        add_submenu_page( 'el-core', 'Role Manager', 'Roles', 'manage_options', 'el-core-roles', [ $this, 'render_roles_page' ] );
    }

    /**
     * Enqueue admin CSS/JS
     */
    public function enqueue_admin_assets( string $hook ): void {
        // Only load on our pages
        if ( strpos( $hook, 'el-core' ) === false ) {
            return;
        }

        wp_enqueue_style(
            'el-core-admin',
            EL_CORE_URL . 'admin/css/admin.css',
            [],
            EL_CORE_VERSION
        );

        wp_enqueue_script(
            'el-core-admin',
            EL_CORE_URL . 'admin/js/admin.js',
            [ 'jquery' ],
            EL_CORE_VERSION,
            true
        );

        wp_localize_script( 'el-core-admin', 'elAdminData', [
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'el_core_nonce' ),
        ] );

        // Brand page extras
        if ( strpos( $hook, 'el-core-brand' ) !== false ) {
            wp_enqueue_media();

            // Pickr color wheel — enqueued from CDN
            wp_enqueue_style(
                'pickr',
                'https://cdnjs.cloudflare.com/ajax/libs/pickr/1.8.4/themes/classic.min.css',
                [],
                '1.8.4'
            );
            wp_enqueue_script(
                'pickr',
                'https://cdnjs.cloudflare.com/ajax/libs/pickr/1.8.4/pickr.min.js',
                [],
                '1.8.4',
                true
            );
        }
    }

    /**
     * Admin page renderers — load view files
     */
    public function render_admin_page(): void {
        include EL_CORE_DIR . 'admin/views/settings-general.php';
    }

    public function render_brand_page(): void {
        include EL_CORE_DIR . 'admin/views/settings-brand.php';
    }

    public function render_modules_page(): void {
        include EL_CORE_DIR . 'admin/views/settings-modules.php';
    }

    public function render_roles_page(): void {
        include EL_CORE_DIR . 'admin/views/settings-roles.php';
    }

    // ═══════════════════════════════════════════
    // BRAND SETTINGS AJAX HANDLERS
    // ═══════════════════════════════════════════

    /**
     * AJAX: Analyze a logo image and return 3 AI-generated palette options.
     *
     * el_action: el_analyze_logo
     * POST: logo_url (string)
     */
    public function ajax_analyze_logo( array $data ): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            EL_AJAX_Handler::error( 'Permission denied.', 403 );
        }

        $logo_url = esc_url_raw( $data['logo_url'] ?? '' );
        if ( empty( $logo_url ) ) {
            EL_AJAX_Handler::error( 'Missing logo URL.' );
        }

        // Fetch the image
        $response = wp_remote_get( $logo_url, [ 'timeout' => 30 ] );
        if ( is_wp_error( $response ) ) {
            EL_AJAX_Handler::error( 'Could not load image from URL. Try uploading the image to the media library first.' );
        }

        $image_data = wp_remote_retrieve_body( $response );
        if ( empty( $image_data ) ) {
            EL_AJAX_Handler::error( 'Could not load image from URL. The file appears to be empty.' );
        }

        // Detect MIME type from URL extension or Content-Type header
        $content_type = wp_remote_retrieve_header( $response, 'content-type' );
        $content_type = explode( ';', $content_type )[0];
        $allowed_types = [ 'image/jpeg', 'image/png', 'image/gif', 'image/webp' ];

        if ( ! in_array( $content_type, $allowed_types, true ) ) {
            // Try from URL extension
            $ext = strtolower( pathinfo( wp_parse_url( $logo_url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
            $ext_map = [ 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp' ];
            $content_type = $ext_map[ $ext ] ?? 'image/jpeg';
        }

        $image_base64 = base64_encode( $image_data );

        $system_prompt = <<<'PROMPT'
You are a professional brand designer. Analyze the provided logo image and generate exactly 3 distinct brand palette options that would complement it. Each option must feel cohesive with the logo's existing colors and aesthetic.

Return ONLY valid JSON — no markdown, no code fences, no explanation. The response must be parseable by json_decode() with nothing before or after it.

JSON format:
{
  "options": [
    {
      "primary": "#hex",
      "secondary": "#hex",
      "accent": "#hex",
      "font_heading": "Font Name",
      "font_body": "Font Name",
      "rationale": "One sentence explaining the aesthetic direction."
    },
    { ... },
    { ... }
  ]
}

Rules:
- primary: dominant brand color (used for buttons, headings, key UI elements)
- secondary: supporting color (used for backgrounds, cards, secondary UI)
- accent: highlight color (used for CTAs, badges, links)
- Ensure strong contrast between colors for WCAG AA accessibility
- Font names must be real Google Fonts or system fonts
- Each option should represent a meaningfully different aesthetic direction
- Do not repeat the same hex values across options
PROMPT;

        $result = $this->ai->complete_with_image( [
            'system'        => $system_prompt,
            'prompt'        => 'Analyze this logo and return 3 brand palette options in the specified JSON format.',
            'image_base64'  => $image_base64,
            'image_mime'    => $content_type,
            'max_tokens'    => 1024,
        ] );

        if ( ! $result['success'] ) {
            EL_AJAX_Handler::error( $result['error'] ?: 'AI analysis failed.' );
        }

        // Parse the JSON — strip markdown fences if present
        $raw = trim( $result['content'] );
        $raw = preg_replace( '/^```(?:json)?\s*/i', '', $raw );
        $raw = preg_replace( '/\s*```$/', '', $raw );

        $parsed = json_decode( $raw, true );
        if ( ! is_array( $parsed ) || empty( $parsed['options'] ) ) {
            EL_AJAX_Handler::error( 'AI response was not valid JSON. Please try again.' );
        }

        // Save to settings for persistence (so palette cards reload on next visit)
        $this->settings->set( 'brand', 'ai_palette_suggestions', wp_json_encode( $parsed ) );

        wp_send_json_success( [ 'options' => $parsed['options'] ] );
    }

    /**
     * AJAX: Save an AI palette selection (colors + index) to brand settings.
     *
     * el_action: el_save_brand_selection
     * POST: palette_index (int), primary, secondary, accent (hex strings)
     */
    public function ajax_save_brand_selection( array $data ): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            EL_AJAX_Handler::error( 'Permission denied.', 403 );
        }

        $hex_pattern = '/^#[0-9a-fA-F]{6}$/';

        $primary   = sanitize_text_field( $data['primary']   ?? '' );
        $secondary = sanitize_text_field( $data['secondary'] ?? '' );
        $accent    = sanitize_text_field( $data['accent']    ?? '' );
        $index     = absint( $data['palette_index'] ?? 0 );

        if ( ! preg_match( $hex_pattern, $primary ) || ! preg_match( $hex_pattern, $secondary ) || ! preg_match( $hex_pattern, $accent ) ) {
            EL_AJAX_Handler::error( 'Invalid hex color value.' );
        }

        $this->settings->set( 'brand', 'primary_color',   $primary );
        $this->settings->set( 'brand', 'secondary_color', $secondary );
        $this->settings->set( 'brand', 'accent_color',    $accent );
        $this->settings->set( 'brand', 'palette_selected', $index );

        wp_send_json_success();
    }

    /**
     * Prevent cloning and unserialization
     */
    private function __clone() {}
    public function __wakeup() {
        throw new \Exception( 'Cannot unserialize singleton' );
    }
}

/**
 * EL Core — Admin UI Framework Scripts
 *
 * Provides the elAdmin namespace with reusable functions for modals,
 * tabs, filter bars, and dismissible notices.
 *
 * Modules use these functions — they never re-implement this logic.
 *
 * @package EL_Core
 * @since   1.1.0
 */

/* global elAdminData */

const elAdmin = ( function() {

    'use strict';

    // -------------------------------------------------------------------------
    // MODALS
    // -------------------------------------------------------------------------

    /**
     * Open a modal by ID.
     * @param {string} id - The modal element ID.
     */
    function openModal( id ) {
        const modal = document.getElementById( id );
        if ( ! modal ) return;
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
        // Focus the first focusable element inside
        const focusable = modal.querySelector( 'input, select, textarea, button, [href]' );
        if ( focusable ) {
            setTimeout( () => focusable.focus(), 50 );
        }
    }

    /**
     * Close a modal by ID.
     * @param {string} id - The modal element ID.
     */
    function closeModal( id ) {
        const modal = document.getElementById( id );
        if ( ! modal ) return;
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }

    /**
     * Close all open modals.
     */
    function closeAllModals() {
        document.querySelectorAll( '.el-modal' ).forEach( modal => {
            modal.style.display = 'none';
        } );
        document.body.style.overflow = '';
    }

    // Bind modal close buttons and overlay clicks (event delegation)
    document.addEventListener( 'click', function( e ) {
        const closer = e.target.closest( '[data-modal-close]' );
        if ( closer ) {
            closeModal( closer.dataset.modalClose );
            return;
        }

        const opener = e.target.closest( '[data-modal-open]' );
        if ( opener ) {
            openModal( opener.dataset.modalOpen );
            return;
        }
    } );

    // Close modal on Escape key
    document.addEventListener( 'keydown', function( e ) {
        if ( e.key === 'Escape' ) {
            closeAllModals();
        }
    } );

    // -------------------------------------------------------------------------
    // TABS
    // -------------------------------------------------------------------------

    /**
     * Switch to a tab within a group.
     * @param {string} tabId  - The tab ID to activate.
     * @param {string} groupId - The tab group ID.
     */
    function switchTab( tabId, groupId ) {
        // Deactivate all buttons in this group
        document.querySelectorAll( `.el-tab-btn[data-group="${ groupId }"]` ).forEach( btn => {
            btn.classList.remove( 'active' );
        } );

        // Hide all panels in this group
        document.querySelectorAll( `.el-tab-content[data-group="${ groupId }"]` ).forEach( panel => {
            panel.style.display = 'none';
        } );

        // Activate the selected button
        const activeBtn = document.querySelector(
            `.el-tab-btn[data-group="${ groupId }"][data-tab="${ tabId }"]`
        );
        if ( activeBtn ) activeBtn.classList.add( 'active' );

        // Show the selected panel
        const activePanel = document.querySelector(
            `.el-tab-content[data-group="${ groupId }"][data-tab="${ tabId }"]`
        );
        if ( activePanel ) activePanel.style.display = 'block';
    }

    // Bind tab button clicks (event delegation)
    document.addEventListener( 'click', function( e ) {
        const btn = e.target.closest( '.el-tab-btn' );
        if ( ! btn ) return;
        const tabId  = btn.dataset.tab;
        const groupId = btn.dataset.group;
        if ( tabId && groupId ) {
            switchTab( tabId, groupId );
        }
    } );

    // -------------------------------------------------------------------------
    // NOTICES
    // -------------------------------------------------------------------------

    /**
     * Dismiss a notice element.
     * @param {HTMLElement} notice - The .el-notice element to remove.
     */
    function dismissNotice( notice ) {
        notice.style.transition = 'opacity 0.2s ease';
        notice.style.opacity    = '0';
        setTimeout( () => notice.remove(), 200 );
    }

    // Bind notice close buttons (event delegation)
    document.addEventListener( 'click', function( e ) {
        const btn = e.target.closest( '.el-notice-close' );
        if ( ! btn ) return;
        const notice = btn.closest( '.el-notice' );
        if ( notice ) dismissNotice( notice );
    } );

    // -------------------------------------------------------------------------
    // FILTER BAR
    // -------------------------------------------------------------------------

    /**
     * Initialize auto-submit behavior on filter selects.
     * Selects in .el-filter-form submit the form on change automatically.
     */
    function initFilters() {
        document.querySelectorAll( '.el-filter-form .el-filter-select' ).forEach( select => {
            select.addEventListener( 'change', function() {
                this.closest( 'form' ).submit();
            } );
        } );
    }

    // -------------------------------------------------------------------------
    // UTILITIES
    // -------------------------------------------------------------------------

    /**
     * Show a temporary notice at the top of the page.
     * Useful for AJAX responses where you need to show feedback without a reload.
     *
     * @param {string} message - Notice text.
     * @param {string} type    - 'success', 'error', 'warning', or 'info'.
     * @param {number} duration - Auto-dismiss after this many ms. 0 = no auto-dismiss.
     */
    function flashNotice( message, type = 'success', duration = 4000 ) {
        const icons = {
            success: 'yes-alt',
            error:   'dismiss',
            warning: 'warning',
            info:    'info',
        };
        const icon = icons[ type ] || 'info';

        const el = document.createElement( 'div' );
        el.className = `el-notice el-notice-${ type } el-notice-dismissible`;
        el.style.marginBottom = '1rem';
        el.innerHTML = `
            <span class="dashicons dashicons-${ icon }"></span>
            <div class="el-notice-message">${ message }</div>
            <button type="button" class="el-notice-close" aria-label="Dismiss">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        `;

        // Insert after .el-page-header if it exists, otherwise at top of wrap
        const wrap   = document.querySelector( '.el-admin-wrap' );
        const header = document.querySelector( '.el-page-header' );
        if ( wrap ) {
            if ( header && header.nextSibling ) {
                wrap.insertBefore( el, header.nextSibling );
            } else {
                wrap.prepend( el );
            }
        }

        if ( duration > 0 ) {
            setTimeout( () => { if ( el.parentNode ) dismissNotice( el ); }, duration );
        }
    }

    // -------------------------------------------------------------------------
    // AJAX HELPER
    // -------------------------------------------------------------------------

    /**
     * Send an AJAX request to the EL Core handler.
     *
     * @param {string}   action   - The el_action value.
     * @param {Object}   data     - Additional POST data.
     * @param {Function} callback - Called with the parsed JSON response object.
     */
    function ajax( action, data, callback ) {
        const payload = Object.assign( {}, data, {
            action:    'el_core_action',
            el_action: action,
            nonce:     ( window.elAdminData || {} ).nonce || '',
        } );

        const body = new URLSearchParams( payload );

        fetch( ( window.elAdminData || {} ).ajaxUrl || '', {
            method:  'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body:    body.toString(),
        } )
        .then( r => r.json() )
        .then( callback )
        .catch( err => {
            console.error( '[elAdmin] AJAX error:', err );
            callback( { success: false, message: 'Network error.' } );
        } );
    }

    // -------------------------------------------------------------------------
    // BRAND SETTINGS PAGE
    // -------------------------------------------------------------------------

    // ── Color math helpers ──────────────────────────────────────────────────

    function hexToHSL( hex ) {
        hex = hex.replace( /^#/, '' );
        if ( hex.length === 3 ) hex = hex.split( '' ).map( c => c + c ).join( '' );
        const r = parseInt( hex.slice( 0, 2 ), 16 ) / 255;
        const g = parseInt( hex.slice( 2, 4 ), 16 ) / 255;
        const b = parseInt( hex.slice( 4, 6 ), 16 ) / 255;
        const max = Math.max( r, g, b ), min = Math.min( r, g, b );
        let h, s;
        const l = ( max + min ) / 2;
        const diff = max - min;
        if ( diff === 0 ) { h = 0; s = 0; }
        else {
            s = l > 0.5 ? diff / ( 2 - max - min ) : diff / ( max + min );
            switch ( max ) {
                case r: h = ( ( g - b ) / diff + 6 ) % 6; break;
                case g: h = ( b - r ) / diff + 2; break;
                default: h = ( r - g ) / diff + 4;
            }
            h *= 60;
        }
        return { h: Math.round( h ), s: Math.round( s * 100 ), l: Math.round( l * 100 ) };
    }

    function hslToHex( h, s, l ) {
        s /= 100; l /= 100;
        const c  = ( 1 - Math.abs( 2 * l - 1 ) ) * s;
        const x  = c * ( 1 - Math.abs( ( h / 60 ) % 2 - 1 ) );
        const m  = l - c / 2;
        let r = 0, g = 0, b = 0;
        if      ( h < 60  ) { r = c; g = x; b = 0; }
        else if ( h < 120 ) { r = x; g = c; b = 0; }
        else if ( h < 180 ) { r = 0; g = c; b = x; }
        else if ( h < 240 ) { r = 0; g = x; b = c; }
        else if ( h < 300 ) { r = x; g = 0; b = c; }
        else                { r = c; g = 0; b = x; }
        const toHex = n => Math.round( ( n + m ) * 255 ).toString( 16 ).padStart( 2, '0' );
        return '#' + toHex( r ) + toHex( g ) + toHex( b );
    }

    function calculateSemanticColors( primaryHex ) {
        const hsl = hexToHSL( primaryHex );
        const s   = Math.min( 70, Math.max( 50, hsl.s ) );
        const l   = Math.min( 55, Math.max( 40, hsl.l ) );
        return {
            success: hslToHex( 145, s, l ),
            warning: hslToHex( 45,  s, l ),
            error:   hslToHex( 5,   s, l ),
            info:    hslToHex( 210, s, l ),
        };
    }

    // ── Semantic preview strip ───────────────────────────────────────────────

    function updateSemanticPreview() {
        const primaryInput = document.querySelector( '#el-color-primary-input' );
        if ( ! primaryInput ) return;
        const primary = primaryInput.value;
        if ( ! primary || primary.length !== 7 ) return;

        const colors = calculateSemanticColors( primary );
        const successEl = document.querySelector( '.el-semantic-preview-success' );
        const warningEl = document.querySelector( '.el-semantic-preview-warning' );
        const errorEl   = document.querySelector( '.el-semantic-preview-error' );
        const infoEl    = document.querySelector( '.el-semantic-preview-info' );

        if ( successEl ) successEl.style.backgroundColor = colors.success;
        if ( warningEl ) warningEl.style.backgroundColor = colors.warning;
        if ( errorEl   ) errorEl.style.backgroundColor   = colors.error;
        if ( infoEl    ) infoEl.style.backgroundColor    = colors.info;
    }

    // ── Color path toggle (AI vs Manual) ────────────────────────────────────

    function initColorPathToggle() {
        const radios = document.querySelectorAll( 'input[name="el_color_path"]' );
        if ( ! radios.length ) return;

        radios.forEach( radio => {
            radio.addEventListener( 'change', () => {
                const aiPath     = document.querySelector( '.el-color-path-ai' );
                const manualPath = document.querySelector( '.el-color-path-manual' );
                if ( aiPath )     aiPath.style.display     = radio.value === 'ai'     ? 'block' : 'none';
                if ( manualPath ) manualPath.style.display = radio.value === 'manual' ? 'block' : 'none';
            } );
        } );
    }

    // ── Media uploaders ─────────────────────────────────────────────────────

    function initMediaUploaders() {
        document.querySelectorAll( '.el-media-upload-btn' ).forEach( btn => {
            btn.addEventListener( 'click', function() {
                const targetId  = this.dataset.target;
                const previewId = this.dataset.preview;

                const frame = wp.media( {
                    title:    'Select Image',
                    button:   { text: 'Use this image' },
                    multiple: false,
                } );

                frame.on( 'select', () => {
                    const attachment = frame.state().get( 'selection' ).first().toJSON();

                    // Find the input by name (handles el_core_brand[field] names)
                    const input = document.querySelector( `input[name="el_core_brand[${ targetId }]"]` );
                    if ( input ) input.value = attachment.url;

                    const previewWrap = document.getElementById( previewId );
                    if ( previewWrap ) {
                        previewWrap.style.display = 'block';
                        let img = previewWrap.querySelector( 'img' );
                        if ( ! img ) {
                            img = document.createElement( 'img' );
                            img.className = 'el-logo-preview';
                            previewWrap.appendChild( img );
                        }
                        img.src = attachment.url;
                    }

                    // If this is the primary logo, also update the AI path logo reference
                    if ( targetId === 'logo_url' ) {
                        const aiLogoRef = document.querySelector( '.el-ai-analyze-section img' );
                        if ( aiLogoRef ) aiLogoRef.src = attachment.url;
                    }
                } );

                frame.open();
            } );
        } );
    }

    // ── Logo AI analysis ────────────────────────────────────────────────────

    function handleAnalyzeLogo() {
        const logoInput = document.querySelector( 'input[name="el_core_brand[logo_url]"]' );
        if ( ! logoInput || ! logoInput.value ) {
            alert( 'Please upload a logo in the Logo & Identity section first.' );
            return;
        }

        const btn         = document.querySelector( '#el-analyze-logo-btn' );
        const resultsArea = document.querySelector( '.el-palette-results' );
        if ( ! btn || ! resultsArea ) return;

        btn.disabled       = true;
        btn.innerHTML      = '<span class="dashicons dashicons-update-alt" style="animation:rotation 1s linear infinite;"></span> Analyzing…';
        resultsArea.innerHTML = '<p class="el-analyzing-msg">Analyzing your logo — this may take a few seconds…</p>';

        ajax( 'el_analyze_logo', { logo_url: logoInput.value }, function( response ) {
            btn.disabled  = false;
            btn.innerHTML = '<span class="dashicons dashicons-art"></span> Analyze Logo';

            if ( response.success && response.data && response.data.options ) {
                renderPaletteOptions( response.data.options );
                // Store in hidden field so save preserves them
                const hidden = document.getElementById( 'el-ai-palette-hidden' );
                if ( hidden ) hidden.value = JSON.stringify( { options: response.data.options } );
            } else {
                const msg = ( response.data && response.data.message ) ? response.data.message : 'Analysis failed. Please try again.';
                resultsArea.innerHTML = '<p class="el-error-msg">' + msg + '</p>';
            }
        } );
    }

    // ── Palette card rendering ───────────────────────────────────────────────

    function renderPaletteOptions( options ) {
        const resultsArea = document.querySelector( '.el-palette-results' );
        if ( ! resultsArea ) return;
        resultsArea.innerHTML = '';

        const labels = [ 'Option A', 'Option B', 'Option C' ];

        options.forEach( ( option, index ) => {
            const card = document.createElement( 'div' );
            card.className = 'el-palette-card';
            card.innerHTML =
                '<div class="el-palette-swatches">'
                + '<span class="el-swatch el-swatch-primary" style="background:' + option.primary + '" title="Primary: ' + option.primary + '"></span>'
                + '<span class="el-swatch el-swatch-secondary" style="background:' + option.secondary + '" title="Secondary: ' + option.secondary + '"></span>'
                + '<span class="el-swatch el-swatch-accent" style="background:' + option.accent + '" title="Accent: ' + option.accent + '"></span>'
                + '</div>'
                + '<strong>' + ( labels[ index ] || 'Option ' + ( index + 1 ) ) + '</strong>'
                + '<p class="el-palette-rationale">' + ( option.rationale || '' ) + '</p>'
                + '<p class="el-palette-fonts">' + ( option.font_heading || '' ) + ' / ' + ( option.font_body || '' ) + '</p>'
                + '<button type="button" class="el-btn el-btn-secondary el-use-palette-btn"'
                + ' data-index="' + index + '"'
                + ' data-primary="' + option.primary + '"'
                + ' data-secondary="' + option.secondary + '"'
                + ' data-accent="' + option.accent + '">'
                + 'Use This Palette'
                + '</button>';
            resultsArea.appendChild( card );
        } );

        // Bind "Use This Palette" buttons
        resultsArea.querySelectorAll( '.el-use-palette-btn' ).forEach( btn => {
            btn.addEventListener( 'click', () => {
                applyPaletteSelection(
                    parseInt( btn.dataset.index, 10 ),
                    btn.dataset.primary,
                    btn.dataset.secondary,
                    btn.dataset.accent
                );
            } );
        } );
    }

    function applyPaletteSelection( index, primary, secondary, accent ) {
        // Update color inputs (plain text for now; Step 4 will update Pickr pickers too)
        const primaryInput    = document.querySelector( '#el-color-primary-input' );
        const secondaryInput  = document.querySelector( '#el-color-secondary-input' );
        const accentInput     = document.querySelector( '#el-color-accent-input' );

        if ( primaryInput )   primaryInput.value   = primary;
        if ( secondaryInput ) secondaryInput.value = secondary;
        if ( accentInput )    accentInput.value    = accent;

        // Update hidden palette_selected field
        const hiddenIdx = document.getElementById( 'el-palette-selected-hidden' );
        if ( hiddenIdx ) hiddenIdx.value = index;

        // Save selection via AJAX (saves to DB immediately)
        ajax( 'el_save_brand_selection', {
            palette_index: index,
            primary:   primary,
            secondary: secondary,
            accent:    accent,
        }, function( response ) {
            if ( response.success ) {
                // Switch to manual path so user sees the populated inputs
                const manualRadio = document.querySelector( 'input[name="el_color_path"][value="manual"]' );
                if ( manualRadio ) manualRadio.click();
                updateSemanticPreview();
                flashNotice( 'Palette applied! Review the colors below, then click Save Brand Settings.', 'success' );
            } else {
                const msg = ( response.data && response.data.message ) ? response.data.message : 'Could not save selection.';
                flashNotice( msg, 'error' );
            }
        } );
    }

    // ── Pickr color pickers ─────────────────────────────────────────────────

    function initBrandColorPickers() {
        if ( typeof Pickr === 'undefined' ) return;

        const pickerConfigs = [
            { pickrEl: '#el-color-primary-input-pickr',   inputId: 'el-color-primary-input' },
            { pickrEl: '#el-color-secondary-input-pickr', inputId: 'el-color-secondary-input' },
            { pickrEl: '#el-color-accent-input-pickr',    inputId: 'el-color-accent-input' },
        ];

        pickerConfigs.forEach( config => {
            const target = document.querySelector( config.pickrEl );
            const input  = document.getElementById( config.inputId );
            if ( ! target || ! input ) return;

            const picker = Pickr.create( {
                el:      target,
                theme:   'classic',
                default: input.value || '#3B82F6',
                components: {
                    preview:  true,
                    hue:      true,
                    interaction: { hex: true, input: true, save: true },
                },
            } );

            picker.on( 'save', ( color ) => {
                if ( ! color ) return;
                const hex = color.toHEXA().toString();
                input.value = hex;
                updateSemanticPreview();
                picker.hide();
            } );

            // Sync picker if text input is edited manually
            input.addEventListener( 'change', () => {
                const val = input.value.trim();
                if ( /^#[0-9a-fA-F]{6}$/.test( val ) ) {
                    picker.setColor( val, true );
                    updateSemanticPreview();
                }
            } );
        } );
    }

    // ── Brand page initialization ────────────────────────────────────────────

    function initBrandPage() {
        if ( ! document.getElementById( 'el-brand-settings-form' ) ) return;

        initColorPathToggle();
        initMediaUploaders();
        initBrandColorPickers();
        updateSemanticPreview();

        // Live semantic preview on primary color input change
        const primaryInput = document.querySelector( '#el-color-primary-input' );
        if ( primaryInput ) {
            primaryInput.addEventListener( 'input', updateSemanticPreview );
        }

        // Analyze logo button
        const analyzeBtn = document.getElementById( 'el-analyze-logo-btn' );
        if ( analyzeBtn ) {
            analyzeBtn.addEventListener( 'click', handleAnalyzeLogo );
        }

        // "Use This Palette" buttons (pre-rendered from PHP on page load)
        document.querySelectorAll( '.el-use-palette-btn' ).forEach( btn => {
            btn.addEventListener( 'click', () => {
                applyPaletteSelection(
                    parseInt( btn.dataset.index, 10 ),
                    btn.dataset.primary,
                    btn.dataset.secondary,
                    btn.dataset.accent
                );
            } );
        } );
    }

    // -------------------------------------------------------------------------
    // INIT
    // -------------------------------------------------------------------------

    document.addEventListener( 'DOMContentLoaded', function() {
        initFilters();
        initBrandPage();
    } );

    // -------------------------------------------------------------------------
    // PUBLIC API
    // -------------------------------------------------------------------------

    return {
        openModal,
        closeModal,
        closeAllModals,
        switchTab,
        dismissNotice,
        flashNotice,
        initFilters,
        ajax,
        hexToHSL,
        hslToHex,
        calculateSemanticColors,
        updateSemanticPreview,
        initBrandColorPickers,
        renderPaletteOptions,
        applyPaletteSelection,
        initBrandPage,
    };

} )();

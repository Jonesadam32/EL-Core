<?php
/**
 * EL Core — Brand Settings Page (v1.19.0)
 *
 * Five sections: Logo & Identity, Brand Colors, Typography, Brand Voice, Dark Mode.
 * Rebuilt using EL_Admin_UI::* framework.
 * Colors saved via WordPress Settings API (el_core_brand option group).
 * AI palette analysis saved via AJAX (el_analyze_logo / el_save_brand_selection).
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$core  = EL_Core::instance();
$brand = $core->settings->get_brand();
$ai    = $core->settings->get_group( 'ai' );

// Determine initial color-path state
$has_ai_suggestions = ! empty( $brand['ai_palette_suggestions'] );
$default_path       = $has_ai_suggestions ? 'ai' : 'manual';

// Font options (label => stored value)
$font_options = [
    'Inter, sans-serif'          => 'Inter',
    'Poppins, sans-serif'        => 'Poppins',
    'Montserrat, sans-serif'     => 'Montserrat',
    'Raleway, sans-serif'        => 'Raleway',
    'Playfair Display, serif'    => 'Playfair Display',
    'Merriweather, serif'        => 'Merriweather',
    'Lora, serif'                => 'Lora',
    'Source Serif Pro, serif'    => 'Source Serif Pro',
];

$tone_options = [
    'professional'  => __( 'Professional', 'el-core' ),
    'friendly'      => __( 'Friendly', 'el-core' ),
    'inspirational' => __( 'Inspirational', 'el-core' ),
    'bold'          => __( 'Bold', 'el-core' ),
    'calm'          => __( 'Calm', 'el-core' ),
];

ob_start();

// ═══════════════════════════════════════════
// PAGE HEADER
// ═══════════════════════════════════════════

echo EL_Admin_UI::page_header( [
    'title'    => __( 'Brand & Configuration', 'el-core' ),
    'subtitle' => __( 'Visual identity, color system, typography, and AI branding tools.', 'el-core' ),
] );

// ═══════════════════════════════════════════
// BRAND FORM (Settings API)
// ═══════════════════════════════════════════
?>
<form method="post" action="options.php" id="el-brand-settings-form">
    <?php
    settings_fields( 'el_core_brand_group' );

    // ─── SECTION 1: Logo & Identity ───────────────────────────────────────────

    $logo_content = EL_Admin_UI::form_section( [
        'title'       => __( 'Logo & Identity', 'el-core' ),
        'description' => __( 'Upload your logo and favicon. These appear in headers, email templates, and browser tabs.', 'el-core' ),
    ] );

    // Primary Logo
    $logo_preview = $brand['logo_url']
        ? '<img src="' . esc_url( $brand['logo_url'] ) . '" class="el-logo-preview" alt="Logo preview" />'
        : '';

    $logo_field  = '<div class="el-media-row">';
    $logo_field .= '<input type="url" id="el-field-logo_url" name="el_core_brand[logo_url]" value="' . esc_attr( $brand['logo_url'] ) . '" class="el-input el-input-url" />';
    $logo_field .= ' <button type="button" class="el-btn el-btn-secondary el-media-upload-btn" data-target="logo_url" data-preview="el-logo-preview-img">';
    $logo_field .= '<span class="dashicons dashicons-upload"></span> ' . __( 'Upload', 'el-core' );
    $logo_field .= '</button>';
    $logo_field .= '</div>';
    if ( $logo_preview ) {
        $logo_field .= '<div class="el-logo-preview-wrap" id="el-logo-preview-img">' . $logo_preview . '</div>';
    } else {
        $logo_field .= '<div class="el-logo-preview-wrap" id="el-logo-preview-img" style="display:none;"></div>';
    }
    $logo_field .= '<p class="el-form-helper">' . esc_html__( 'Used in the site header and email templates.', 'el-core' ) . '</p>';

    $logo_content .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Primary Logo', 'el-core' ) . '</label><div class="el-form-field">' . $logo_field . '</div></div>';

    // Dark variant
    $dark_field  = '<div class="el-media-row">';
    $dark_field .= '<input type="url" id="el-field-logo_variant_dark" name="el_core_brand[logo_variant_dark]" value="' . esc_attr( $brand['logo_variant_dark'] ) . '" class="el-input el-input-url" />';
    $dark_field .= ' <button type="button" class="el-btn el-btn-secondary el-media-upload-btn" data-target="logo_variant_dark" data-preview="el-logo-dark-preview">';
    $dark_field .= '<span class="dashicons dashicons-upload"></span> ' . __( 'Upload', 'el-core' );
    $dark_field .= '</button>';
    $dark_field .= '</div>';
    if ( $brand['logo_variant_dark'] ) {
        $dark_field .= '<div class="el-logo-preview-wrap" id="el-logo-dark-preview"><img src="' . esc_url( $brand['logo_variant_dark'] ) . '" class="el-logo-preview" alt="" /></div>';
    } else {
        $dark_field .= '<div class="el-logo-preview-wrap" id="el-logo-dark-preview" style="display:none;"></div>';
    }
    $dark_field .= '<p class="el-form-helper">' . esc_html__( 'White or light version of your logo for dark backgrounds.', 'el-core' ) . '</p>';

    $logo_content .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Logo — Dark Background Variant', 'el-core' ) . '</label><div class="el-form-field">' . $dark_field . '</div></div>';

    // Light variant
    $light_field  = '<div class="el-media-row">';
    $light_field .= '<input type="url" id="el-field-logo_variant_light" name="el_core_brand[logo_variant_light]" value="' . esc_attr( $brand['logo_variant_light'] ) . '" class="el-input el-input-url" />';
    $light_field .= ' <button type="button" class="el-btn el-btn-secondary el-media-upload-btn" data-target="logo_variant_light" data-preview="el-logo-light-preview">';
    $light_field .= '<span class="dashicons dashicons-upload"></span> ' . __( 'Upload', 'el-core' );
    $light_field .= '</button>';
    $light_field .= '</div>';
    if ( $brand['logo_variant_light'] ) {
        $light_field .= '<div class="el-logo-preview-wrap" id="el-logo-light-preview"><img src="' . esc_url( $brand['logo_variant_light'] ) . '" class="el-logo-preview" alt="" /></div>';
    } else {
        $light_field .= '<div class="el-logo-preview-wrap" id="el-logo-light-preview" style="display:none;"></div>';
    }
    $light_field .= '<p class="el-form-helper">' . esc_html__( 'Dark version of your logo for light or white backgrounds.', 'el-core' ) . '</p>';

    $logo_content .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Logo — Light Background Variant', 'el-core' ) . '</label><div class="el-form-field">' . $light_field . '</div></div>';

    // Favicon
    $fav_field  = '<div class="el-media-row">';
    $fav_field .= '<input type="url" id="el-field-favicon_url" name="el_core_brand[favicon_url]" value="' . esc_attr( $brand['favicon_url'] ) . '" class="el-input el-input-url" />';
    $fav_field .= ' <button type="button" class="el-btn el-btn-secondary el-media-upload-btn" data-target="favicon_url" data-preview="el-favicon-preview">';
    $fav_field .= '<span class="dashicons dashicons-upload"></span> ' . __( 'Upload', 'el-core' );
    $fav_field .= '</button>';
    $fav_field .= '</div>';
    if ( $brand['favicon_url'] ) {
        $fav_field .= '<div class="el-logo-preview-wrap" id="el-favicon-preview"><img src="' . esc_url( $brand['favicon_url'] ) . '" class="el-logo-preview el-favicon-preview-img" alt="" /></div>';
    } else {
        $fav_field .= '<div class="el-logo-preview-wrap" id="el-favicon-preview" style="display:none;"></div>';
    }
    $fav_field .= '<p class="el-form-helper">' . esc_html__( 'Square image, 512×512px recommended. Appears in browser tabs.', 'el-core' ) . '</p>';

    $logo_content .= '<div class="el-form-row"><label class="el-form-label">' . esc_html__( 'Favicon', 'el-core' ) . '</label><div class="el-form-field">' . $fav_field . '</div></div>';

    echo EL_Admin_UI::card( [
        'title'   => '',
        'content' => $logo_content,
        'class'   => 'el-settings-card',
    ] );

    // ─── SECTION 2: Brand Colors ──────────────────────────────────────────────

    $color_content = EL_Admin_UI::form_section( [
        'title'       => __( 'Brand Colors', 'el-core' ),
        'description' => __( 'Set your brand palette. Colors are used across the entire site via CSS custom properties.', 'el-core' ),
    ] );

    // Path toggle (AI vs Manual)
    $color_content .= '<div class="el-form-row el-color-path-toggle-row">';
    $color_content .= '<label class="el-form-label">' . esc_html__( 'Color Source', 'el-core' ) . '</label>';
    $color_content .= '<div class="el-form-field">';
    $color_content .= '<label class="el-radio-label">';
    $color_content .= '<input type="radio" name="el_color_path" value="ai" ' . checked( $default_path, 'ai', false ) . '> ';
    $color_content .= esc_html__( 'Analyze My Logo (AI)', 'el-core' );
    $color_content .= '</label>';
    $color_content .= ' &nbsp; ';
    $color_content .= '<label class="el-radio-label">';
    $color_content .= '<input type="radio" name="el_color_path" value="manual" ' . checked( $default_path, 'manual', false ) . '> ';
    $color_content .= esc_html__( 'Pick My Own Colors', 'el-core' );
    $color_content .= '</label>';
    $color_content .= '</div>';
    $color_content .= '</div>';

    // ── Path A: AI Analysis ──
    $ai_path_style = $default_path === 'ai' ? '' : ' style="display:none;"';
    $color_content .= '<div class="el-color-path-ai"' . $ai_path_style . '>';

    $color_content .= '<div class="el-ai-analyze-section">';
    if ( $brand['logo_url'] ) {
        $color_content .= '<p class="el-form-helper">'
            . esc_html__( 'Using logo from above. ', 'el-core' )
            . '<img src="' . esc_url( $brand['logo_url'] ) . '" style="height:24px;vertical-align:middle;margin-left:8px;" alt="" />'
            . '</p>';
    } else {
        $color_content .= EL_Admin_UI::notice( [
            'message' => __( 'Upload a logo in the Logo & Identity section above, then come back here to analyze it.', 'el-core' ),
            'type'    => 'info',
        ] );
    }
    $color_content .= '<button type="button" id="el-analyze-logo-btn" class="el-btn el-btn-primary">';
    $color_content .= '<span class="dashicons dashicons-art"></span> ';
    $color_content .= esc_html__( 'Analyze Logo', 'el-core' );
    $color_content .= '</button>';
    $color_content .= '</div>';

    // Palette results area (populated by JS, or pre-rendered if suggestions exist)
    $color_content .= '<div class="el-palette-results">';
    if ( $has_ai_suggestions ) {
        $suggestions = json_decode( $brand['ai_palette_suggestions'], true );
        if ( ! empty( $suggestions['options'] ) ) {
            $labels = [ 'Option A', 'Option B', 'Option C' ];
            foreach ( $suggestions['options'] as $idx => $opt ) {
                $is_selected = ( (int) $brand['palette_selected'] === $idx );
                $card_class  = 'el-palette-card' . ( $is_selected ? ' el-palette-card-selected' : '' );
                $color_content .= '<div class="' . $card_class . '">';
                $color_content .= '<div class="el-palette-swatches">';
                $color_content .= '<span class="el-swatch el-swatch-primary" style="background:' . esc_attr( $opt['primary'] ) . '" title="Primary: ' . esc_attr( $opt['primary'] ) . '"></span>';
                $color_content .= '<span class="el-swatch el-swatch-secondary" style="background:' . esc_attr( $opt['secondary'] ) . '" title="Secondary: ' . esc_attr( $opt['secondary'] ) . '"></span>';
                $color_content .= '<span class="el-swatch el-swatch-accent" style="background:' . esc_attr( $opt['accent'] ) . '" title="Accent: ' . esc_attr( $opt['accent'] ) . '"></span>';
                $color_content .= '</div>';
                $color_content .= '<strong>' . esc_html( $labels[ $idx ] ?? "Option {$idx}" ) . '</strong>';
                $color_content .= '<p class="el-palette-rationale">' . esc_html( $opt['rationale'] ?? '' ) . '</p>';
                $color_content .= '<p class="el-palette-fonts">' . esc_html( ( $opt['font_heading'] ?? '' ) . ' / ' . ( $opt['font_body'] ?? '' ) ) . '</p>';
                $color_content .= '<button type="button" class="el-btn el-btn-secondary el-use-palette-btn" '
                    . 'data-index="' . $idx . '" '
                    . 'data-primary="' . esc_attr( $opt['primary'] ) . '" '
                    . 'data-secondary="' . esc_attr( $opt['secondary'] ) . '" '
                    . 'data-accent="' . esc_attr( $opt['accent'] ) . '">'
                    . esc_html__( 'Use This Palette', 'el-core' )
                    . '</button>';
                $color_content .= '</div>';
            }
        }
    }
    $color_content .= '</div>'; // .el-palette-results

    $color_content .= '</div>'; // .el-color-path-ai

    // ── Path B: Manual Picker ──
    $manual_path_style = $default_path === 'manual' ? '' : ' style="display:none;"';
    $color_content .= '<div class="el-color-path-manual"' . $manual_path_style . '>';

    // Helper to build a Pickr color picker field row
    $make_color_row = function( string $field_name, string $field_id, string $label, string $value, string $helper ) {
        $html  = '<div class="el-form-row">';
        $html .= '<label class="el-form-label">' . esc_html( $label ) . '</label>';
        $html .= '<div class="el-form-field">';
        $html .= '<div class="el-color-picker-row">';
        $html .= '<div id="' . esc_attr( $field_id ) . '-pickr" class="el-pickr-target"></div>';
        $html .= '<input type="text" id="' . esc_attr( $field_id ) . '" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $value ) . '" class="el-input el-color-input" maxlength="7" />';
        $html .= '</div>';
        $html .= '<p class="el-form-helper">' . esc_html( $helper ) . '</p>';
        $html .= '</div>';
        $html .= '</div>';
        return $html;
    };

    $color_content .= $make_color_row(
        'el_core_brand[primary_color]', 'el-color-primary-input',
        __( 'Primary Color', 'el-core' ),
        $brand['primary_color'],
        __( 'Used for buttons, headings, and key UI elements.', 'el-core' )
    );

    $color_content .= $make_color_row(
        'el_core_brand[secondary_color]', 'el-color-secondary-input',
        __( 'Secondary Color', 'el-core' ),
        $brand['secondary_color'],
        __( 'Used for backgrounds, cards, and secondary UI elements.', 'el-core' )
    );

    $color_content .= $make_color_row(
        'el_core_brand[accent_color]', 'el-color-accent-input',
        __( 'Accent Color', 'el-core' ),
        $brand['accent_color'],
        __( 'Used for CTAs, badges, and links.', 'el-core' )
    );

    // Semantic color preview strip (read-only, updated live by JS)
    $color_content .= '<div class="el-form-row">';
    $color_content .= '<label class="el-form-label">' . esc_html__( 'System Colors', 'el-core' ) . '</label>';
    $color_content .= '<div class="el-form-field">';
    $color_content .= '<div class="el-semantic-preview">';
    $color_content .= '<div class="el-semantic-swatch"><span class="el-semantic-preview-success"></span><small>' . esc_html__( 'Success', 'el-core' ) . '</small></div>';
    $color_content .= '<div class="el-semantic-swatch"><span class="el-semantic-preview-warning"></span><small>' . esc_html__( 'Warning', 'el-core' ) . '</small></div>';
    $color_content .= '<div class="el-semantic-swatch"><span class="el-semantic-preview-error"></span><small>' . esc_html__( 'Error', 'el-core' ) . '</small></div>';
    $color_content .= '<div class="el-semantic-swatch"><span class="el-semantic-preview-info"></span><small>' . esc_html__( 'Info', 'el-core' ) . '</small></div>';
    $color_content .= '</div>';
    $color_content .= '<p class="el-form-helper">' . esc_html__( 'Auto-generated from your brand palette. Used for success messages, warnings, and alerts.', 'el-core' ) . '</p>';
    $color_content .= '</div>';
    $color_content .= '</div>';

    $color_content .= '</div>'; // .el-color-path-manual

    echo EL_Admin_UI::card( [
        'title'   => '',
        'content' => $color_content,
        'class'   => 'el-settings-card',
    ] );

    // ─── SECTION 3: Typography ────────────────────────────────────────────────

    $type_content = EL_Admin_UI::form_section( [
        'title'       => __( 'Typography', 'el-core' ),
        'description' => __( 'Choose heading and body fonts for your site.', 'el-core' ),
    ] );

    $type_content .= EL_Admin_UI::form_row( [
        'name'    => 'el_core_brand[font_heading]',
        'id'      => 'el-font-heading',
        'label'   => __( 'Heading Font', 'el-core' ),
        'type'    => 'select',
        'value'   => $brand['font_heading'],
        'options' => $font_options,
        'helper'  => __( 'Applied to all headings (H1–H4).', 'el-core' ),
    ] );

    $type_content .= EL_Admin_UI::form_row( [
        'name'        => 'el_core_brand[font_heading_custom]',
        'id'          => 'el-font-heading-custom',
        'label'       => __( 'Or enter a custom heading font', 'el-core' ),
        'type'        => 'text',
        'value'       => isset( $font_options[ $brand['font_heading'] ] ) ? '' : $brand['font_heading'],
        'placeholder' => 'e.g. Nunito, sans-serif',
        'helper'      => __( 'If using a custom font, make sure it is loaded by your theme.', 'el-core' ),
    ] );

    $type_content .= EL_Admin_UI::form_row( [
        'name'    => 'el_core_brand[font_body]',
        'id'      => 'el-font-body',
        'label'   => __( 'Body Font', 'el-core' ),
        'type'    => 'select',
        'value'   => $brand['font_body'],
        'options' => $font_options,
        'helper'  => __( 'Used for paragraphs and general content text.', 'el-core' ),
    ] );

    $type_content .= EL_Admin_UI::form_row( [
        'name'        => 'el_core_brand[font_body_custom]',
        'id'          => 'el-font-body-custom',
        'label'       => __( 'Or enter a custom body font', 'el-core' ),
        'type'        => 'text',
        'value'       => isset( $font_options[ $brand['font_body'] ] ) ? '' : $brand['font_body'],
        'placeholder' => 'e.g. Nunito, sans-serif',
        'helper'      => __( 'If using a custom font, make sure it is loaded by your theme.', 'el-core' ),
    ] );

    echo EL_Admin_UI::card( [
        'title'   => '',
        'content' => $type_content,
        'class'   => 'el-settings-card',
    ] );

    // ─── SECTION 4: Brand Voice ───────────────────────────────────────────────

    $voice_content = EL_Admin_UI::form_section( [
        'title'       => __( 'Brand Voice', 'el-core' ),
        'description' => __( 'These fields guide AI-generated content to match your organization\'s tone and values.', 'el-core' ),
    ] );

    $voice_content .= EL_Admin_UI::form_row( [
        'name'    => 'el_core_brand[brand_tone]',
        'id'      => 'el-brand-tone',
        'label'   => __( 'Tone', 'el-core' ),
        'type'    => 'select',
        'value'   => $brand['brand_tone'],
        'options' => $tone_options,
        'helper'  => __( 'How should your written content sound to your audience?', 'el-core' ),
    ] );

    $voice_content .= EL_Admin_UI::form_row( [
        'name'        => 'el_core_brand[brand_audience]',
        'id'          => 'el-brand-audience',
        'label'       => __( 'Target Audience', 'el-core' ),
        'type'        => 'text',
        'value'       => $brand['brand_audience'],
        'placeholder' => __( 'K-12 educators and district administrators', 'el-core' ),
        'helper'      => __( 'Describe who you are primarily speaking to.', 'el-core' ),
    ] );

    $voice_content .= EL_Admin_UI::form_row( [
        'name'        => 'el_core_brand[brand_values]',
        'id'          => 'el-brand-values',
        'label'       => __( 'Brand Values', 'el-core' ),
        'type'        => 'textarea',
        'value'       => $brand['brand_values'],
        'placeholder' => __( '2-3 sentences describing what your organization stands for and what makes you different.', 'el-core' ),
        'helper'      => __( 'Used to guide AI-generated content to match your voice.', 'el-core' ),
    ] );

    echo EL_Admin_UI::card( [
        'title'   => '',
        'content' => $voice_content,
        'class'   => 'el-settings-card',
    ] );

    // ─── SECTION 5: Dark Mode ─────────────────────────────────────────────────

    $dark_content = EL_Admin_UI::form_section( [
        'title'       => __( 'Dark Mode', 'el-core' ),
        'description' => '',
    ] );

    $dark_content .= EL_Admin_UI::form_row( [
        'name'        => 'el_core_brand[dark_mode_preference]',
        'id'          => 'el-dark-mode',
        'label'       => __( 'Dark Mode Support', 'el-core' ),
        'type'        => 'checkbox',
        'value'       => (bool) $brand['dark_mode_preference'],
        'placeholder' => __( 'This installation should support dark mode', 'el-core' ),
        'helper'      => __( 'Records your preference for future dark theme support. No dark styles are generated yet — this setting will be used in a future update.', 'el-core' ),
    ] );

    echo EL_Admin_UI::card( [
        'title'   => '',
        'content' => $dark_content,
        'class'   => 'el-settings-card',
    ] );

    // ─── SAVE BUTTON ──────────────────────────────────────────────────────────
    echo '<div class="el-settings-save-row">';
    // Org name hidden (not surfaced here — edit on General settings page)
    echo '<input type="hidden" name="el_core_brand[org_name]" value="' . esc_attr( $brand['org_name'] ) . '" />';
    echo '<input type="hidden" name="el_core_brand[ai_palette_suggestions]" id="el-ai-palette-hidden" value="' . esc_attr( $brand['ai_palette_suggestions'] ) . '" />';
    echo '<input type="hidden" name="el_core_brand[palette_selected]" id="el-palette-selected-hidden" value="' . esc_attr( $brand['palette_selected'] ?? '' ) . '" />';
    submit_button( __( 'Save Brand Settings', 'el-core' ), 'primary large', 'submit', false );
    echo '</div>';
    ?>
</form>

<?php
// ─── AI SETTINGS (separate form, unchanged) ────────────────────────────────

$ai_content = EL_Admin_UI::form_section( [
    'title'       => __( 'AI Configuration', 'el-core' ),
    'description' => __( 'Configure the AI provider used for logo analysis and AI-generated content across all modules.', 'el-core' ),
] );
?>
<form method="post" action="options.php">
    <?php settings_fields( 'el_core_ai_group' ); ?>
    <?php
    $ai_content .= EL_Admin_UI::form_row( [
        'name'    => 'el_core_ai[provider]',
        'id'      => 'el-ai-provider',
        'label'   => __( 'AI Provider', 'el-core' ),
        'type'    => 'select',
        'value'   => $ai['provider'],
        'options' => [
            'anthropic' => 'Anthropic (Claude)',
            'openai'    => 'OpenAI (GPT)',
        ],
    ] );

    $ai_content .= EL_Admin_UI::form_row( [
        'name'   => 'el_core_ai[api_key]',
        'id'     => 'el-ai-api-key',
        'label'  => __( 'API Key', 'el-core' ),
        'type'   => 'password',
        'value'  => $ai['api_key'],
        'helper' => __( 'Your API key is stored in the WordPress database.', 'el-core' ),
    ] );

    $ai_content .= EL_Admin_UI::form_row( [
        'name'   => 'el_core_ai[model]',
        'id'     => 'el-ai-model',
        'label'  => __( 'Model', 'el-core' ),
        'type'   => 'text',
        'value'  => $ai['model'],
        'helper' => __( 'Anthropic: claude-sonnet-4-5-20250929 | OpenAI: gpt-4o', 'el-core' ),
    ] );

    $ai_content .= EL_Admin_UI::form_row( [
        'name'  => 'el_core_ai[max_tokens]',
        'id'    => 'el-ai-max-tokens',
        'label' => __( 'Default Max Tokens', 'el-core' ),
        'type'  => 'number',
        'value' => $ai['max_tokens'],
    ] );

    echo EL_Admin_UI::card( [
        'title'   => '',
        'content' => $ai_content,
        'class'   => 'el-settings-card',
    ] );

    echo '<div class="el-settings-save-row">';
    submit_button( __( 'Save AI Settings', 'el-core' ), 'primary large', 'submit', false );
    echo '</div>';
    ?>
</form>

<?php

$page_html = ob_get_clean();
echo EL_Admin_UI::wrap( $page_html );
